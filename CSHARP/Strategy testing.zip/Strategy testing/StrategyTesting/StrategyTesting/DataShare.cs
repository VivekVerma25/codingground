﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StrategyTesting
{
    public class DataShare
    {

    }

    public enum PlotOption
    {
        SECURITY_PRICE,
        SECURITY_TRADES,
        MTM,
        NET_POSITION,
        DD,
        RETURN_DIST,
        YOY,
        MOM,
        HOH
    }
}
