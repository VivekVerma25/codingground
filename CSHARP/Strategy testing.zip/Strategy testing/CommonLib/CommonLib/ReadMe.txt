﻿TODO: Convert to standard format.

General: if a name has more than one word it should be seperated using caps. Eg: myClassForComplexNumbers
1) Name of Methods -> starts with capital, params start with small letter
2) Arrays and local variables -> start with small letter
3) Class names -> start with capital letter but objects with small letter
4) Enums -> starts with captital and interal elements also start with capital
5) Property -> starts with capital
6) Interface -> starts with capital "I"

