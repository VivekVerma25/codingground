// Set versioning information for the assembly.
[assembly:System.Reflection.AssemblyCompanyAttribute("ALGLIB Project")]
[assembly:System.Reflection.AssemblyProductAttribute("ALGLIB for C# (managed)")]
[assembly:System.Reflection.AssemblyInformationalVersionAttribute("3.9.0.0")]
