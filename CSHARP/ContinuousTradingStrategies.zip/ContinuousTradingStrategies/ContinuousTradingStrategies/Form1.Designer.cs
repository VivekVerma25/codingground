﻿namespace ContinuousTradingStrategies
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cbReadFile = new System.Windows.Forms.ComboBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbLoadFile = new System.Windows.Forms.ToolStripButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.cbSelectStrategy = new System.Windows.Forms.ComboBox();
            this.btnRunStrat = new System.Windows.Forms.Button();
            this.dgParams = new System.Windows.Forms.DataGridView();
            this.tabOutput = new System.Windows.Forms.TabControl();
            this.tabOverall = new System.Windows.Forms.TabPage();
            this.dgOverall = new System.Windows.Forms.DataGridView();
            this.tabStocks = new System.Windows.Forms.TabPage();
            this.dgStocks = new System.Windows.Forms.DataGridView();
            this.tabDates = new System.Windows.Forms.TabPage();
            this.dgDates = new System.Windows.Forms.DataGridView();
            this.tabTrades = new System.Windows.Forms.TabPage();
            this.dgTrades = new System.Windows.Forms.DataGridView();
            this.tabYearly = new System.Windows.Forms.TabPage();
            this.dgYearly = new System.Windows.Forms.DataGridView();
            this.lbDisplay = new System.Windows.Forms.ListBox();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgParams)).BeginInit();
            this.tabOutput.SuspendLayout();
            this.tabOverall.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgOverall)).BeginInit();
            this.tabStocks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgStocks)).BeginInit();
            this.tabDates.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDates)).BeginInit();
            this.tabTrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTrades)).BeginInit();
            this.tabYearly.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgYearly)).BeginInit();
            this.SuspendLayout();
            // 
            // cbReadFile
            // 
            this.cbReadFile.FormattingEnabled = true;
            this.cbReadFile.ImeMode = System.Windows.Forms.ImeMode.On;
            this.cbReadFile.Items.AddRange(new object[] {
            "Read Data File Horizontal",
            "Read Data File Vertical",
            "Read Vertical Date Time Separate",
            "Read Vertical File with Bid Ask"});
            this.cbReadFile.Location = new System.Drawing.Point(52, 38);
            this.cbReadFile.Name = "cbReadFile";
            this.cbReadFile.Size = new System.Drawing.Size(203, 21);
            this.cbReadFile.TabIndex = 0;
            this.cbReadFile.Text = "Read Data File Vertical";
            this.cbReadFile.SelectedIndexChanged += new System.EventHandler(this.cbReadFile_SelectedIndexChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLoadFile});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1150, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // tsbLoadFile
            // 
            this.tsbLoadFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLoadFile.Image = ((System.Drawing.Image)(resources.GetObject("tsbLoadFile.Image")));
            this.tsbLoadFile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLoadFile.Name = "tsbLoadFile";
            this.tsbLoadFile.Size = new System.Drawing.Size(37, 22);
            this.tsbLoadFile.Text = "Load";
            this.tsbLoadFile.Click += new System.EventHandler(this.tsbLoadFile_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // cbSelectStrategy
            // 
            this.cbSelectStrategy.FormattingEnabled = true;
            this.cbSelectStrategy.ImeMode = System.Windows.Forms.ImeMode.On;
            this.cbSelectStrategy.Items.AddRange(new object[] {
            "OpeningGap",
            "OpeningGapContra",
            "VPOC"});
            this.cbSelectStrategy.Location = new System.Drawing.Point(52, 81);
            this.cbSelectStrategy.Name = "cbSelectStrategy";
            this.cbSelectStrategy.Size = new System.Drawing.Size(203, 21);
            this.cbSelectStrategy.TabIndex = 3;
            this.cbSelectStrategy.SelectedIndexChanged += new System.EventHandler(this.cbSelectStrategy_SelectedIndexChanged);
            // 
            // btnRunStrat
            // 
            this.btnRunStrat.Location = new System.Drawing.Point(292, 81);
            this.btnRunStrat.Name = "btnRunStrat";
            this.btnRunStrat.Size = new System.Drawing.Size(173, 21);
            this.btnRunStrat.TabIndex = 4;
            this.btnRunStrat.Text = "Run Strategy";
            this.btnRunStrat.UseVisualStyleBackColor = true;
            this.btnRunStrat.Click += new System.EventHandler(this.btnRunStrat_Click);
            // 
            // dgParams
            // 
            this.dgParams.AllowUserToAddRows = false;
            this.dgParams.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgParams.ColumnHeadersVisible = false;
            this.dgParams.Location = new System.Drawing.Point(56, 128);
            this.dgParams.Name = "dgParams";
            this.dgParams.RowHeadersVisible = false;
            this.dgParams.Size = new System.Drawing.Size(279, 282);
            this.dgParams.TabIndex = 5;
            this.dgParams.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgParams_CellContentClick);
            // 
            // tabOutput
            // 
            this.tabOutput.Controls.Add(this.tabOverall);
            this.tabOutput.Controls.Add(this.tabStocks);
            this.tabOutput.Controls.Add(this.tabDates);
            this.tabOutput.Controls.Add(this.tabTrades);
            this.tabOutput.Controls.Add(this.tabYearly);
            this.tabOutput.Location = new System.Drawing.Point(527, 41);
            this.tabOutput.Name = "tabOutput";
            this.tabOutput.SelectedIndex = 0;
            this.tabOutput.Size = new System.Drawing.Size(612, 583);
            this.tabOutput.TabIndex = 6;
            this.tabOutput.SelectedIndexChanged += new System.EventHandler(this.tabOutput_SelectedIndexChanged);
            // 
            // tabOverall
            // 
            this.tabOverall.Controls.Add(this.dgOverall);
            this.tabOverall.Location = new System.Drawing.Point(4, 22);
            this.tabOverall.Name = "tabOverall";
            this.tabOverall.Padding = new System.Windows.Forms.Padding(3);
            this.tabOverall.Size = new System.Drawing.Size(604, 557);
            this.tabOverall.TabIndex = 0;
            this.tabOverall.Text = "Overall";
            this.tabOverall.UseVisualStyleBackColor = true;
            this.tabOverall.Click += new System.EventHandler(this.tabOverall_Click);
            // 
            // dgOverall
            // 
            this.dgOverall.AllowUserToAddRows = false;
            this.dgOverall.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgOverall.Location = new System.Drawing.Point(3, 4);
            this.dgOverall.Name = "dgOverall";
            this.dgOverall.Size = new System.Drawing.Size(600, 552);
            this.dgOverall.TabIndex = 0;
            this.dgOverall.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgOverall_CellContentClick);
            // 
            // tabStocks
            // 
            this.tabStocks.Controls.Add(this.dgStocks);
            this.tabStocks.Location = new System.Drawing.Point(4, 22);
            this.tabStocks.Name = "tabStocks";
            this.tabStocks.Padding = new System.Windows.Forms.Padding(3);
            this.tabStocks.Size = new System.Drawing.Size(604, 557);
            this.tabStocks.TabIndex = 1;
            this.tabStocks.Text = "Stocks";
            this.tabStocks.UseVisualStyleBackColor = true;
            this.tabStocks.Click += new System.EventHandler(this.tabStocks_Click);
            // 
            // dgStocks
            // 
            this.dgStocks.AllowUserToAddRows = false;
            this.dgStocks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgStocks.Location = new System.Drawing.Point(3, 5);
            this.dgStocks.Name = "dgStocks";
            this.dgStocks.Size = new System.Drawing.Size(600, 551);
            this.dgStocks.TabIndex = 0;
            this.dgStocks.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgStocks_CellContentClick);
            // 
            // tabDates
            // 
            this.tabDates.Controls.Add(this.dgDates);
            this.tabDates.Location = new System.Drawing.Point(4, 22);
            this.tabDates.Name = "tabDates";
            this.tabDates.Size = new System.Drawing.Size(604, 557);
            this.tabDates.TabIndex = 2;
            this.tabDates.Text = "Dates";
            this.tabDates.UseVisualStyleBackColor = true;
            this.tabDates.Click += new System.EventHandler(this.tabDates_Click);
            // 
            // dgDates
            // 
            this.dgDates.AllowUserToAddRows = false;
            this.dgDates.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDates.Location = new System.Drawing.Point(2, 3);
            this.dgDates.Name = "dgDates";
            this.dgDates.Size = new System.Drawing.Size(600, 551);
            this.dgDates.TabIndex = 1;
            this.dgDates.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDates_CellContentClick);
            // 
            // tabTrades
            // 
            this.tabTrades.Controls.Add(this.dgTrades);
            this.tabTrades.Location = new System.Drawing.Point(4, 22);
            this.tabTrades.Name = "tabTrades";
            this.tabTrades.Padding = new System.Windows.Forms.Padding(3);
            this.tabTrades.Size = new System.Drawing.Size(604, 557);
            this.tabTrades.TabIndex = 3;
            this.tabTrades.Text = "Trades";
            this.tabTrades.UseVisualStyleBackColor = true;
            this.tabTrades.Click += new System.EventHandler(this.tabTrades_Click);
            // 
            // dgTrades
            // 
            this.dgTrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTrades.Location = new System.Drawing.Point(4, 4);
            this.dgTrades.Name = "dgTrades";
            this.dgTrades.Size = new System.Drawing.Size(600, 553);
            this.dgTrades.TabIndex = 0;
            this.dgTrades.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTrades_CellContentClick);
            // 
            // tabYearly
            // 
            this.tabYearly.Controls.Add(this.dgYearly);
            this.tabYearly.Location = new System.Drawing.Point(4, 22);
            this.tabYearly.Name = "tabYearly";
            this.tabYearly.Size = new System.Drawing.Size(604, 557);
            this.tabYearly.TabIndex = 4;
            this.tabYearly.Text = "Yearly";
            this.tabYearly.UseVisualStyleBackColor = true;
            this.tabYearly.Click += new System.EventHandler(this.tabYearly_Click);
            // 
            // dgYearly
            // 
            this.dgYearly.AllowUserToAddRows = false;
            this.dgYearly.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgYearly.Location = new System.Drawing.Point(4, 4);
            this.dgYearly.Name = "dgYearly";
            this.dgYearly.Size = new System.Drawing.Size(597, 550);
            this.dgYearly.TabIndex = 0;
            this.dgYearly.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgYearly_CellContentClick);
            // 
            // lbDisplay
            // 
            this.lbDisplay.FormattingEnabled = true;
            this.lbDisplay.Location = new System.Drawing.Point(56, 436);
            this.lbDisplay.Name = "lbDisplay";
            this.lbDisplay.Size = new System.Drawing.Size(443, 95);
            this.lbDisplay.TabIndex = 7;
            this.lbDisplay.SelectedIndexChanged += new System.EventHandler(this.lbDisplay_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 629);
            this.Controls.Add(this.lbDisplay);
            this.Controls.Add(this.tabOutput);
            this.Controls.Add(this.dgParams);
            this.Controls.Add(this.btnRunStrat);
            this.Controls.Add(this.cbSelectStrategy);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.cbReadFile);
            this.Name = "Form1";
            this.Text = "Form1";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgParams)).EndInit();
            this.tabOutput.ResumeLayout(false);
            this.tabOverall.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgOverall)).EndInit();
            this.tabStocks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgStocks)).EndInit();
            this.tabDates.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDates)).EndInit();
            this.tabTrades.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTrades)).EndInit();
            this.tabYearly.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgYearly)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbReadFile;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbLoadFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ComboBox cbSelectStrategy;
        private System.Windows.Forms.Button btnRunStrat;
        private System.Windows.Forms.DataGridView dgParams;
        private System.Windows.Forms.TabControl tabOutput;
        private System.Windows.Forms.TabPage tabOverall;
        private System.Windows.Forms.DataGridView dgOverall;
        private System.Windows.Forms.TabPage tabStocks;
        private System.Windows.Forms.DataGridView dgStocks;
        private System.Windows.Forms.TabPage tabDates;
        private System.Windows.Forms.DataGridView dgDates;
        private System.Windows.Forms.ListBox lbDisplay;
        private System.Windows.Forms.TabPage tabTrades;
        private System.Windows.Forms.DataGridView dgTrades;
        private System.Windows.Forms.TabPage tabYearly;
        private System.Windows.Forms.DataGridView dgYearly;
    }
}

