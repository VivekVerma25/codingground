﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using CommonLib;


namespace ContinuousTradingStrategies
{
    public partial class Form1 : Form
    {
        # region Common Variables

        private string FilePath ;
        private stocks[] stocksobj;
        private stocks2[] stocksobj2;
        private IEnumerable<DateTime> alldates;
        private List<dailypnl> daydetails;

        # endregion

        public Form1()
        {
            InitializeComponent();
        }

        public class stocks
        {
            public string stkname;
            public List<DateTime> dttm;
            public List<double> high, low, close, bid, ask;
            public double tottrds, totmtm;
            public List<DateTime> entm;
            public List<DateTime> extm;
            public List<double> entryprice;
            public List<double> exitprice;
            public List<double> pnl;
            public List<double> avgog;
        }

        public class stocks2
        {
            public string stkname;
            public List<DateTime> dttm;
            public List<double> high, low, close, volume;
            public double tottrds, totmtm;
            public List<DateTime> entm;
            public List<DateTime> extm;
            public List<double> entryprice;
            public List<double> exitprice;
            public List<double> pnl;
            public List<double> avgog;
        }

        public class dailypnl
        {
            public DateTime trddt = DateTime.MinValue;            
            public double daypnl;

            public dailypnl(DateTime dt, double pl)
            {
                if (dt != null)
                {
                    trddt = dt;
                }
                daypnl = pl;
            }
        }


        private void tsbLoadFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            DialogResult dr = openFileDialog1.ShowDialog();
            
            
            FilePath = openFileDialog1.FileName;
                if (!File.Exists(FilePath))
                    MessageBox.Show("Please Select valid file");
                else
                {
                    if (FilePath == "")
                        MessageBox.Show("Please Select file");
                    else
                    {
                        Stopwatch watcher = new Stopwatch();
                        watcher.Start();
                        StreamReader sr = new StreamReader(FilePath);

                        # region Read File

                        switch (cbReadFile.SelectedIndex)
                        {
                            # region Horizontal File

                            case 0:
                                String[] temp = sr.ReadLine().Split(',');
                                int numstk = temp.Length / 5;
                                stocksobj = new stocks[numstk];
                                String[] stklist = new string[numstk];
                                List<DateTime>[] dtarr = new List<DateTime>[numstk];
                                List<double>[] harr = new List<double>[numstk];
                                List<double>[] larr = new List<double>[numstk];
                                List<double>[] carr = new List<double>[numstk];

                                for (int i = 0; i < numstk; i++)
                                {
                                    dtarr[i] = new List<DateTime>();
                                    harr[i] = new List<double>();
                                    larr[i] = new List<double>();
                                    carr[i] = new List<double>();
                                }

                                //bool secondline = false;

                                while (sr.Peek() >= 0)
                                {
                                    string Line = sr.ReadLine();
                                    string[] fields = Line.Split(',');

                                    for (int i = 0; i < numstk; i++)
                                    {
                                        if (fields[5 * i] != "" && fields[5 * i + 1] != "" && fields[5 * i + 2] != "" && fields[5 * i + 3] != "" && fields[5 * i + 4] != "")
                                        {
                                            if (stklist[i] == null)
                                                stklist[i] = fields[5 * i].ToString();                                            

                                            DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[5 * i + 1]));
                                            dtarr[i].Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                            harr[i].Add(Convert.ToDouble(fields[5 * i + 2]));
                                            larr[i].Add(Convert.ToDouble(fields[5 * i + 3]));
                                            carr[i].Add(Convert.ToDouble(fields[5 * i + 4]));
                                        }
                                    }
                                    //secondline = true;
                                }

                                sr.Close();

                                for (int i = 0; i < numstk; i++)
                                {
                                    stocksobj[i] = new stocks();
                                    stocksobj[i].stkname = stklist[i];
                                    stocksobj[i].dttm = dtarr[i];
                                    stocksobj[i].high = harr[i];
                                    stocksobj[i].low = larr[i];
                                    stocksobj[i].close = carr[i];
                                }

                                break;

                            # endregion

                            # region Vertical File date + time

                            case 1:
                                String[] tempvert = sr.ReadLine().Split(',');
                                List<stocks> stocksobjvert = new List<stocks>();
                                List<String> stklistvert = new List<string>();
                                List<DateTime> dtarrvert = new List<DateTime>();
                                List<double> harrvert = new List<double>();
                                List<double> larrvert = new List<double>();
                                List<double> carrvert = new List<double>();
                                                                

                                while (sr.Peek() >= 0)
                                {
                                    string[] fields = sr.ReadLine().Split(',');


                                    if (fields[0] != "" && fields[1] != "" && fields[2] != "" && fields[3] != "" && fields[4] != "")
                                    {
                                        if(stklistvert.Count() == 0)
                                        {
                                            stklistvert.Add(fields[0].ToString());
                                            
                                            //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                            DateTime tmpdttm = DateTime.Parse(fields[1]);
                                            dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                            harrvert.Add(Convert.ToDouble(fields[2]));
                                            larrvert.Add(Convert.ToDouble(fields[3]));
                                            carrvert.Add(Convert.ToDouble(fields[4]));
                                        }
                                        else
                                            if (string.Equals(stklistvert.Last(),fields[0].ToString()))
                                            {
                                                //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                                DateTime tmpdttm = DateTime.Parse(fields[1]);
                                                dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                                harrvert.Add(Convert.ToDouble(fields[2]));
                                                larrvert.Add(Convert.ToDouble(fields[3]));
                                                carrvert.Add(Convert.ToDouble(fields[4]));
                                            }
                                            else
                                            {                 
                                                stocks stocksvert = new stocks();
                                                stocksvert.stkname = stklistvert.Last();
                                                stocksvert.dttm = dtarrvert;
                                                stocksvert.high = harrvert;
                                                stocksvert.low = larrvert;
                                                stocksvert.close = carrvert;
                                                stocksobjvert.Add(stocksvert);

                                                stklistvert.Add(fields[0].ToString());
                                                dtarrvert = new List<DateTime>();
                                                harrvert = new List<double>();
                                                larrvert = new List<double>();
                                                carrvert = new List<double>();
                                                //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                                DateTime tmpdttm = DateTime.Parse(fields[1]);
                                                dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                                harrvert.Add(Convert.ToDouble(fields[2]));
                                                larrvert.Add(Convert.ToDouble(fields[3]));
                                                carrvert.Add(Convert.ToDouble(fields[4]));
                                            }
                                        
                                    }                                    


                                    
                                }

                                stocks stocksvert2 = new stocks();
                                stocksvert2.stkname = stklistvert.Last();
                                stocksvert2.dttm = dtarrvert;
                                stocksvert2.high = harrvert;
                                stocksvert2.low = larrvert;
                                stocksvert2.close = carrvert;
                                stocksobjvert.Add(stocksvert2);

                                sr.Close();
                                stocksobj = stocksobjvert.ToArray();
                                stocksobjvert.Clear();
                                break;

                            # endregion

                            # region Vertical File with separate date and time

                            case 2:
                                tempvert = sr.ReadLine().Split(',');
                                stocksobjvert = new List<stocks>();
                                stklistvert = new List<string>();
                                dtarrvert = new List<DateTime>();
                                harrvert = new List<double>();
                                larrvert = new List<double>();
                                carrvert = new List<double>();


                                while (sr.Peek() >= 0)
                                {
                                    string[] fields = sr.ReadLine().Split(',');


                                    if (fields[0] != "" && fields[1] != "" && fields[2] != "" && fields[3] != "" && fields[4] != "" && fields[5] != "")
                                    {
                                        if (stklistvert.Count() == 0)
                                        {
                                            stklistvert.Add(fields[0].ToString());

                                            //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                            DateTime tmpdttm = DateTime.Parse(fields[1]) + TimeSpan.Parse(fields[2]);
                                            dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                            harrvert.Add(Convert.ToDouble(fields[3]));
                                            larrvert.Add(Convert.ToDouble(fields[4]));
                                            carrvert.Add(Convert.ToDouble(fields[5]));
                                        }
                                        else
                                            if (string.Equals(stklistvert.Last(), fields[0].ToString()))
                                            {
                                                //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                                DateTime tmpdttm = DateTime.Parse(fields[1]) + TimeSpan.Parse(fields[2]);
                                                dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                                harrvert.Add(Convert.ToDouble(fields[3]));
                                                larrvert.Add(Convert.ToDouble(fields[4]));
                                                carrvert.Add(Convert.ToDouble(fields[5]));
                                            }
                                            else
                                            {
                                                stocks stocksvert = new stocks();
                                                stocksvert.stkname = stklistvert.Last();
                                                stocksvert.dttm = dtarrvert;
                                                stocksvert.high = harrvert;
                                                stocksvert.low = larrvert;
                                                stocksvert.close = carrvert;
                                                stocksobjvert.Add(stocksvert);

                                                stklistvert.Add(fields[0].ToString());
                                                dtarrvert = new List<DateTime>();
                                                harrvert = new List<double>();
                                                larrvert = new List<double>();
                                                carrvert = new List<double>();
                                                //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                                DateTime tmpdttm = DateTime.Parse(fields[1]) + TimeSpan.Parse(fields[2]);
                                                dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                                harrvert.Add(Convert.ToDouble(fields[3]));
                                                larrvert.Add(Convert.ToDouble(fields[4]));
                                                carrvert.Add(Convert.ToDouble(fields[5]));
                                            }

                                    }



                                }

                                stocksvert2 = new stocks();
                                stocksvert2.stkname = stklistvert.Last();
                                stocksvert2.dttm = dtarrvert;
                                stocksvert2.high = harrvert;
                                stocksvert2.low = larrvert;
                                stocksvert2.close = carrvert;
                                stocksobjvert.Add(stocksvert2);

                                sr.Close();
                                stocksobj = stocksobjvert.ToArray();
                                stocksobjvert.Clear();
                                break;

                            # endregion

                            # region Vertical File date + time + bid/ask 

                            case 3:
                                tempvert = sr.ReadLine().Split(',');
                                stocksobjvert = new List<stocks>();
                                stklistvert = new List<string>();
                                dtarrvert = new List<DateTime>();
                                harrvert = new List<double>();
                                larrvert = new List<double>();
                                carrvert = new List<double>();
                                List<double> bidarrvert = new List<double>();
                                List<double> askarrvert = new List<double>();


                                while (sr.Peek() >= 0)
                                {
                                    string[] fields = sr.ReadLine().Split(',');


                                    if (fields[0] != "" && fields[1] != "" && fields[2] != "" && fields[3] != "" && fields[4] != "" && fields[5] != "" && fields[6] != "")
                                    {
                                        if (stklistvert.Count() == 0)
                                        {
                                            stklistvert.Add(fields[0].ToString());

                                            //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                            DateTime tmpdttm = DateTime.Parse(fields[1]);
                                            dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                            harrvert.Add(Convert.ToDouble(fields[2]));
                                            larrvert.Add(Convert.ToDouble(fields[3]));
                                            carrvert.Add(Convert.ToDouble(fields[4]));
                                            if (Convert.ToDouble(fields[5]) == 0)
                                                bidarrvert.Add(Convert.ToDouble(fields[4]));
                                            else bidarrvert.Add(Convert.ToDouble(fields[5]));
                                            if (Convert.ToDouble(fields[6]) == 0)
                                                askarrvert.Add(Convert.ToDouble(fields[4]));
                                            else askarrvert.Add(Convert.ToDouble(fields[6]));                                            
                                        }
                                        else
                                            if (string.Equals(stklistvert.Last(), fields[0].ToString()))
                                            {
                                                //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                                DateTime tmpdttm = DateTime.Parse(fields[1]);
                                                dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                                harrvert.Add(Convert.ToDouble(fields[2]));
                                                larrvert.Add(Convert.ToDouble(fields[3]));
                                                carrvert.Add(Convert.ToDouble(fields[4]));
                                                if (Convert.ToDouble(fields[5]) == 0)
                                                    bidarrvert.Add(Convert.ToDouble(fields[4]));
                                                else bidarrvert.Add(Convert.ToDouble(fields[5]));
                                                if (Convert.ToDouble(fields[6]) == 0)
                                                    askarrvert.Add(Convert.ToDouble(fields[4]));
                                                else askarrvert.Add(Convert.ToDouble(fields[6]));   
                                            }
                                            else
                                            {
                                                stocks stocksvert = new stocks();
                                                stocksvert.stkname = stklistvert.Last();
                                                stocksvert.dttm = dtarrvert;
                                                stocksvert.high = harrvert;
                                                stocksvert.low = larrvert;
                                                stocksvert.close = carrvert;
                                                stocksvert.bid = bidarrvert;
                                                stocksvert.ask = askarrvert;
                                                stocksobjvert.Add(stocksvert);

                                                stklistvert.Add(fields[0].ToString());
                                                dtarrvert = new List<DateTime>();
                                                harrvert = new List<double>();
                                                larrvert = new List<double>();
                                                carrvert = new List<double>();
                                                bidarrvert = new List<double>();
                                                askarrvert = new List<double>();
                                                //DateTime tmpdttm = DateTime.FromOADate(Double.Parse(fields[1]));
                                                DateTime tmpdttm = DateTime.Parse(fields[1]);
                                                dtarrvert.Add(tmpdttm.Date.AddMinutes(Math.Round(tmpdttm.TimeOfDay.TotalMinutes, 0)));
                                                harrvert.Add(Convert.ToDouble(fields[2]));
                                                larrvert.Add(Convert.ToDouble(fields[3]));
                                                carrvert.Add(Convert.ToDouble(fields[4]));
                                                bidarrvert.Add(Convert.ToDouble(fields[5]));
                                                askarrvert.Add(Convert.ToDouble(fields[6]));
                                            }

                                    }



                                }

                                stocksvert2 = new stocks();
                                stocksvert2.stkname = stklistvert.Last();
                                stocksvert2.dttm = dtarrvert;
                                stocksvert2.high = harrvert;
                                stocksvert2.low = larrvert;
                                stocksvert2.close = carrvert;
                                stocksvert2.bid = bidarrvert;
                                stocksvert2.ask = askarrvert;
                                stocksobjvert.Add(stocksvert2);

                                sr.Close();
                                stocksobj = stocksobjvert.ToArray();
                                stocksobjvert.Clear();
                                break;

                            # endregion

                            default:
                                break;
                        }

                        # endregion


                        lbDisplay.BringToFront();
                        lbDisplay.Items.Add(DateTime.Now.ToLongTimeString() + " Data Loaded : " + Path.GetFileName(openFileDialog1.FileName) + " : " + watcher.ElapsedMilliseconds + " ms");
                        lbDisplay.SelectedIndex = lbDisplay.Items.Count - 1;
                        lbDisplay.SelectedIndex = -1;
                    }
                }

        }

        private void btnRunStrat_Click(object sender, EventArgs e)
        {
            if (cbSelectStrategy.SelectedItem == null)
            {
                MessageBox.Show("Select Strategy");                
            }
            else if (stocksobj != null)
            {
                Stopwatch watcher = new Stopwatch();
                watcher.Start();

                if (cbSelectStrategy.SelectedItem == "OpeningGap")
                    OpeningGap();

                if (cbSelectStrategy.SelectedItem == "OpeningGapContra")
                    OpeningGapContra();

                if (cbSelectStrategy.SelectedItem == "VPOC")
                    VPOC();

                lbDisplay.BringToFront();
                lbDisplay.Items.Add(DateTime.Now + " Strategy Run Complete : " + watcher.ElapsedMilliseconds + " ms");
                lbDisplay.SelectedIndex = lbDisplay.Items.Count - 1;
                lbDisplay.SelectedIndex = -1;
            }
            else
                MessageBox.Show("Load Data First");

        }

        private void VPOC()
        {
            TimeSpan TrdStartTime = TimeSpan.Parse(dgParams.Rows[0].Cells[1].Value.ToString());
            TimeSpan TrdEndTime = TimeSpan.Parse(dgParams.Rows[1].Cells[1].Value.ToString());
            TimeSpan TrdExitTime = TimeSpan.Parse(dgParams.Rows[2].Cells[1].Value.ToString());
            TimeSpan exittm = TimeSpan.Parse(dgParams.Rows[3].Cells[1].Value.ToString());
            double sperc = Convert.ToDouble(dgParams.Rows[4].Cells[1].Value);
            int lbk = Convert.ToInt32(dgParams.Rows[5].Cells[1].Value);
            double cutoff = Convert.ToDouble(dgParams.Rows[6].Cells[1].Value);
            double sco = Convert.ToDouble(dgParams.Rows[7].Cells[1].Value);
            double sl = Convert.ToDouble(dgParams.Rows[8].Cells[1].Value);
            double pb = Convert.ToDouble(dgParams.Rows[9].Cells[1].Value);

            daydetails = new List<dailypnl>();

            alldates = new List<DateTime>();

            for (int i = 0; i < stocksobj2.Count(); i++)
            {
                GC.Collect();

                List<DateTime> unqdts = new List<DateTime>();
                double[] enpx = new double[stocksobj2[i].dttm.Count()];
                double[] expx = new double[stocksobj2[i].dttm.Count()];
                double[] trdmtm = new double[stocksobj2[i].dttm.Count()];
                double[] slpx = new double[stocksobj2[i].dttm.Count()];
                double[] pbpx = new double[stocksobj2[i].dttm.Count()];
                int[] en = new int[stocksobj2[i].dttm.Count()];
                int[] ex = new int[stocksobj2[i].dttm.Count()];
                int[] np = new int[stocksobj2[i].dttm.Count()];
                stocksobj2[i].entm = new List<DateTime>();
                stocksobj2[i].extm = new List<DateTime>();
                stocksobj2[i].entryprice = new List<double>();
                stocksobj2[i].exitprice = new List<double>();
                stocksobj2[i].pnl = new List<double>();

                double[] ltp = stocksobj2[i].close.ToArray();
                double[] high = stocksobj2[i].high.ToArray();
                double[] low = stocksobj2[i].low.ToArray();
                double[] volume = stocksobj2[i].volume.ToArray();

                double pricepoints = 0;
                double triggerhigh = 99999999999;
                double triggerlow = -99999999999;

                double ctr1 = 0;
                double ctr2 = 0;
                double ctr3 = 0;

                double sig = 0;

                for (int j = 0; j < stocksobj2[i].dttm.Count(); j++)
                {
                    sig = 0;

                    if (j == 0)
                    {
                        unqdts.Add(stocksobj2[i].dttm[j].Date);
                    }

                    if (j == stocksobj[i].dttm.Count() - 1)
                    {
                        np[j] = 0;
                        ex[j] = -np[j - 1];
                        expx[j] = np[j - 1] == 0 ? 0 : stocksobj[i].close[j];

                        if (np[j - 1] != 0)
                        {
                            trdmtm[j] = np[j - 1] * (expx[j] / enpx[j - 1] - 1);
                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                            stocksobj[i].exitprice.Add(expx[j]);
                            stocksobj[i].pnl.Add(trdmtm[j]);
                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                        }

                    }

                    if (stocksobj2[i].dttm[j].Date != stocksobj2[i].dttm[j - 1].Date)
                    {
                        ctr1 = 1;
                        ctr2 = 1;
                        ctr3 = 1;
                        double[] p_dat = UF.GetRange(ltp, j - lbk, j - 1);
                        double[] v_dat = UF.GetRange(volume, j - lbk, j - 1);

                        double max = p_dat.Max();
                        double min = p_dat.Min();
                        double range = max - min;
                        int segment = Convert.ToInt32(sperc * range);
                        int seg = 0;
                        if (segment > 2)
                            seg = segment;
                        else
                            seg = 2;
                        double inc = range / seg;
                        double[] p1 = new double[seg];
                        double[] p2 = new double[seg];

                        p1[0] = min;
                        p2[0] = min + inc;

                        for (int k = 1; k < seg; k++)
                        {
                            p1[k] = p1[k - 1] + inc;
                            p2[k] = p2[k - 1] + inc;
                        }

                        double[] v_hist = new double[seg];

                        for (int k = 0; k < seg; k++)
                        {
                            double v_sum = 0;
                            for (int l = 0; l < (lbk / 1); l++)
                            {
                                if (p_dat[l] >= p1[k] && p_dat[l] < p2[k])
                                    v_sum = v_sum + v_dat[l];
                            }
                            v_hist[k] = v_sum;
                        }

                        int idx = Array.IndexOf(v_hist, v_hist.Max());

                        pricepoints = (p1[idx] + p2[idx]) / 2;

                        double[] std_data = UF.GetRange(ltp, j - lbk, j - 1);
                        double tmp = Math.Max(UF.StandardDeviation(std_data) / std_data.Average(), sco);

                        triggerhigh = ((1 + (cutoff * tmp)) * pricepoints);
                        triggerlow = ((1 - (cutoff * tmp)) * pricepoints);
                        
                    }

                    if (stocksobj2[i].dttm[j].TimeOfDay < TrdStartTime)
                    {
                        ctr1++;

                        if (ltp[j] < triggerhigh)
                            ctr2++;

                        if (ltp[j] > triggerlow)
                            ctr3++;
                    }

                    if (stocksobj2[i].dttm[j].TimeOfDay >= TrdStartTime)
                    {
                        if (np[j - 1] == 0 && stocksobj[i].dttm[j].TimeOfDay <= TrdEndTime && ctr1 == ctr2 && high[j] >= triggerhigh)
                        {
                            en[j] = 1;
                            enpx[j] = triggerhigh;
                            
                            slpx[j] = enpx[j] * (1 + sl);
                            pbpx[j] = enpx[j] * (1 - pb);
                            stocksobj[i].entm.Add(stocksobj[i].dttm[j]);
                            stocksobj[i].entryprice.Add(enpx[j]);

                            sig = 1;
                        }

                        if (np[j - 1] == 0 && stocksobj[i].dttm[j].TimeOfDay <= TrdEndTime && ctr1 == ctr3 && low[j] <= triggerlow)
                        {
                            en[j] = -1;
                            enpx[j] = triggerlow;

                            slpx[j] = enpx[j] * (1 + sl);
                            pbpx[j] = enpx[j] * (1 - pb);
                            stocksobj[i].entm.Add(stocksobj[i].dttm[j]);
                            stocksobj[i].entryprice.Add(enpx[j]);

                            sig = 1;
                        }

                        if (np[j - 1] == 1 && stocksobj2[i].low[j] <= slpx[j - 1])
                        {
                            expx[j] = slpx[j - 1];
                            ex[j] = -1;
                            en[j] = 0;
                            trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                            stocksobj2[i].extm.Add(stocksobj[i].dttm[j]);
                            stocksobj2[i].exitprice.Add(expx[j]);
                            stocksobj2[i].pnl.Add(trdmtm[j]);
                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));

                            sig = 1;
                        }
                        
                        if (np[j - 1] == 1 && stocksobj[i].high[j] > pbpx[j - 1])
                        {
                            expx[j] = pbpx[j - 1];
                            ex[j] = -1;
                            en[j] = 0;
                            trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                            stocksobj[i].exitprice.Add(expx[j]);
                            stocksobj[i].pnl.Add(trdmtm[j]);
                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));

                            sig = 1;
                        }

                        if (np[j - 1] == -1 && stocksobj2[i].low[j] <= slpx[j - 1])
                        {
                            expx[j] = slpx[j - 1];
                            ex[j] = -1;
                            en[j] = 0;
                            trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                            stocksobj2[i].extm.Add(stocksobj[i].dttm[j]);
                            stocksobj2[i].exitprice.Add(expx[j]);
                            stocksobj2[i].pnl.Add(trdmtm[j]);
                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));

                            sig = 1;
                        }

                        if (np[j - 1] == -1 && stocksobj[i].high[j] > pbpx[j - 1])
                        {
                            expx[j] = pbpx[j - 1];
                            ex[j] = -1;
                            en[j] = 0;
                            trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                            stocksobj[i].exitprice.Add(expx[j]);
                            stocksobj[i].pnl.Add(trdmtm[j]);
                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));

                            sig = 1;
                        }

                        if(sig == 0)
                        {
                            enpx[j] = enpx[j - 1];
                            slpx[j] = slpx[j - 1];
                            pbpx[j] = pbpx[j - 1];
                        }

                    }

                    np[j] = np[j - 1] + en[j] + ex[j];
                               
                }
                
            
            }


        }

        private void OpeningGap()
        {
            int numdays = Convert.ToInt32(dgParams.Rows[0].Cells[1].Value);
            TimeSpan bodtm = TimeSpan.Parse(dgParams.Rows[1].Cells[1].Value.ToString());
            TimeSpan highlowtm = TimeSpan.Parse(dgParams.Rows[2].Cells[1].Value.ToString());
            TimeSpan lastentrytm = TimeSpan.Parse(dgParams.Rows[3].Cells[1].Value.ToString());
            TimeSpan exittm = TimeSpan.Parse(dgParams.Rows[4].Cells[1].Value.ToString());
            double sl = Convert.ToDouble(dgParams.Rows[5].Cells[1].Value);
            double pb = Convert.ToDouble(dgParams.Rows[6].Cells[1].Value);
            double maxog = Convert.ToDouble(dgParams.Rows[7].Cells[1].Value);
            double mult = Convert.ToDouble(dgParams.Rows[8].Cells[1].Value);
            double highlowband = Convert.ToDouble(dgParams.Rows[9].Cells[1].Value);
            bool usebidask = Convert.ToInt16(dgParams.Rows[10].Cells[1].Value) == 0 ? false : true;
            
            daydetails = new List<dailypnl>();

            alldates = new List<DateTime>();
            for (int i = 0; i < stocksobj.Count(); i++)
            //Parallel.For(0, stocksobj.Count(), i =>
            {
                GC.Collect();
                List<DateTime> unqdts = new List<DateTime>();
                List<double> eodpx = new List<double>();
                List<double> bodpx = new List<double>();
                List<double> histog = new List<double>();
                //List<double> dailyog = new List<double>();
                double prevclose = 0, crhigh = double.MinValue, crlow = double.MaxValue, crog = 0, histavg = 0;
                double[] enpx = new double[stocksobj[i].dttm.Count()];
                double[] expx = new double[stocksobj[i].dttm.Count()];
                double[] trdmtm = new double[stocksobj[i].dttm.Count()];
                double[] slpx = new double[stocksobj[i].dttm.Count()];
                double[] pbpx = new double[stocksobj[i].dttm.Count()];
                int[] en = new int[stocksobj[i].dttm.Count()];
                int[] ex = new int[stocksobj[i].dttm.Count()];
                int[] np = new int[stocksobj[i].dttm.Count()];
                stocksobj[i].entm = new List<DateTime>();
                stocksobj[i].extm = new List<DateTime>();
                stocksobj[i].entryprice = new List<double>();
                stocksobj[i].exitprice = new List<double>();
                stocksobj[i].pnl = new List<double>();
                stocksobj[i].avgog = new List<double>();
                bool daytrd = false;
                List<double> lastnclose = new List<double>();
                double biasval = 0;

                for (int j = 0; j < stocksobj[i].dttm.Count(); j++)
                {
                    if (j == 0)
                    {
                        unqdts.Add(stocksobj[i].dttm[j].Date);
                    }
                    else
                        if (j == stocksobj[i].dttm.Count() - 1)
                        {
                            np[j] = 0;
                            ex[j] = -np[j - 1];
                            expx[j] = np[j - 1] == 0 ? 0 : stocksobj[i].close[j];

                            if (np[j - 1] != 0)
                            {
                                trdmtm[j] = np[j - 1] * (expx[j] / enpx[j - 1] - 1);
                                stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                stocksobj[i].exitprice.Add(expx[j]);
                                stocksobj[i].pnl.Add(trdmtm[j]);
                                daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                            }

                        }
                        else
                        {
                            if (stocksobj[i].dttm[j].Date != stocksobj[i].dttm[j - 1].Date)
                            {
                                eodpx.Add(stocksobj[i].close[j - 1]);
                                unqdts.Add(stocksobj[i].dttm[j].Date);
                                prevclose = stocksobj[i].close[j - 1];
                                crog = 0;
                                crhigh = stocksobj[i].high[j];
                                crlow = stocksobj[i].low[j];
                                daytrd = false;
                                //crhigh = 0;
                                //crlow = double.MaxValue;
                                if (eodpx.Count > numdays)
                                {
                                    lastnclose = eodpx.Skip(eodpx.Count - numdays).ToList();                                    
                                }
                            }
                            else
                            {
                                if (stocksobj[i].dttm[j].TimeOfDay <= highlowtm)
                                {
                                    crhigh = Math.Max(crhigh, stocksobj[i].high[j]);
                                    crlow = Math.Min(crlow, stocksobj[i].low[j]);
                                    if (stocksobj[i].dttm[j].TimeOfDay == bodtm || (stocksobj[i].dttm[j].TimeOfDay > bodtm && stocksobj[i].dttm[j - 1].TimeOfDay < bodtm))
                                    {
                                        bodpx.Add(stocksobj[i].close[j]);
                                        crog = prevclose == 0 ? 0 : stocksobj[i].close[j] / prevclose - 1;
                                        if (histog.Count > numdays)
                                        {
                                            double tempavg = histog.Skip(histog.Count - numdays).Average();

                                            //if (tempavg < 0.01)
                                            //    histavg = 0.01;
                                            //else if (tempavg < 0.015)
                                            //    histavg = 0.015;
                                            //else histavg = 0.02;

                                            //if (tempavg > 0.02)
                                            //    histavg = 0.02;
                                            //else if (tempavg > 0.015)
                                            //    histavg = 0.015;                                            
                                            //else histavg = tempavg;
                                            
                                            histavg = tempavg;
                                            biasval = lastnclose == null ? 0 : stocksobj[i].close[j] / lastnclose.Average() - 1;
                                            
                                        }
                                        histog.Add(Math.Abs(crog));
                                    }
                                }
                                else
                                {
                                    if (np[j - 1] == 1 && stocksobj[i].low[j] <= slpx[j - 1])
                                    {
                                        expx[j] = stocksobj[i].high[j] <= slpx[j - 1] ? stocksobj[i].high[j] : slpx[j - 1];
                                        //expx[j] = usebidask ? stocksobj[i].bid[j] : slpx[j - 1];
                                        //expx[j] = usebidask ? stocksobj[i].bid[j] : stocksobj[i].close[j];
                                        ex[j] = -1;
                                        en[j] = 0;
                                        trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                                        stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                        stocksobj[i].exitprice.Add(expx[j]);
                                        stocksobj[i].pnl.Add(trdmtm[j]);
                                        daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                    }
                                    else if (np[j - 1] == 1 && stocksobj[i].high[j] > pbpx[j - 1])
                                    {
                                        expx[j] = stocksobj[i].low[j] >= pbpx[j - 1] ? stocksobj[i].low[j] : pbpx[j - 1];
                                        //expx[j] = usebidask ? stocksobj[i].bid[j] : pbpx[j - 1];
                                        //expx[j] = usebidask ? stocksobj[i].bid[j] : stocksobj[i].close[j];
                                        ex[j] = -1;
                                        en[j] = 0;
                                        trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                                        stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                        stocksobj[i].exitprice.Add(expx[j]);
                                        stocksobj[i].pnl.Add(trdmtm[j]);
                                        daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                    }
                                    else
                                        if (np[j - 1] == -1 && stocksobj[i].high[j] >= slpx[j - 1])
                                        {
                                            expx[j] = stocksobj[i].low[j] >= slpx[j - 1] ? stocksobj[i].low[j] : slpx[j - 1];
                                            //expx[j] = usebidask ? stocksobj[i].ask[j] : slpx[j - 1];
                                            //expx[j] = usebidask ? stocksobj[i].ask[j] : stocksobj[i].close[j];
                                            ex[j] = 1;
                                            en[j] = 0;
                                            trdmtm[j] = 1 - expx[j] / enpx[j - 1];
                                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                            stocksobj[i].exitprice.Add(expx[j]);
                                            stocksobj[i].pnl.Add(trdmtm[j]);
                                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                        }
                                        else if (np[j - 1] == -1 && stocksobj[i].low[j] < pbpx[j - 1])
                                        {
                                            expx[j] = stocksobj[i].high[j] <= pbpx[j - 1] ? stocksobj[i].high[j] : pbpx[j - 1];
                                            //expx[j] = usebidask ? stocksobj[i].ask[j] : pbpx[j - 1];
                                            //expx[j] = usebidask ? stocksobj[i].ask[j] : stocksobj[i].close[j];
                                            ex[j] = 1;
                                            en[j] = 0;
                                            trdmtm[j] = 1 - expx[j] / enpx[j - 1];
                                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                            stocksobj[i].exitprice.Add(expx[j]);
                                            stocksobj[i].pnl.Add(trdmtm[j]);
                                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                        }
                                        else
                                            if (np[j - 1] != 0 && (stocksobj[i].dttm[j].TimeOfDay >= exittm || stocksobj[i].dttm[j].Date != stocksobj[i].dttm[j + 1].Date))
                                            {
                                                expx[j] = usebidask ? (np[j - 1] == 1 ? stocksobj[i].bid[j] : stocksobj[i].ask[j]) : stocksobj[i].close[j];
                                                trdmtm[j] = np[j - 1] * (expx[j] / enpx[j - 1] - 1);
                                                ex[j] = -np[j - 1];
                                                en[j] = 0;
                                                stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                                stocksobj[i].exitprice.Add(expx[j]);
                                                stocksobj[i].pnl.Add(trdmtm[j]);
                                                daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                            }
                                            else
                                                if (np[j - 1] == 0 && Math.Abs(crog) > histavg * mult && histavg > 0 && Math.Abs(crog) < maxog && crog > 0 && stocksobj[i].high[j] >= crhigh  
                                                    && stocksobj[i].dttm[j].TimeOfDay <= lastentrytm && !daytrd)
                                                {
                                                    if (stocksobj[i].extm.Count != 0)
                                                        if (stocksobj[i].extm.Last().Date == stocksobj[i].dttm[j].Date)
                                                            continue;
                                                    en[j] = 1;
                                                    enpx[j] = stocksobj[i].low[j] >= crhigh ? stocksobj[i].low[j] : crhigh;
                                                    //enpx[j] = crhigh;
                                                    //enpx[j] = usebidask ? stocksobj[i].ask[j] : stocksobj[i].close[j];
                                                    //double modsl = Math.Max(sl, histavg * highlowband);
                                                    //double modpb = Math.Max(pb, histavg * highlowband * 2);
                                                    slpx[j] = enpx[j] * (1 - sl);                                                    
                                                    pbpx[j] = enpx[j] * (1 + pb);
                                                    stocksobj[i].entm.Add(stocksobj[i].dttm[j]);
                                                    stocksobj[i].entryprice.Add(enpx[j]);
                                                    stocksobj[i].avgog.Add(histavg);
                                                    daytrd = true;
                                                }
                                                else
                                                    if (np[j - 1] == 0 && Math.Abs(crog) > histavg * mult && histavg > 0 && Math.Abs(crog) < maxog && crog < 0 && stocksobj[i].low[j] <= crlow
                                                        && stocksobj[i].dttm[j].TimeOfDay <= lastentrytm && !daytrd)
                                                    {
                                                        if (stocksobj[i].extm.Count != 0)
                                                            if (stocksobj[i].extm.Last().Date == stocksobj[i].dttm[j].Date)
                                                                continue;
                                                        en[j] = -1;
                                                        enpx[j] = stocksobj[i].high[j] <= crlow ? stocksobj[i].high[j] : crlow;
                                                        //enpx[j] = crlow;
                                                        //enpx[j] = usebidask ? stocksobj[i].bid[j] : stocksobj[i].close[j];
                                                        //double modsl = Math.Max(sl, histavg * highlowband);
                                                        //double modpb = Math.Max(pb, histavg * highlowband * 2);
                                                        slpx[j] = enpx[j] * (1 + sl);
                                                        pbpx[j] = enpx[j] * (1 - pb);
                                                        stocksobj[i].entm.Add(stocksobj[i].dttm[j]);
                                                        stocksobj[i].entryprice.Add(enpx[j]);
                                                        stocksobj[i].avgog.Add(histavg);
                                                        daytrd = true;
                                                    }
                                                    else
                                                    {
                                                        enpx[j] = enpx[j - 1];
                                                        slpx[j] = slpx[j - 1];
                                                        pbpx[j] = pbpx[j - 1];
                                                    }

                                    np[j] = np[j - 1] + en[j] + ex[j];

                                }
                            }
                        }
                }
                stocksobj[i].tottrds = ex.Where(x => x != 0).Count();
                stocksobj[i].totmtm = trdmtm.Sum();

                alldates = alldates.Union(unqdts).OrderBy(x => x).Distinct();
            }//); // Parallel For

            //daydetails = daydetails.OrderBy(x => x.trddt).ToList();
            PopulateResults();
            
        }

        private void OpeningGapContra()
        {
            int numdays = Convert.ToInt32(dgParams.Rows[0].Cells[1].Value);
            TimeSpan bodtm = TimeSpan.Parse(dgParams.Rows[1].Cells[1].Value.ToString());
            TimeSpan highlowtm = TimeSpan.Parse(dgParams.Rows[2].Cells[1].Value.ToString());
            TimeSpan lastentrytm = TimeSpan.Parse(dgParams.Rows[3].Cells[1].Value.ToString());
            TimeSpan exittm = TimeSpan.Parse(dgParams.Rows[4].Cells[1].Value.ToString());
            double sl = Convert.ToDouble(dgParams.Rows[5].Cells[1].Value);
            double pb = Convert.ToDouble(dgParams.Rows[6].Cells[1].Value);
            double maxog = Convert.ToDouble(dgParams.Rows[7].Cells[1].Value);
            double mult = Convert.ToDouble(dgParams.Rows[8].Cells[1].Value);
            double highlowband = Convert.ToDouble(dgParams.Rows[9].Cells[1].Value);

            daydetails = new List<dailypnl>();

            alldates = new List<DateTime>();
            for (int i = 0; i < stocksobj.Count(); i++)
            //Parallel.For(0, stocksobj.Count(), i =>
            {
                GC.Collect();
                List<DateTime> unqdts = new List<DateTime>();
                List<double> eodpx = new List<double>();
                List<double> bodpx = new List<double>();
                List<double> histog = new List<double>();
                //List<double> dailyog = new List<double>();
                double prevclose = 0, crhigh = double.MinValue, crlow = double.MaxValue, crog = 0, histavg = 0;
                double[] enpx = new double[stocksobj[i].dttm.Count()];
                double[] expx = new double[stocksobj[i].dttm.Count()];
                double[] trdmtm = new double[stocksobj[i].dttm.Count()];
                double[] slpx = new double[stocksobj[i].dttm.Count()];
                double[] pbpx = new double[stocksobj[i].dttm.Count()];
                int[] en = new int[stocksobj[i].dttm.Count()];
                int[] ex = new int[stocksobj[i].dttm.Count()];
                int[] np = new int[stocksobj[i].dttm.Count()];
                stocksobj[i].entm = new List<DateTime>();
                stocksobj[i].extm = new List<DateTime>();
                stocksobj[i].entryprice = new List<double>();
                stocksobj[i].exitprice = new List<double>();
                stocksobj[i].pnl = new List<double>();
                bool daytrd = false;


                for (int j = 0; j < stocksobj[i].dttm.Count(); j++)
                {
                    if (j == 0)
                    {
                        unqdts.Add(stocksobj[i].dttm[j].Date);
                    }
                    else 
                        if (j == stocksobj[i].dttm.Count() - 1)
                        {
                            np[j] = 0;
                            ex[j] = -np[j - 1];
                            expx[j] = np[j - 1] == 0 ? 0 : stocksobj[i].close[j];
                            if (np[j - 1] != 0)
                            {
                                trdmtm[j] = np[j - 1] * (expx[j] / enpx[j - 1] - 1);
                                stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                stocksobj[i].exitprice.Add(expx[j]);
                                stocksobj[i].pnl.Add(trdmtm[j]);
                                daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                            }

                        }
                        else
                        {
                            # region Computation for all except last tick in array

                            if (stocksobj[i].dttm[j].Date != stocksobj[i].dttm[j - 1].Date)
                            {
                                eodpx.Add(stocksobj[i].close[j - 1]);
                                unqdts.Add(stocksobj[i].dttm[j].Date);
                                prevclose = stocksobj[i].close[j - 1];
                                crog = 0;
                                crhigh = stocksobj[i].high[j];
                                crlow = stocksobj[i].low[j];
                                daytrd = false;
                                //crhigh = 0;
                                //crlow = double.MaxValue;
                            }
                            else
                            {
                                # region Computation for all except last tick of day

                                if (stocksobj[i].dttm[j].TimeOfDay <= highlowtm)
                                {
                                    # region Before High Low Record Time

                                    crhigh = Math.Max(crhigh, stocksobj[i].high[j]);
                                    crlow = Math.Min(crlow, stocksobj[i].low[j]);
                                    if (stocksobj[i].dttm[j].TimeOfDay == bodtm || (stocksobj[i].dttm[j].TimeOfDay > bodtm && stocksobj[i].dttm[j - 1].TimeOfDay < bodtm))
                                    {
                                        bodpx.Add(stocksobj[i].close[j]);
                                        crog = prevclose == 0 ? 0 : stocksobj[i].close[j] / prevclose - 1;
                                        if (histog.Count > numdays)
                                        {
                                            double tempavg = histog.Skip(histog.Count - numdays).Average();
                                            //if (tempavg < 0.01)
                                            //    histavg = 0.01;
                                            //else if (tempavg < 0.015)
                                            //    histavg = 0.015;
                                            //else histavg = 0.02;
                                            histavg = tempavg;
                                        }
                                        histog.Add(Math.Abs(crog));
                                    }

                                    # endregion
                                }
                                else
                                {
                                    if (np[j - 1] == 1 && stocksobj[i].low[j] <= slpx[j - 1])
                                    {
                                        expx[j] = stocksobj[i].high[j] <= slpx[j - 1] ? stocksobj[i].high[j] : slpx[j - 1];
                                        //expx[j] = stocksobj[i].close[j];
                                        //expx[j] = slpx[j - 1];
                                        ex[j] = -1;
                                        en[j] = 0;
                                        trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                                        stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                        stocksobj[i].exitprice.Add(expx[j]);
                                        stocksobj[i].pnl.Add(trdmtm[j]);
                                        daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                    }
                                    else if (np[j - 1] == 1 && stocksobj[i].high[j] > pbpx[j - 1])
                                    {
                                        expx[j] = stocksobj[i].low[j] >= pbpx[j - 1] ? stocksobj[i].low[j] : pbpx[j - 1];
                                        //expx[j] = stocksobj[i].close[j];
                                        //expx[j] = pbpx[j - 1];
                                        ex[j] = -1;
                                        en[j] = 0;
                                        trdmtm[j] = expx[j] / enpx[j - 1] - 1;
                                        stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                        stocksobj[i].exitprice.Add(expx[j]);
                                        stocksobj[i].pnl.Add(trdmtm[j]);
                                        daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                    }
                                    else
                                        if (np[j - 1] == -1 && stocksobj[i].high[j] >= slpx[j - 1])
                                        {
                                            expx[j] = stocksobj[i].low[j] >= slpx[j - 1] ? stocksobj[i].low[j] : slpx[j - 1];
                                            //expx[j] = stocksobj[i].close[j];
                                            //expx[j] = slpx[j - 1];
                                            ex[j] = 1;
                                            en[j] = 0;
                                            trdmtm[j] = 1 - expx[j] / enpx[j - 1];
                                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                            stocksobj[i].exitprice.Add(expx[j]);
                                            stocksobj[i].pnl.Add(trdmtm[j]);
                                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                        }
                                        else if (np[j - 1] == -1 && stocksobj[i].low[j] < pbpx[j - 1])
                                        {
                                            expx[j] = stocksobj[i].high[j] <= pbpx[j - 1] ? stocksobj[i].high[j] : pbpx[j - 1];
                                            //expx[j] = stocksobj[i].close[j];
                                            //expx[j] = pbpx[j - 1];
                                            ex[j] = 1;
                                            en[j] = 0;
                                            trdmtm[j] = 1 - expx[j] / enpx[j - 1];
                                            stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                            stocksobj[i].exitprice.Add(expx[j]);
                                            stocksobj[i].pnl.Add(trdmtm[j]);
                                            daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                        }
                                        else
                                            if (np[j - 1] != 0 && (stocksobj[i].dttm[j].TimeOfDay >= exittm || stocksobj[i].dttm[j].Date != stocksobj[i].dttm[j + 1].Date))
                                            {
                                                expx[j] = stocksobj[i].close[j];
                                                trdmtm[j] = np[j - 1] * (expx[j] / enpx[j - 1] - 1);
                                                ex[j] = -np[j - 1];
                                                en[j] = 0;
                                                stocksobj[i].extm.Add(stocksobj[i].dttm[j]);
                                                stocksobj[i].exitprice.Add(expx[j]);
                                                stocksobj[i].pnl.Add(trdmtm[j]);
                                                daydetails.Add(new dailypnl(stocksobj[i].dttm[j].Date, trdmtm[j]));
                                            }
                                            else
                                                if (np[j - 1] == 0 && Math.Abs(crog) > histavg * mult && histavg > 0 && Math.Abs(crog) < maxog && crog > 0 &&
                                                    stocksobj[i].high[j] >= crhigh && stocksobj[i].dttm[j].TimeOfDay <= lastentrytm && !daytrd && crlow > prevclose )
                                                //if (np[j - 1] == 0 && Math.Abs(crog) < maxog && stocksobj[i].high[j] >= crhigh && stocksobj[i].dttm[j].TimeOfDay <= lastentrytm &&
                                                    //!daytrd && (crhigh - crlow) * 2 /(crhigh + crlow) > highlowband)
                                                {
                                                    if (stocksobj[i].extm.Count != 0)
                                                        if (stocksobj[i].extm.Last().Date == stocksobj[i].dttm[j].Date)
                                                            continue;
                                                    en[j] = 1;
                                                    //enpx[j] = stocksobj[i].close[j];
                                                    //enpx[j] = crhigh;
                                                    enpx[j] = stocksobj[i].low[j] >= crhigh ? stocksobj[i].low[j] : crhigh;
                                                    //slpx[j] = Math.Min(crlow, enpx[j] * (1 - sl));
                                                    //double modsl = Math.Max(sl, histavg * highlowband);
                                                    //double modpb = Math.Max(pb, histavg * highlowband * 2);
                                                    slpx[j] = enpx[j] * (1 - sl);
                                                    pbpx[j] = enpx[j] * (1 + pb);
                                                    stocksobj[i].entm.Add(stocksobj[i].dttm[j]);
                                                    stocksobj[i].entryprice.Add(enpx[j]);
                                                    daytrd = true;
                                                }
                                                else
                                                    if (np[j - 1] == 0 && Math.Abs(crog) > histavg * mult && histavg > 0 && Math.Abs(crog) < maxog && crog < 0 &&
                                                    stocksobj[i].low[j] <= crlow && stocksobj[i].dttm[j].TimeOfDay <= lastentrytm && !daytrd && crhigh > prevclose )
                                                    //if (np[j - 1] == 0 && Math.Abs(crog) < maxog && stocksobj[i].low[j] <= crlow && stocksobj[i].dttm[j].TimeOfDay <= lastentrytm &&
                                                        //!daytrd && (crhigh - crlow) * 2 / (crhigh + crlow) > highlowband)
                                                    {
                                                        if (stocksobj[i].extm.Count != 0)
                                                            if (stocksobj[i].extm.Last().Date == stocksobj[i].dttm[j].Date)
                                                                continue;
                                                        en[j] = -1;
                                                        //enpx[j] = stocksobj[i].close[j];
                                                        //enpx[j] = crlow;
                                                        enpx[j] = stocksobj[i].high[j] <= crlow ? stocksobj[i].high[j] : crlow;
                                                        //slpx[j] = Math.Max(crhigh, enpx[j] * (1 + sl));
                                                        //double modsl = Math.Max(sl, histavg * highlowband);
                                                        //double modpb = Math.Max(pb, histavg * highlowband * 2);
                                                        slpx[j] = enpx[j] * (1 + sl);
                                                        pbpx[j] = enpx[j] * (1 - pb);
                                                        stocksobj[i].entm.Add(stocksobj[i].dttm[j]);
                                                        stocksobj[i].entryprice.Add(enpx[j]);
                                                        daytrd = true;
                                                    }
                                                    else
                                                    {
                                                        if(stocksobj[i].entm.Count != 0)
                                                        {
                                                            double tmintrd = Math.Max(stocksobj[i].dttm[j].Subtract(stocksobj[i].entm.Last()).TotalMinutes, 0);
                                                            enpx[j] = enpx[j - 1];
                                                            //slpx[j] = slpx[j - 1];
                                                            slpx[j] = enpx[j] * (1 - (sl - tmintrd / 10000) * np[j - 1]);
                                                            pbpx[j] = enpx[j] * (1 + (pb - tmintrd / 10000) * np[j - 1]);
                                                            //pbpx[j] = pbpx[j - 1];
                                                        }
                                                        else
                                                        {
                                                            enpx[j] = enpx[j - 1];                                                            
                                                            slpx[j] = slpx[j - 1];
                                                            pbpx[j] = pbpx[j - 1];
                                                        }
                                                        
                                                        
                                                        
                                                    }

                                    np[j] = np[j - 1] + en[j] + ex[j];

                                }
                                # endregion
                            }
                            # endregion
                        }
                }
                stocksobj[i].tottrds = ex.Where(x => x != 0).Count();
                stocksobj[i].totmtm = trdmtm.Sum();

                alldates = alldates.Union(unqdts).OrderBy(x => x).Distinct();
            }//); // Parallel For

            //daydetails = daydetails.OrderBy(x => x.trddt).ToList();
            PopulateResults();

        }

        private void cbSelectStrategy_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbSelectStrategy.SelectedItem == "OpeningGap")
            {
                dgParams.Columns.Clear();
                dgParams.Rows.Clear();
                dgParams.ColumnCount = 2;
                dgParams.Columns[0].ReadOnly = true;


                dgParams.Rows.Add("Number of Days for avg", 10);
                dgParams.Rows.Add("BOD Time", "09:15:00");
                dgParams.Rows.Add("High/Low Record Time", "09:30:00");
                dgParams.Rows.Add("Last Entry Time", "14:00:00");
                dgParams.Rows.Add("Exit Time", "14:30:00");
                dgParams.Rows.Add("Stop Loss %", 0.02);
                dgParams.Rows.Add("Profit Book %", 0.05);
                dgParams.Rows.Add("Max OG", 0.10);
                dgParams.Rows.Add("Multiplier", 1.0);
                dgParams.Rows.Add("HiLo Band", 0.01);
                dgParams.Rows.Add("Use Bid/Ask", 0);
            }

            if (cbSelectStrategy.SelectedItem == "OpeningGapContra")
            {
                dgParams.Columns.Clear();
                dgParams.Rows.Clear();
                dgParams.ColumnCount = 2;
                dgParams.Columns[0].ReadOnly = true;


                dgParams.Rows.Add("Number of Days for avg", 10);
                dgParams.Rows.Add("BOD Time", "09:15:00");
                dgParams.Rows.Add("High/Low Record Time", "09:30:00");
                dgParams.Rows.Add("Last Entry Time", "14:00:00");
                dgParams.Rows.Add("Exit Time", "14:30:00");
                dgParams.Rows.Add("Stop Loss %", 0.02);
                dgParams.Rows.Add("Profit Book %", 0.05);
                dgParams.Rows.Add("Max OG", 0.10);
                dgParams.Rows.Add("Multiplier", 1.0);
                dgParams.Rows.Add("HiLo Band", 0.01);
                dgParams.Rows.Add("Use Bid/Ask", 0);
            }

            if (cbSelectStrategy.SelectedItem == "VPOC")
            {
                dgParams.Columns.Clear();
                dgParams.Rows.Clear();
                dgParams.ColumnCount = 2;
                dgParams.Columns[0].ReadOnly = true;


                dgParams.Rows.Add("Start Time", "09:15:00");
                dgParams.Rows.Add("Last Entry Time", "14:00:00");
                dgParams.Rows.Add("Exit Time", "15:00:00");
                dgParams.Rows.Add("SegmentPerc", 0.3);
                dgParams.Rows.Add("Lookback", 130);
                dgParams.Rows.Add("CutOff", 4);
                dgParams.Rows.Add("StDev CutOff", 0.001);
                dgParams.Rows.Add("Stop Loss %", 0.02);
                dgParams.Rows.Add("Profit Book %", 0.05);
                
            }
        }

        private void PopulateResults()
        {
            dgDates.Rows.Clear();
            dgDates.Columns.Clear();
            dgOverall.Rows.Clear();
            dgOverall.Columns.Clear();
            dgStocks.Columns.Clear();
            dgStocks.Rows.Clear();
            dgTrades.Columns.Clear();
            dgTrades.Rows.Clear();
            dgYearly.Columns.Clear();
            dgYearly.Rows.Clear();

            
            dgOverall.ColumnCount = 3;
            dgOverall.Rows.Add("Trades", "Returns", "MTM/TV");
            dgOverall.Rows.Add(stocksobj.Select(x => x.tottrds).Sum(), stocksobj.Select(x => x.totmtm).Sum().ToString("0.000%"), (stocksobj.Select(x => x.totmtm).Sum() / (2 * stocksobj.Select(x => x.tottrds).Sum())).ToString("0.000%"));
            dgOverall.ReadOnly = true;

            dgStocks.ColumnCount = 4;
            dgStocks.Rows.Add("Stock", "Trades", "Returns", "MTM/TV");
            for (int i = 0; i < stocksobj.Count(); i++)            
                dgStocks.Rows.Add(stocksobj[i].stkname, stocksobj[i].tottrds, stocksobj[i].totmtm.ToString("0.000%"), (stocksobj[i].totmtm / (2 * stocksobj[i].tottrds)).ToString("0.000%"));            
            dgStocks.ReadOnly = true;


            # region Day wise output 

            dgDates.ColumnCount = 3;
            dgDates.Rows.Add("Date", "Trades", "Returns");
            DateTime[] tmpdates = alldates.ToArray();

            for (int i = 0; i < alldates.Count(); i++)
            {
                int nt = daydetails.Where(x => x.trddt == tmpdates[i]).Count();
                double nmtm = daydetails.Where(x => x.trddt == tmpdates[i]).Select(z => z.daypnl).Sum();
                dgDates.Rows.Add(tmpdates[i].ToShortDateString(), nt, nmtm.ToString("0.000%"));

            }
            dgDates.ReadOnly = true;

            # endregion

            # region Yearly output

            int[] yrs = tmpdates.Select(x => x.Year).Distinct().ToArray();
            
            dgYearly.ColumnCount = 4;
            dgYearly.Rows.Add("Year", "Trades", "Returns", "MTM/TV");

            for (int i = 0; i < yrs.Length; i++)
            {
                int yt = daydetails.Where(x => x.trddt.Year == yrs[i]).Count();
                double ymtm = daydetails.Where(x => x.trddt.Year == yrs[i]).Select(x => x.daypnl).Sum();
                dgYearly.Rows.Add(yrs[i], yt, ymtm.ToString("0.000%"), (ymtm / (2 * yt)).ToString("0.000%"));
            }
            dgYearly.ReadOnly = true;

            # endregion            

            # region Generate All Trades

            dgTrades.ColumnCount = 7;
            dgTrades.Rows.Add("Stock", "Entry Time", "Entry Price", "Exit Time", "Exit Price", "Returns");
            for (int i = 0; i < stocksobj.Count(); i++)
            {
                for (int j = 0; j < stocksobj[i].tottrds; j++)
                {
                    dgTrades.Rows.Add(stocksobj[i].stkname, stocksobj[i].entm[j], stocksobj[i].entryprice[j], stocksobj[i].extm[j], stocksobj[i].exitprice[j], stocksobj[i].pnl[j]);
                }
            }
            dgTrades.ReadOnly = true;

            # endregion

            tabOutput.SelectedIndex = 0;

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void cbReadFile_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dgParams_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabOutput_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabOverall_Click(object sender, EventArgs e)
        {

        }

        private void dgOverall_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabStocks_Click(object sender, EventArgs e)
        {

        }

        private void dgStocks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabDates_Click(object sender, EventArgs e)
        {

        }

        private void dgDates_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabTrades_Click(object sender, EventArgs e)
        {

        }

        private void dgTrades_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabYearly_Click(object sender, EventArgs e)
        {

        }

        private void dgYearly_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lbDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


    }
}
