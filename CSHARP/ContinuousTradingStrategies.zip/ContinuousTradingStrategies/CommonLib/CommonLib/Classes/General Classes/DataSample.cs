﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonLib
{
    public class DataSample
    {
        public DateTime dttm;
        public string name, opttype;
        public DateTime exp;
        public double daystoexp;
        public int strike;
        public double bid, ask, LTP;

        public override string ToString()
        {
            return dttm.ToOADate().ToString() + "," + strike.ToString() + "," + opttype + "," + bid.ToString() + "," +
                ask.ToString() + "," + LTP.ToString();
        }

    }
}
