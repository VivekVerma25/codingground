
##################################################### Libraries

library("xts")
library("zoo")
library("matrixStats")

############################ Inputs to the code
setwd("D:/MN TEMPLATE/INDIA/OUTPUT/")
path_input<-"D:/MN TEMPLATE/INDIA/INPUT/"
dir.create("TEST")
path_output<-"D:/MN TEMPLATE/INDIA/OUTPUT/TEST/"

stck_lvl<-data.frame(read.csv(paste(path_input,"FUT DB/","RollAdjReturns.csv",sep="")))     # INPUT FOR RETURN SERIES OF FUTURES/STOCKS
stck_lvl$Date<-as.Date(stck_lvl$Date,"%d/%m/%Y") # Convert to R date format


bna<-1  # BETA NEUTRAL: Keep this 1 if you need beta neutral
topbot<-1 # 2 : TOP/BOTTOM RANK WEIGHTED, 1 : TOP/BOTTOM EQUAL WEIGHTED, SINGLE FACTOR TOP/BOT  
xnum<-10  # This is the number of stocks you need to select both on the top side and bottom side, SINGLE FACTOR
tc<-(0.0004)  # This is one side trnsaction cost 
dsort=0 # For enabling DOUBLE SORT, 1: for DSORT, 0: SIngle factor
dnum1<-25 # No. of stocks for PRIMARY FACTOR
dnum2<-0 # no. of stocks for SECONDARY FACTOR 
  
######################################################################################################################################################
list_factor1 <- vector('list',2) # MULTIPLE PARAMETERS LIST

raw_cash_close = data.frame(read.csv(paste(path_input,"CASH DB/","ratings.csv",sep=""))) # INPUT RAW DATA FOR FACTOR 1



lookback_period=c(125,250) # DIFFERENT LOOKBACKS

for(l in 1:length(lookback_period)){                     #WRITE YOUR LOGIC FOR FACTOR 1, HERE EXAMPLES IS MOMENTUM : 125/250 DAYS
  
  DELAY_raw_cash_close = raw_cash_close[,-1]
  DELAY_raw_cash_close[c(-1:-lookback_period[l]),] =DELAY_raw_cash_close[c((-dim(DELAY_raw_cash_close)[1]):(-dim(DELAY_raw_cash_close)[1]+lookback_period[l]-1)),]
  
  DELTA_raw_cash_close = (raw_cash_close[,-1]-DELAY_raw_cash_close)/DELAY_raw_cash_close
  
  rollfin<-as.matrix(DELTA_raw_cash_close)
  rollfin[which(!is.finite(rollfin))] <- NA
  rollfin<-data.frame(stck_lvl$Date,rollfin)
  
  list_factor1[[l]] <-rollfin      
}

names(list_factor1) <- list("MOM 125","MOM 250") # Factor1 NAMES WITH PARAMETERS USED

######################################################################## FACTOR 2
list_factor2 <- vector('list',2)

raw_cash_close = data.frame(read.csv(paste(path_input,"CASH DB/","px_last.csv",sep=""))) # INPUT RAW DATA FOR FACTOR 2

lookback_period=c(125,250) # DIFFERENT LOOKBACKS

for(l in 1:length(lookback_period)){              #WRITE YOUR LOGIC FOR FACTOR 2
  
  DELAY_raw_cash_close = raw_cash_close[,-1]
  DELAY_raw_cash_close[c(-1:-lookback_period[l]),] =DELAY_raw_cash_close[c((-dim(DELAY_raw_cash_close)[1]):(-dim(DELAY_raw_cash_close)[1]+lookback_period[l]-1)),]
  
  DELTA_raw_cash_close = (raw_cash_close[,-1]-DELAY_raw_cash_close)/DELAY_raw_cash_close
  
  rollfin<-as.matrix(DELTA_raw_cash_close)
  rollfin[which(!is.finite(rollfin))] <- NA
  rollfin<-data.frame(stck_lvl$Date,rollfin)
  
  list_factor2[[l]] <-rollfin      
}

names(list_factor2) <- list("MOM 125","MOM 250") # Factor2 NAMES WITH PARAMETERS USED
##########################################################################


stapp = data.frame(read.csv(paste(path_input,"UNIVERSE/","ActiveFO.csv",sep=""))) # INPUT THE UNIVERSE TO RUN ON

# FACTOR COMPUTATION ENDS, DON'T CHANGE THE CODE BELOW THIS

#######################################################################################################################################################
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#######################################################################################################################################################


fac_list1 = list_factor1



ret_full_cmbn = data.frame(stck_lvl$Date[c(-1,-2)])
colnames(ret_full_cmbn)= "DATE"

ret_tb_cmbn = ret_full_cmbn
ret_full_cmbn_L = ret_full_cmbn
ret_full_cmbn_S = ret_full_cmbn
ret_tb_cmbn_L = ret_tb_cmbn
ret_tb_cmbn_S= ret_tb_cmbn


for(z in 1 : length(fac_list1))
{
  
  fac_1<-fac_list1[[z]] # factor file input
  
  #stapp<-data.frame(read.csv(paste(uni_list[u,1],"/",uni_list[u,2],".csv",sep="")))
  
  
  f_factor<-data.frame(fac_1)                                 
  f_factor<-(f_factor[,-1])
  
  f_factor[stapp[,-1]==0]<-NA
  f_factor[f_factor<0.0000001 & f_factor>-0.0000001]<-NA      # This will be the final clculate foactor to be used for ranking
  
  fac1_rnk <- data.frame(t(apply(f_factor, 1, rank,na.last="keep",ties.method="max")))
    
  fac_clas<-fac1_rnk   # Rank weight of the final factor
  
  
  if(dsort ==1){
    
    #fac_2<-data.frame(read.csv(paste(path_input,"factor.csv",sep=""))) 
    fac_list2 = list_factor2
  
    for(zz in 1 : length(fac_list2))
    {
      
      fac_2<- fac_list2[[zz]] # factor file input
      
      f_factor2<-data.frame(fac_2)                                 
      f_factor2<-(f_factor2[,-1])
      
      f_factor2[stapp[,-1]==0]<-NA
      f_factor2[f_factor2<0.0000001 & f_factor2>-0.0000001]<-NA      # This will be the final clculate foactor to be used for ranking
            
      fac2_top<-f_factor2
      fac2_bot<-f_factor2
      
      topminc<-data.frame((apply(fac1_rnk,1,max,na.rm=TRUE)))
      
      topminc[topminc<=dnum1]<-dnum1     # This is to make sure that the total number is not less than selected numbers
      
      topminc_cbnd <- topminc-dnum1 +1
      
      
      for (j in 2:dim(fac1_rnk)[2] ){
        topminc_cbnd<-cbind(topminc_cbnd,topminc-dnum1 +1)
        
      }
      
      botminc<-data.frame((apply(fac1_rnk,1,max,na.rm=TRUE)))
      
      botminc[]<-dnum1
      
      botminc_cbnd <- botminc
      
      for (j in 2:dim(fac1_rnk)[2] ){
        botminc_cbnd<-cbind(botminc_cbnd,botminc)
        
      }
                
      
      fac2_top[fac1_rnk < topminc_cbnd]<- NA  
      
      fac2_rank_top<- data.frame(t(apply(fac2_top, 1, rank,na.last="keep",ties.method="random"))) 
      
      fac2_bot[fac1_rnk >dnum1] <- NA  
      
      fac2_rank_bot<- data.frame(t(apply(fac2_bot, 1, rank,na.last="keep",ties.method="random")))
      
      
      fac2_rank_top2<-fac2_rank_top
      
      fac2_rank_bot2<-fac2_rank_bot 
      
      topminc2<-((apply(fac2_rank_top,1,max,na.rm=TRUE)))
      
      fac2_rank_top2[fac2_rank_top < (topminc2 - dnum2+1)]<- NA
      
      #fac2_rank_top1[fac2_rank_top1 <(dim(fac2_rank_top1)[2]-rowSums(is.na(fac2_rank_top1)))- dnum2+1]<- NA
      
      
      fac2_rank_bot2[fac2_rank_bot>dnum2]<- NA
            
      fac2_rank_top2[is.na(fac2_rank_top2)] <-0   #Final double sorted equal weights
      fac2_rank_top2[fac2_rank_top2 >0]<-(1/(2*dnum2))
      fac2_rank_bot2[is.na(fac2_rank_bot2)] <-0
      fac2_rank_bot2[fac2_rank_bot2 >0]<-(-1/(2*dnum2))
      
      
      colnames(fac2_rank_top2)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
      colnames(fac2_rank_bot2)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
#       
#       
#       topname<-matrix(0,dim(fac2_rank_top2)[1],dnum2)
#       botname<-matrix(0,dim(fac2_rank_bot2)[1],dnum2)
#       
#       
#       
#       
#       for (k in 1:dim(fac2_rank_top2)[1]){
#         
#         if((sum(fac2_rank_top2[k,]>0) ==dnum2) && (sum(fac2_rank_bot2[k,]<0) ==dnum2))
#         {
#         
#         topname[k,]<-colnames(fac2_rank_top2[k,fac2_rank_top2[k,]>0])
#         botname[k,]<-colnames(fac2_rank_bot2[k,fac2_rank_bot2[k,]<0])
#         
#         }
#         
#         else
#         {
#           fac2_rank_top2[k,] =0
#           fac2_rank_bot2[k,] =0
#         }
#       }
#       
      
      wts_tb<-(fac2_rank_top2 + fac2_rank_bot2)
      
      wts_tb<-data.frame(wts_tb)
      
      wts_ini_top<-wts_tb
      wts_ini_bot<-wts_tb
      
      wts_ini_top[wts_tb<=0]<-0
      wts_ini_bot[wts_tb>=0]<-0
        
      
      wts_ini_full_tb <- (wts_tb)
      
      ###################################################################################################################################################################
      
      wts_ini_top_calc<-wts_ini_top[c(-1*dim(wts_ini_top)[1],-1*dim(wts_ini_top)[1]+1),]                        #return calculation
      wts_ini_bot_calc<-wts_ini_bot[c(-1*dim(wts_ini_bot)[1],-1*dim(wts_ini_bot)[1]+1),]
      
      stck_lvl_calc<-stck_lvl[c(-1,-2),-1]
      
      lng_ret_tb<-data.frame(rowSums(wts_ini_top_calc*stck_lvl_calc))
      sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
            
      lng_beta_tb<- matrix(1,dim(lng_ret_tb)[1],1)
      sht_beta_tb<- matrix(1,dim(sht_ret_tb)[1],1)
      
      
      if (bna==1){        # This will check if beta neutral needs to be done or not
        
        
        for(m in 251: dim(lng_beta_tb)[1])     # This will quantify the beta ratio between long and short in the portfolio
        {                                  
          
          #print(m)  
          
          lng_beta_tb[m,1]<- (cov(lng_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
          sht_beta_tb[m,1]<- -(cov(sht_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
        }
        
        wts_ini_bot_calc<-wts_ini_bot_calc*(lng_beta_tb/sht_beta_tb)
        wts_ini_full_tb[c(-1*dim(wts_ini_full_tb)[1],-1*dim(wts_ini_full_tb)[1] +1),] <-(wts_ini_top_calc + wts_ini_bot_calc)
        wts_ini_full_tb[(dim(wts_ini_full_tb)[1]-1),] <- wts_ini_top[(dim(wts_ini_full_tb)[1]-1),]+wts_ini_bot[(dim(wts_ini_full_tb)[1]-1),]*(lng_beta_tb[dim(lng_beta_tb)[1],1]/sht_beta_tb[dim(sht_beta_tb)[1],1])
        wts_ini_bot<-wts_ini_full_tb
        wts_ini_bot[wts_ini_full_tb>=0]<-0
        sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
        
      } 
      
      cst_tb<-data.frame(rowSums(abs(wts_ini_full_tb[-1,]-wts_ini_full_tb[-1*dim(wts_ini_full_tb)[1],])*tc))
      cst_tb<-cst_tb[-1*dim(cst_tb)[1],]
      
      cst_tb_L<-data.frame(rowSums(abs(wts_ini_top[-1,]-wts_ini_top[-1*dim(wts_ini_top)[1],])*tc))
      cst_tb_L<-cst_tb_L[-1*dim(cst_tb_L)[1],]
      
      cst_tb_S<-data.frame(rowSums(abs(wts_ini_bot[-1,]-wts_ini_bot[-1*dim(wts_ini_bot)[1],])*tc))
      cst_tb_S<-cst_tb_S[-1*dim(cst_tb_S)[1],]
      
      
      tot_ret_tb<-data.frame((lng_ret_tb+sht_ret_tb) - cst_tb)
      
      lng_ret_tb<-data.frame(lng_ret_tb-cst_tb_L)
      sht_ret_tb<-data.frame(sht_ret_tb-cst_tb_S)
      
      ret_fin_tb<-data.frame(cbind(stck_lvl$Date[c(-1,-2)],tot_ret_tb,lng_ret_tb,sht_ret_tb,wts_ini_full_tb[c(-1,-1*dim(wts_ini_full_tb)[1]),]))
      
      write.csv(ret_fin_tb,paste(path_output,names(fac_list1)[z],"_",names(fac_list2)[zz],"_TOPBOT.csv"),row.names=FALSE)
      
      ret_tb_cmbn = data.frame(cbind(ret_tb_cmbn,tot_ret_tb))
      colnames(ret_tb_cmbn)[(z-1)*length(fac_list2)+1+zz]= paste(names(fac_list1)[z],"_",names(fac_list2)[zz])
      
      ret_tb_cmbn_L = data.frame(cbind(ret_tb_cmbn_L,lng_ret_tb))
      colnames(ret_tb_cmbn_L)[(z-1)*length(fac_list2)+1+zz]= paste(names(fac_list1)[z],"_",names(fac_list2)[zz])
      
      ret_tb_cmbn_S = data.frame(cbind(ret_tb_cmbn_S, sht_ret_tb))
      colnames(ret_tb_cmbn_S)[(z-1)*length(fac_list2)+1+zz]= paste(names(fac_list1)[z],"_",names(fac_list2)[zz])
      
      
      
    }
        
   
  }
  
  
  if(dsort!=1){
    
    wts_fin<-NULL
     
    fac_clas_sel_1<-as.matrix(fac_clas)
     
    fac_clas_sel_2<-(fac_clas_sel_1-rowMeans(fac_clas_sel_1,na.rm=TRUE))/rowSums(abs(fac_clas_sel_1-rowMeans(fac_clas_sel_1,na.rm=TRUE)),na.rm=TRUE)
 
    wts_ini<-data.frame(fac_clas_sel_2)
    
    wts_tb<-wts_ini
    wts_ini_top<-matrix(0,dim(wts_ini)[1],dim(wts_ini)[2])
    wts_ini_bot<-matrix(0,dim(wts_ini)[1],dim(wts_ini)[2])
    
    
    if (topbot==1){  # This will select the top x and bottom x stocks and equaly weigh the same
            
      
      rnk_top<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
      #rnk_top<-fac1_rnk
      
      rnk_bot<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
      #rnk_bot<-fac1_rnk
      
      ############ The below will calculate the top and bottom ranks
      
      topminc<-data.frame((apply(rnk_top,1,max,na.rm=TRUE)))
      topminc[topminc<=xnum]<-xnum     # This is to make sure that the total number is not less than selected numbers
      
      topminc_cbnd <- topminc-xnum +1
      
      for (j in 2:dim(wts_ini)[2] ){
        topminc_cbnd<-cbind(topminc_cbnd,topminc-xnum +1)
        
      }
      
      wts_ini_top[rnk_top>=topminc_cbnd]<-1/(2*xnum)
      wts_ini_top<-data.frame(wts_ini_top)
      
      
      botminc<-data.frame((apply(rnk_bot,1,max,na.rm=TRUE)))
      botminc[botminc<=xnum]<-xnum
      
      botminc[]<-xnum
      
      botminc_cbnd <- botminc
      
      for (j in 2:dim(wts_ini)[2] ){
        botminc_cbnd<-cbind(botminc_cbnd,botminc)
        
      }
      
      
      wts_ini_bot[rnk_bot<=botminc_cbnd]<-(-1/(2*xnum))
      
      wts_ini_bot<-data.frame(wts_ini_bot)
      
      
      colnames(wts_ini_bot)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
      colnames(wts_ini_top)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
      
      
      topname<-matrix(0,dim(wts_ini_top)[1],xnum)
      botname<-matrix(0,dim(wts_ini_bot)[1],xnum)
      
      
#       
#       
#       for (k in 1:dim(wts_ini_bot)[1] ){
#         
#         if((sum(wts_ini_top[k,]>0) ==xnum) && (sum(wts_ini_bot[k,]<0) ==xnum))
#           
#         {
#           topname[k,]<-colnames(wts_ini_top[k,wts_ini_top[k,]>0])
#           botname[k,]<-colnames(wts_ini_bot[k,wts_ini_bot[k,]<0])
#         }
#         else
#         {
#           wts_ini_top[k,]<-0
#           wts_ini_bot[k,]<-0
#         }
#         
#       }
      
      
    }
    ####################################################################################################################################################
 
    
    if (topbot==2){  # This will select the top x and bottom x stocks and equaly weigh the same
      
      
      
      rnk_top<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
      #rnk_top<-fac1_rnk
      
      rnk_bot<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
      #rnk_bot<-fac1_rnk
      
      ############ The below will calculate the top and bottom ranks
      topminc<-data.frame((apply(rnk_top,1,max,na.rm=TRUE)))
      #topminc<-data.frame((apply(rnk_top,1,max,na.rm=TRUE)))
      topminc[topminc<=xnum]<-xnum     # This is to make sure that the total number is not less than selected numbers
      
      topminc_cbnd <- topminc-xnum +1
      
      for (j in 2:dim(wts_ini)[2] ){
        topminc_cbnd<-cbind(topminc_cbnd,topminc-xnum +1)
        
      }
      
      botminc<-data.frame((apply(rnk_bot,1,max,na.rm=TRUE)))
      
      botminc[]<-xnum
      
      botminc_cbnd <- botminc
      
      for (j in 2:dim(wts_ini)[2] ){
        botminc_cbnd<-cbind(botminc_cbnd,botminc)
        
      }
      
      wts_tb[fac1_rnk<topminc_cbnd & fac1_rnk >botminc_cbnd] <-NA
      wts_tb<-wts_tb/rowSums(abs(wts_tb),na.rm=TRUE)
      
      wts_tb[is.na(wts_tb)]<-0
      wts_tb<-data.frame(wts_tb)
      
      wts_ini_top<-wts_tb
      wts_ini_bot<-wts_tb
      
      wts_ini_top[wts_tb<=0]<-0
      wts_ini_bot[wts_tb>=0]<-0
      
      
      colnames(wts_ini_bot)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
      colnames(wts_ini_top)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
      
      
      topname<-matrix(0,dim(wts_ini_top)[1],xnum)
      botname<-matrix(0,dim(wts_ini_bot)[1],xnum)            
    }
    
    ####################################################################################################################################################
    
    
    #wts_sel_int<-wts_ini[wts_ini[2,]==i]     # This is the internal wts for calculation
    
    wts_fin<-wts_ini
    
    
    wts_fin[is.na(wts_fin)]<-0
    
    wts_int_full<-data.frame((wts_fin))
    
    
    wts_int_pos_full<-wts_int_full
    wts_int_neg_full<-wts_int_full
    
    wts_int_pos_full[wts_int_full<=0]<-0
    wts_int_neg_full[wts_int_full>=0]<-0
    
    
    ##############################################################################################################################
    wts_int_pos_full_calc<-wts_int_pos_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),]             #Full universe factor returns
    wts_int_neg_full_calc<-wts_int_neg_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),]
    
    
    #wts_int_pos_full_calc<-wts_int_pos_full_calc[-1*dim(wts_int_pos_full_calc)[1],]             #Full universe factor returns
    #wts_int_neg_full_calc<-wts_int_neg_full_calc[-1*dim(wts_int_neg_full_calc)[1],]
    
    stck_lvl_calc<-stck_lvl[c(-1,-2),-1]
    
    lng_ret_full<-data.frame(rowSums(wts_int_pos_full_calc*stck_lvl_calc))
    sht_ret_full<-data.frame(rowSums(wts_int_neg_full_calc*stck_lvl_calc))
    
    lng_beta_full<- matrix(1,dim(lng_ret_full)[1],1)
    sht_beta_full<- matrix(1,dim(sht_ret_full)[1],1)
    
    
    if (bna==1){        # This will check if beta neutral needs to be done or not
      
      
      for(m in 251: dim(lng_ret_full)[1])        # This will quantify the beta ratio between long and short in the portfolio
      {
        
        #print(m)  
        
        lng_beta_full[m,1]<- (cov(lng_ret_full[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
        sht_beta_full[m,1]<- -(cov(sht_ret_full[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
      }
      
      wts_int_neg_full_calc<-wts_int_neg_full_calc*(lng_beta_full/sht_beta_full)
      wts_int_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),] <- ( wts_int_pos_full_calc + wts_int_neg_full_calc)
      wts_int_full[(dim(wts_int_full)[1]-1),] <- wts_int_pos_full[(dim(wts_int_full)[1]-1),]+wts_int_neg_full[(dim(wts_int_full)[1]-1),]*(lng_beta_full[dim(lng_beta_full)[1],1]/sht_beta_full[dim(sht_beta_full)[1],1])
      wts_int_neg_full<-wts_int_full
      wts_int_neg_full[wts_int_full>=0]<-0
      sht_ret_full<-data.frame(rowSums(wts_int_neg_full_calc*stck_lvl_calc))
    } 
    
    
    cst_full<-data.frame(rowSums(abs(wts_int_full[-1,]-wts_int_full[-1*dim(wts_int_full)[1],])*tc))
    cst_full<-cst_full[-1*dim(cst_full)[1],]
    
    cst_full_L<-data.frame(rowSums(abs(wts_int_pos_full[-1,]-wts_int_pos_full[-1*dim(wts_int_pos_full)[1],])*tc))
    cst_full_L<-cst_full_L[-1*dim(cst_full_L)[1],]
    
    cst_full_S<-data.frame(rowSums(abs(wts_int_neg_full[-1,]-wts_int_neg_full[-1*dim(wts_int_neg_full)[1],])*tc))
    cst_full_S<-cst_full_S[-1*dim(cst_full_S)[1],]
    
    
    #lng_ret_full<-data.frame(rowSums(wts_int_pos_full_calc*stck_lvl_calc))
    #tot_ret_full<-data.frame((wts_int_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),]*stck_lvl_calc)-cst_full)  
    
    tot_ret_full<-data.frame((lng_ret_full+sht_ret_full)-cst_full)
    
    
    lng_ret_full<-data.frame(lng_ret_full-cst_full_L)
    sht_ret_full<-data.frame(sht_ret_full-cst_full_S)
    
    ret_fin_full<-data.frame(cbind(stck_lvl$Date[c(-1,-2)],tot_ret_full,lng_ret_full,sht_ret_full,wts_int_full[c(-1,-1*dim(wts_int_full)[1]),]))
    
    #write.csv(ret_fin_full, file = "ret_fin_full.csv")
    
    #write.csv(ret_fin_full,paste(path_output,fac_list[z,2],"_",uni_list[u,2],"_FULL.csv"),row.names=FALSE)
    write.csv(ret_fin_full,paste(path_output,names(fac_list1)[z],"_FULL.csv"),row.names=FALSE)
    ################################################################################################################################
    
    ################################################################################################################################
    if (topbot!=0){       
      
      wts_ini_full_tb <- (wts_ini_top+wts_ini_bot)
      
      
      wts_ini_top_calc<-wts_ini_top[c(-1*dim(wts_ini_top)[1],-1*dim(wts_ini_top)[1]+1),]                        #return calculation for top-bot 10
      wts_ini_bot_calc<-wts_ini_bot[c(-1*dim(wts_ini_bot)[1],-1*dim(wts_ini_bot)[1]+1),]
                  
      lng_ret_tb<-data.frame(rowSums(wts_ini_top_calc*stck_lvl_calc))
      sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
      
      
      lng_beta_tb<- matrix(1,dim(lng_ret_tb)[1],1)
      sht_beta_tb<- matrix(1,dim(sht_ret_tb)[1],1)
      
      
      if (bna==1){        # This will check if beta neutral needs to be done or not
        
        
        for(m in 251: dim(lng_beta_tb)[1])     # This will quantify the beta ratio between long and short in the portfolio
        {                                  
          
          #print(m)  
          
          lng_beta_tb[m,1]<- (cov(lng_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
          sht_beta_tb[m,1]<- -(cov(sht_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
        }
        
        wts_ini_bot_calc<-wts_ini_bot_calc*(lng_beta_tb/sht_beta_tb)
        wts_ini_full_tb[c(-1*dim(wts_ini_full_tb)[1],-1*dim(wts_ini_full_tb)[1] +1),] <-(wts_ini_top_calc + wts_ini_bot_calc)
        wts_ini_full_tb[(dim(wts_ini_full_tb)[1]-1),] <- wts_ini_top[(dim(wts_ini_full_tb)[1]-1),]+wts_ini_bot[(dim(wts_ini_full_tb)[1]-1),]*(lng_beta_tb[dim(lng_beta_tb)[1],1]/sht_beta_tb[dim(sht_beta_tb)[1],1])
        wts_ini_bot<-wts_ini_full_tb
        wts_ini_bot[wts_ini_full_tb>=0]<-0
        sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
        
      } 
      
      cst_tb<-data.frame(rowSums(abs(wts_ini_full_tb[-1,]-wts_ini_full_tb[-1*dim(wts_ini_full_tb)[1],])*tc))
      cst_tb<-cst_tb[-1*dim(cst_tb)[1],]
      
      cst_tb_L<-data.frame(rowSums(abs(wts_ini_top[-1,]-wts_ini_top[-1*dim(wts_ini_top)[1],])*tc))
      cst_tb_L<-cst_tb_L[-1*dim(cst_tb_L)[1],]
      
      cst_tb_S<-data.frame(rowSums(abs(wts_ini_bot[-1,]-wts_ini_bot[-1*dim(wts_ini_bot)[1],])*tc))
      cst_tb_S<-cst_tb_S[-1*dim(cst_tb_S)[1],]
      
      
      tot_ret_tb<-data.frame((lng_ret_tb+sht_ret_tb) - cst_tb)
      
      lng_ret_tb<-data.frame(lng_ret_tb-cst_tb_L)
      sht_ret_tb<-data.frame(sht_ret_tb-cst_tb_S)
      
      #ret_fin_tb<-data.frame(cbind(stck_lvl$Returns[c(-1,-2)],tot_ret_tb,lng_ret_tb,sht_ret_tb,topname[c(-1,-1*dim(topname)[1]),],botname[c(-1,-1*dim(botname)[1]),]))
      
      ret_fin_tb<-data.frame(cbind(stck_lvl$Date[c(-1,-2)],tot_ret_tb,lng_ret_tb,sht_ret_tb,wts_ini_full_tb[c(-1,-1*dim(wts_ini_full_tb)[1]),]))
      
      
      #ret_fin_tb1<- data.frame(aggregate(ret_fin_tb[,2],by=list((substr(ret_fin_tb[,1],1,4))),sum))
      #ret_fin_tb2<- data.frame(aggregate(ret_fin_tb[,2],by=list((substr(ret_fin_tb[,1],1,4))),mean))
      #ret_fin_tb3<- data.frame(aggregate(ret_fin_tb[,2],by=list((substr(ret_fin_tb[,1],1,4))),sd))
      
      #write.csv(ret_fin_tb, file = "ret_fin_tb.csv")
      #write.csv(ret_fin_tb,paste(path_output,fac_list[z,2],"_",uni_list[u,2],"_TOPBOT.csv"),row.names=FALSE)
      write.csv(ret_fin_tb,paste(path_output,names(fac_list1)[z],"_TOPBOT.csv"),row.names=FALSE)
      
    }
  
  
  ret_full_cmbn = data.frame(cbind(ret_full_cmbn,tot_ret_full))
  colnames(ret_full_cmbn)[z+1]= names(fac_list1)[z]
  
  ret_full_cmbn_L = data.frame(cbind(ret_full_cmbn_L,lng_ret_full))
  colnames(ret_full_cmbn_L)[z+1]= names(fac_list1)[z]
  
  ret_full_cmbn_S = data.frame(cbind(ret_full_cmbn_S, sht_ret_full))
  colnames(ret_full_cmbn_S)[z+1]= names(fac_list1)[z]
  
  if (topbot!=0){   
    ret_tb_cmbn = data.frame(cbind(ret_tb_cmbn,tot_ret_tb))
    colnames(ret_tb_cmbn)[z+1]= names(fac_list1)[z]
    
    ret_tb_cmbn_L = data.frame(cbind(ret_tb_cmbn_L,lng_ret_tb))
    colnames(ret_tb_cmbn_L)[z+1]= names(fac_list1)[z]
    
    ret_tb_cmbn_S = data.frame(cbind(ret_tb_cmbn_S, sht_ret_tb))
    colnames(ret_tb_cmbn_S)[z+1]= names(fac_list1)[z]
    
  }
  
}
}



write.csv(ret_full_cmbn,paste(path_output,"FULL_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(ret_full_cmbn_L,paste(path_output,"LONG_FULL_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(ret_full_cmbn_S,paste(path_output,"SHT_FULL_CMBND_RETURNS.csv"),row.names=FALSE)

write.csv(ret_tb_cmbn,paste(path_output,"TOP_BOT_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(ret_tb_cmbn_L,paste(path_output,"LONG_TOP_BOT_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(ret_tb_cmbn_S,paste(path_output,"SHT_TOP_BOT_CMBND_RETURNS.csv"),row.names=FALSE)


