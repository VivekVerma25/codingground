

# Will tolerate 1 bps difference between variables that should be equal
# This constant is used to compare if two things are equal

if(!exists("DiffTolerance")) DiffTolerance = 0.00001

# xtsToDat transforms a xts variable to data.table dat long format
xtsToDat = function(x, myType){
  
  if(class(x)[1] != "xts") stop(paste("xtsToDat needs xts variable as input, current variable is",class(x)))
  
  # store the current keys, as will set the key to them at the end
  # if datkeys doesn't exists
  if(!exists("datkeys")) {
    tempdatkeys = key(dat)
  } else {
    tempdatkeys = datkeys
  }
  
  xnew = cbind(index(x), data.frame(x))
  colnames(xnew)[1] = "year_mon"
  xnew = gather(xnew, mqaid, value, -year_mon)
  xnew = data.table(xnew)
  xnew[, mqaid := as.character(mqaid)]
  
  # occasionally, an X is added in front of a mqaid
  # need to change the mqaid back
  if( !all(xnew[,colnames(x) %in% mqaid]) ){
    all_adjusted_ticker = colnames(x)[!xnew[,((colnames(x) %in% mqaid))]]
    
    for(adjusted_ticker in all_adjusted_ticker){
      changed_ticker = xnew[grepl(adjusted_ticker, mqaid), unique(mqaid)]
      
      if(length(changed_ticker) > 1){
        stop(paste("xtsToDat error: adjusting mqaid issue", adjusted_ticker, changed_ticker))
      }
      
      # if there is only X left, after removing adjusted_ticker from changed_ticker
      # then change the changed_ticker to adjusted_ticker
      if(gsub(adjusted_ticker,"", changed_ticker) == "X"){
        xnew[mqaid == changed_ticker, mqaid := adjusted_ticker]
      }
    }
    
    
  }
  
  
  xnew[, type := myType]
  
  # set keys of dat to datkeys if it exists, otherwise to the tempdatkeys
  setkeyv(xnew, tempdatkeys)
  
  
  
  return(xnew)
}




# rbindDat function operates through externality
# it adds add to end of dat, and sets key of dat again to what it was before
rbindDat = function(add){
  
  datkeys = key(dat)
  
  setkeyv(add, datkeys)
  
  # check if dat already has the tickers for that type
  for(i in add[,unique(type)]){
    if(dat[.(i, add[,unique(mqaid)]), any(!is.na(value))]){
      stop(paste("Some of the tickers already are in dat for",i))
    }
  }

  
  dat <<- rbindlist(list(dat, add), use.names = T)
  
  if(dat[,class(mqaid)[1]] == "factor") dat[, mqaid := as.character(mqaid)]
  
  setkeyv(dat, datkeys)
  return(NULL)
}

# addXtsToDat
# transforms xts object to a data.table long format, and adds it to dat
addXtsToDat = function(x, myType){
  rbindDat(na.omit(xtsToDat(x, myType)))
}

# dtToXts transforms data table dat format to xts
datToXts = function(x, column_variable = "mqaid", dateColumn = "year_mon",
                    valueColumn = "value"){
  
  if(class(x)[1] != "data.table") stop(paste("datToXts needs data.table variable as input, current variable is",class(x)))
  
  x = x[,.(get(dateColumn), get(column_variable), get(valueColumn))]
  
  x = spread(x, V2, V3)
  x = xts(x[,-1, with = F], if(x[,class(V1)] == "yearmon"){
    as.yearmon(x[,V1])
  } else if(x[,class(V1)] == "Date"){
    as.Date(x[,V1])
  } else {
    stop("Currently only supports yearmon and Date classes")
  })
  
  return(x)
}

# returnsToXts_raw
# Use this to get returns from dat
# have a function to call this function, as we have different ETF security identifier
# conventions, so might need to call this multiple times to find out which the user wanted
# example, if user gave in ticker, but the function requires MQAID, the calling function
# will try to convert ticker to mqaid
# If the user didn't add 10 underscores, the function will add it
returnsToXts_raw = function(x, myColumnVariable = "mqaid", myDateColumn = "year_mon",
                            returnType = "monthly_return"){
  
  dattickers = dat[returnType, unique(mqaid)]
  
#   if(any(!( (gsub("_index|_backfilled","",x) %in% dattickers) |
#            (x %in% dattickers)))){
#     stop(paste("These tickers are not available in our database:",x[!( (gsub("_index|_backfilled","",x) %in% dattickers) |
#                                                                          (x %in% dattickers))]))
#   }
  # if dat containts type monthly_return_index then use that
  # otherwise try to get the ETF return itself
  
  
  if(nrow(dat[returnType]) > 1){
    
    # Return the mqaid if it is in monthly_return, it is an ETF
    # Return the index, if _index is in the mqaid
    # Return the index backfilled ETF returns if _backfilled is in the mqaid
    # Otherwise return an error
    
    res = lapply(x,function(name){
      # print(x)
      if(name %in% dattickers){
        # ETF return case
        return(datToXts(dat[.(returnType,name)]))
      } else if(grepl("_index$",name)){
        # Index return case
        indexret = datToXts(dat[.(paste(returnType,"index", sep = "_"),gsub("_index","",name))])
        colnames(indexret) = name
        return(indexret)
      } else if(grepl("_backfilled$",name)){
        # Backfilled return case
        etfret = datToXts(dat[.(returnType,gsub("_backfilled","",name))])
        indexret = datToXts(dat[.(paste(returnType,"index", sep = "_"),gsub("_backfilled","",name))])
        etffee = datToXts(dat[.("etf_fees",gsub("_backfilled","",name))])
        
        
        # return etfret if index return is not available
        if(nrow(indexret) == 1){
          return(etfret)
        }
        
        # subtract monthly ETF fee from index returns
        if(!exists("AnnualizationFactor")) AnnualizationFactor = 12
        indexret = indexret - etffee/AnnualizationFactor
        
        colnames(indexret) = paste(name,"index", sep = "_")
        backfilledret = backfillETFReturn(etfret, indexret, T)
        colnames(backfilledret) = name
        return(backfilledret)
      } else if(grepl("_backfilled_fee_te$",name)){
        
        # Backfilled return case with average difference between ETF and Index
        # subtracted from index
        etfret = datToXts(dat[.(returnType,gsub("_backfilled_fee_te","",name))])
        indexret = datToXts(dat[.(paste(returnType,"index", sep = "_"),gsub("_backfilled_fee_te","",name))])
        
        # return etfret if index return is not available
        if(nrow(indexret) == 1){
          return(etfret)
        }
        
        # subtract average difference between ETF and index from index
        etf_drag = read.csv("C:/local_quant_qsf/Quant/qsf_etf/IMPLEMENTATION/Monthly Average ETF - Index Returns.csv",
                            stringsAsFactors = F)
        etf_drag[,"mqaid"] = adjustMqaid(etf_drag[,"mqaid"])
        
        indexret = indexret - etf_drag[etf_drag[,"mqaid"] == gsub("_backfilled_fee_te","",name),"etf_drag"]
        
        
        colnames(indexret) = paste(name,"index", sep = "_")
        backfilledret = backfillETFReturn(etfret, indexret, T)
        colnames(backfilledret) = name
        return(backfilledret)
      } else {
        stop(paste("Either",name,"isn't in ETF database or we are asking for type that's not supported. Support only etf, index, or index backfilled etf returns"))
      }
    })
    
    lapply(res, function(x){
         if(all(is.na(x))) stop(paste("ETF", names(x), "is not in the database"))
         
    })
    
	
    res = do.call(merge,res)
    colnames(res) = x
  } else {
    if(any(!(x %in% dattickers))){
      print(paste("Following tickers don't have data in dat"))
      print(x[!(x %in% dattickers)])
      print("Will try to get not backfilled, and not index returns for them")
      x[!(x %in% dattickers)] = gsub("_index|_backfilled","", x[!(x %in% dattickers)])
    }
    
    res = datToXts(dat[.(returnType, x)], myColumnVariable, myDateColumn)
    # ensure column setup is the same as in the input
    res = res[,x]
  }


  
#   # if don't have data in dat, then will get it from 
#   # C:\local_quant_qsf\Quant\qsf_etf\TRADING\etf_returns.csv
#   if(nrow(res) == 1){
#     res = fread("C:/local_quant_qsf/Quant/qsf_etf/TRADING/etf_returns.csv")
#     
#     res = res[,c("V1",x), with = F]
#     
#     res = xts(res[,-1,with = F], res[,as.yearmon(V1)])
#     # ensure column setup is the same as in the input
#     res = res[,x]
#   }

  return(res)
}

# returnsToXts
# Will try to look up x in dat, and if there is an error, will make a tickerToMqaid conversion
returnsToXts_ticker_mqaid_conversion = function(x, myColumnVariable = "mqaid", myDateColumn = "year_mon"){
  tryCatch(returnsToXts_raw(x, myColumnVariable, myDateColumn),
           error = function(e){
             tryCatch(returnsToXts_raw(tickerToMqaid(x),myColumnVariable, myDateColumn),
                      error = function(e2){
                        returnsToXts_raw(x, myColumnVariable, myDateColumn)
                      })})
  
}

# mqaidAdjustment 
# What is added in front of mqaid to avoid issues when they start with a number
### R data frame doesn't allow column name to start with a number
### if it does, it will add an X in front of it, causing issues when doing
### any operation on two matrices, as the column names
### won't match if one has had an X added in front of it
### Will add 10 underscores in front of an mqaid, and then remove it in
### finishSignalCode function.
mqaidAdjustment = function(){
  "x"
}

# adjustMqaid
# Adds mqaidAdjustment in front of an mqaid
adjustMqaid = function(x){
  paste0(mqaidAdjustment(), x)
}


returnsToXts = function(x, myColumnVariable = "mqaid", myDateColumn = "year_mon", 
                        tickerColNames = FALSE, useReturnType = "monthly_return"){
  #   adjustX = sapply(x, function(name){
  #     tryCatch({
  #                 res = returnsToXts_ticker_mqaid_conversion(name, myColumnVariable, myDateColumn)
  #                 if(nrow(res) == 1){
  #                   T
  #                 } else {
  #                   F
  #                 }
  #              }, error = function(e){
  #                 T
  #              })
  #   })
  #   for(i in which(adjustX)){
  #     if(is.na(mqaidToTicker(x[i])) & is.na(tickerToMqaid(x[i]))){
  #       stop("shouldn't happen")
  #     }
  #     if(is.na(mqaidToTicker(x[i]))){
  #       # if we have a ticker
  #       x[i] = tickerToMqaid(x[i])
  #     } else if(is.na(tickerToMqaid(x[i]))){
  #       # if we have an mqaid
  #       x[i] = mqaidToTicker(x[i])
  #     }
  #   }
  #   x[adjustX] = paste0(mqaidAdjustment(), x[adjustX])
  # adjust names to handle both tickers, mqaid, and mqaid with or without the mqaidAdjustment
  x_before_change = x
  
  for(i in 1:length(x)){
    tempx = gsub("_backfilled$|_index$|_backfilled_fee_te$","",x[i])
    if(!is.na(tickerToMqaid( tempx )))
    {
      # Try converting ticker to mqaid
      # if backfilled
      if(grepl("_backfilled$", x[i]))
      {
        x[i] = paste0(tickerToMqaid(tempx),"_backfilled")
      }
      else if(grepl("_backfilled_fee_te$", x[i]))
      {
        x[i] = paste0(tickerToMqaid(tempx),"_backfilled_fee_te")
      }
      else if(grepl("_index$", x[i]))
      {
        x[i] = paste0(tickerToMqaid(tempx),"_index")
      } 
      else 
      {
        x[i] = tickerToMqaid(x[i])
      }
    }
    else if(!is.na( mqaidToTicker( adjustMqaid(tempx) ) ))
    {
      # Add mqaidAdjustment in front of mqaid
      
      
      if(grepl("_backfilled$", x[i])){
        # if backfilled
        x[i] = paste0(adjustMqaid(tempx),"_backfilled")
      }
      else if(grepl("_backfilled_fee_te$", x[i]))
      {
        # if backfilled fee
        x[i] = paste0(adjustMqaid(tempx),"_backfilled_fee_te")
      } 
      else if(grepl("_index$", x[i]))
      {
        # if index
        x[i] = paste0(adjustMqaid(tempx),"_index")
      } 
      else 
      {
        x[i] = adjustMqaid(x[i])
      }
      
    }
  }
  
  res = returnsToXts_raw(x, myColumnVariable, myDateColumn, useReturnType)
  # Choose a standard for the colname that will be the ticker
  # The object  need to be easily readable 
  
  # if we want ticker only in the colnames
  if(tickerColNames)
  {
    x_after_change = x_before_change
    
    # Looping on the original colnames with a for loop for code readability
    for(i in 1:length(x_before_change))
    {   
      # if colnames contain the word backfilled or index
      if( grepl("_backfilled$|_index$|_backfilled_fee_te$",x_before_change[i]) )
      {
        # remove backfilled or index then return ticker in the colname
        colNameTicker = ifelse( !is.na(mqaidToTicker(gsub("_backfilled$|_index$|_backfilled_fee_te$","",x_before_change[i]))),
                                mqaidToTicker(gsub("_backfilled$|_index$|_backfilled_fee_te$","",x_before_change[i])),
                                gsub("_backfilled$|_index$|_backfilled_fee_te$","", x_before_change[i])   ) 
        x_after_change[i] = colNameTicker
      } 
      else if( !is.na(tickerToMqaid(x_before_change[i])) | !is.na(mqaidToTicker(x_before_change[i]))   )
      {
        # return ticker in the colname if not already ticker
        colNameTicker = ifelse(!is.na(mqaidToTicker(x_before_change[i])),mqaidToTicker(x_before_change[i]),
                               x_before_change[i])
        x_after_change[i] = colNameTicker
      }
    }
    colnames(res) = x_after_change
  }
  else
  {
    colnames(res) = x_before_change
  }
  
  return(res)
  # returnsToXts_ticker_mqaid_conversion(x, myColumnVariable, myDateColumn)
  
}


# lagXts lags xts object by lagLength
# lag.xts issue is that it doesn't push the
# end point back, it just stops
lagXts = function(x,lagLength = 1){
  
  if(class(index(x)) == "yearmon"){
    index(x) = index(x) + lagLength/12      
  } else if(class(index(x)) == "Date"){
    # when lag daily data, need to make sure we lag according to market dates
    
    # calculate lagged lagLength market date
    datem = createDateMap(index(x), lagLength)
    
    #set date
    index(x) = datem[,Lagged_Date]
  } else {
    stop("Support only Date and yearmon")
  }
  
  return(x)
}



# getNDayOfMonth
# Takes in an Xts object, and then if fromEnd = T it returns the 
# nday last trading day of the month, 1 its the last trading day
# 2 is the second last trading day
# if fromEnd = F, 1 will get the first trading day of month
getNDayOfMonth = function(x, nday = 1, fromEnd = T){
  if(class(x)[1] != "xts" & class(x)[1] != "zoo"){
    stop("getNDayOfMonth supports only xts and zoo classes")
  }
  
  if(class(index(x)) != "Date"){
    stop("getNDayOfMonth supports only Date as the date format")
  }
  
  # transform to data table, and keep dates
  x = data.table(cbind(index(x),data.frame(x)))
  setnames(x,"index(x)","date")
  
  # rank dates within a month
  x[, year_mon := as.yearmon(date)]
  
  x[, day_rank := frankv(date, order = ifelse(fromEnd,-1,1)), by = year_mon]
  
  setkey(x, day_rank, year_mon)
  
  x = x[.(nday)]
  x[, year_mon := NULL]
  x[, day_rank := NULL]
  setkey(x,date)
  
  return(x)
}

# getNDayOfMonthXts
# See getNDayOfMonth explanation. Calls getNDayOfMonth and returns an xts
getNDayOfMonthXts = function(x, nday = 1, fromEnd = T){
  
  temp = getNDayOfMonth(x, nday, fromEnd)
  temp = xts(temp[,-1, with = F], temp[,date])
  return(temp)
}



# setToDate
# sets date like object to either Date class object or yearmon
# based of what class the index of mydata has
# mainly used within sapply, and rollapply
# as if you use index(mydata) within them, it will show up as numeric
setToDate = function(mydate = mydate, mydata = mydata){
  if(class(index(mydata)) == "yearmon"){
    mydate = as.yearmon(mydate)
  } else if (class(index(mydata)) == "Date"){
    mydate = as.Date(mydate)
  } else {
    stop("Support only yearmon and Date date classes")
  }
  return(mydate)
}


# QuandlPriceToReturn
# Reads in price data from Quandl, sets it as Xts object
# and returns the returns
QuandlPriceToReturn = function(x, columnToGet = 1, monthly = T){
  temp = Quandl(x)
  temp = xts(temp[,columnToGet], as.Date(temp[,1]))
  if(monthly) temp = to.monthly(temp, OHLC = F)
  temp = na.omit(temp/lag(temp, k = 1) - 1)
  return(temp)
}


# backfillETFReturn
# Takes in etf name, and index name that exists in dat, and backfills the
# etf returns with index returns where etf returns are missing
backfillETFReturn = function(etf_name, index_name, returnXts = F){
  
  if(is.character(etf_name)) etf_name = returnsToXts(etf_name)
  if(is.character(index_name)) index_name = returnsToXts(index_name)
  
  temp = merge(etf_name,index_name)
  
  etf_name = colnames(etf_name)
  index_name = colnames(index_name)
  
  colnames(temp) = c(etf_name, index_name)
  temp[is.na(temp[,etf_name]),etf_name] = temp[is.na(temp[,etf_name]),index_name]
  temp = temp[,etf_name]
  colnames(temp) = paste(etf_name,"backfilled", sep = "_")

  if(returnXts) return(temp)
  
  addXtsToDat(temp,"monthly_return")
}

# winsorize
# winsorizes a variable
# values above or equal to the highLevel %tile, get replaced by the highLevel %tile
# values below or equal to the lowLevel %tile, get replaced by the lowLevel %tile
winsorize = function(x, lowLevel = 0.01, highLevel = 0.99){
  x_low = quantile(x, lowLevel)
  x_high = quantile(x, highLevel)
  
  x[x <= x_low] = x_low
  x[x >= x_high] = x_high
  
  return(x)
}



summarizeRegCoef = function(regres, RoundCoef = 2){
     
     if(nrow(regres$coef) > 1){
          data.frame("Beta" = c(round(regres$coef[2,"Estimate"],RoundCoef),paste0(round(100*regres$coef[1,"Estimate"]*12,RoundCoef),"%")),
                     "T-Stat" = c(round(regres$coef[2,"t value"],RoundCoef), round(regres$coef[1,"t value"],RoundCoef)),
                     "P-Value" = c(paste0(round(100 * regres$coef[2,"Pr(>|t|)"],1),"%"),paste0(round(100 * regres$coef[1,"Pr(>|t|)"],1),"%")),
                     "Adj. R-Squared" = c(paste0(round(100 * regres$adj.r.squared, 1),"%"),""), check.names = F, stringsAsFactors = F)
     } else {
          data.frame("Beta" = c(NA,paste0(round(100*regres$coef[1,"Estimate"]*12,RoundCoef),"%")),
                     "T-Stat" = c(NA, round(regres$coef[1,"t value"],RoundCoef)),
                     "P-Value" = c(NA,paste0(round(100 * regres$coef[1,"Pr(>|t|)"],1),"%")),
                     "Adj. R-Squared" = c(paste0(round(100 * regres$adj.r.squared, 1),"%"),""), check.names = F, stringsAsFactors = F)
     }
}


# setCompData sets the data to comparable start dates
# assumes columns 1 and 2 are etf portfolio, 3 and 4 are index portfolios
setCompData = function(x){
  
  if(ncol(x) == 2 | ncol(x) == 4){
    # set first 2 columns
    common_months = getCommonMonths(na.omit(x[,1]),na.omit(x[,2]))
    x[!(index(x) %in% common_months),1:2] = NA
    
    if(ncol(x) == 4){
      # set columns 3 to 4
      common_months = getCommonMonths(na.omit(x[,3]),na.omit(x[,4]))
      x[!(index(x) %in% common_months),3:4] = NA
    }
    
    x = x[rowSums(is.na(x)) < ncol(x)]
    
    return(x)
  } else if(ncol(x) == 6){
    common_months = getCommonMonths(na.omit(x[,1]),na.omit(x[,2]))
    common_months = intersect(common_months,index(na.omit(x[,3])))
    
    x[!(index(x) %in% common_months),1:3] = NA
    
    if(ncol(x) == 6){
      # set columns 4 to 6
      common_months = getCommonMonths(na.omit(x[,4]),na.omit(x[,5]))
      common_months = intersect(common_months, index(na.omit(x[,6])))
      x[!(index(x) %in% common_months),4:6] = NA
    }
    
    x = x[rowSums(is.na(x)) < ncol(x)]
    
  } else {
    stop("data has to have 2 or 4 columns, or 6, etf and index comparisons, and volcapture.")
  }
  
}

# mqaidTickerMap
# Creates a data.table that has a mapping between tickers and mqaid
# with tickers being the key
mqaidTickerMap = function(){
  
  loadPackages(c("foreign","data.table"))
  mtmap = read.dta("C:/local_quant_qsf/Quant/qsf_etf/TRADING/masterEtf_IMP_M.dta")
  mtmap = data.table(mtmap)
  
  # remove tickers that are inactive, have tick Null
  mtmap = mtmap[tick != "Null"]
  
  mtmap = mtmap[,.(mqaid, tick)]
  mtmap[, mqaid := adjustMqaid(mqaid)]
  
  mtmap = unique(mtmap,by = NULL)
  
  mtmap[, tick := tolower(tick)]
  setkey(mtmap, tick)
  
  return(mtmap)
}

# tickerToMqaid
# takes a ticker as an input and returns the mqaid
tickerToMqaid = function(x){
  
  # use mtmap if it exists in memory, as loading it takes time
  if(!exists("mtmap")) mtmap <<- mqaidTickerMap()
  setkey(mtmap, tick)
  mtmap[tolower(x),mqaid]
}



# mqaidToTicker
# takes a mqaid as an input and returns the ticker
mqaidToTicker = function(x){
  
  # use mtmap if it exists in memory, as loading it takes time
  # if it doesn't exist, the save it to global memory
  if(!exists("mtmap")) mtmap <<- mqaidTickerMap()
  
  setkey(mtmap, mqaid)
  
  for(i in 1:length(x)){
    if(substr(x[i],1,1) != mqaidAdjustment()){
      x[i] = adjustMqaid(x[i])
    }
  }

  mtmap[x,tick]
}






###################################################################################################
## # check that myRet and myWt have the same column names
###################################################################################################
# Checks that the column names of x and y are identical and throws an error if not
# this is used to ensure that 2 matrices are setup correctly before doing any
# calculation, such as multiplying weights by returns
DataCheckerWtRet = function(myRet, myWt)
{
     # check that myRet and myWt have the same column names
     if(ncol(myRet) != ncol(myWt)) stop("DataCheckerWtRet Error. Different number of columns")
     if(any(colnames(myRet) != colnames(myWt))) stop("DataCheckerWtRet Error: Column names don't match")
}


# checkNameSetup
# legacy, was first created, then DataCheckerWtRet was created and is more robust
checkNameSetup = function(x, y){
     DataCheckerWtRet(x,y)
}



# writeTradelist
# sets weights to the format required for tradelist, and writes it to file

writeTradelist = function(x, name = "", monthnum = NULL){
  
  # transform weights to long format
  x = cbind(index(x),data.frame(x))
  colnames(x)[1] = "year_mon"
  x = gather(x, tick, weight, -year_mon)
  
  # set as data.table
  x = data.table(x)
  
  
  # add mqaid, monthnumber, signal
  x[, mqaid := mqaid_ticker[toupper(as.character(x[,tick])),mqaid]]
  x[, monthnumber := YearmonToMonthn[as.character(x[,year_mon]), monthnumber]]
  x[, signal := sign(weight)]
  
  # remove those with 0 weight and 0 signal
  x = x[signal != 0 & weight != 0]
  
  # remove year_mon as it's no longer needed
  x[, year_mon := NULL]
  
  # reorder columns
  x = x[,.(mqaid, tick, monthnumber, signal, weight)]
  
  if(!is.null(monthnum)){
    x = x[monthnumber == monthnum]
    
    write.csv(x, paste0(name," tradelist ",monthnum,".csv"), row.names = F)
  } else {
    write.csv(x, paste0(name," tradelist.csv"), row.names = F)
  }
  return(x)
}

# firstNonNA
# Returns the location of the first non NA in x
firstNonNA = function(x){
  # multiply 1:length(x) with if it is na or not
  # those with NA get 0, whereas non NA will get the number if has in X
  # remove 0, and get the min
  min(setdiff(as.numeric(!is.na(x)) * (1:length(x)),0))
}


# fillNAWith0AfterDataStarts
# Replaces NA's with 0, but only after the data starts
# some data might have NA's because of data not being available
# others might have NA in the middle, due to how data is calculated
# Example, bloomberg PE_RATIO, has NA if earnings are negative
# therefore when we use earnings yield, we need to replace the 
# na in the middle due to negative earnings with 0
fillNAWith0AfterDataStarts = function(x){
  for(i in 1:ncol(x)){
    x[firstNonNA(x[,i]):nrow(x),i] = na.fill(x[firstNonNA(x[,i]):nrow(x),i],0)
  }
  return(x)
}


# setSignalToSameReturnDates
# Sets all entries in signal, before the ret has return data, to NA
# This is useful if we use underlying indices to create a signal
# and want to remove the signal entries for when we don't have ETF data
setSignalToSameReturnDates = function(signal, ret){
  
  if( any(colnames(signal) != colnames(ret)) ){
    stop("signal and ret column names are not aligned")
  }
  

  for(name in colnames(ret)){
    # find first non NA
    
    myFirstNonNA = firstNonNA(ret[,name])
    myFirstNonNA = index(ret)[myFirstNonNA]
    
    signal[index(signal) < myFirstNonNA, name] = NA
  }
  
  # error check, to ensure all signals are NA when ret is Na for a name
  for(name in colnames(ret)){
    if(any(!is.na(signal[index(ret)][index(ret)[is.na(ret[,name])],name]))){
      stop(paste(name,"has non NA data in signal where ret is NA"))
    }
  }
  
  return(signal)
}




# createZScore
# Creates a z-score for an xts object
# subtracts a rolling RollRegLength average, lagged 1 month, from the object
# and divides by rolling standard deviation, lagged 1 month

createZScore = function(x = xt, zLength = RollRegLength, na.rm = T, lagMeanStd = T){
  if(class(x)[1] != "xts" & class(x)[1] != "zoo") stop("createZScore requires xts object")
  
  xmean = rollapplyr(x, zLength, mean)
  
  if(na.rm) xmean = na.omit(xmean)
  
  if(lagMeanStd) {
    xmean = lagXts(xmean, 1)
  }
  
  xsd = rollapplyr(x, zLength, sd)
  if(na.rm) xsd = na.omit(xsd)
  
  if(lagMeanStd){
    xsd = lagXts(xsd, 1)
  }
  
  
  x = x[index(xmean)]
  xmean = xmean[index(x)]
  xsd = xsd[index(x)]
  
  return((x[index(xmean)] - xmean)/xsd)
}

# createZScoreSignal
# Creates a continuous signal that goes from -1 and 1 using createZScore
# It then caps the z-score at both extremes, and scales to go from -1 to +1
# if squareResults, it will calcualte the square of the signal, preserving directionality of it
# this means signal will be pulled towards 0, so less signal value unless the signal is close
# to + or -1
createZScoreSignal = function(x = xt, zlength = 36, zfloor = -1, zceiling = 1,
                              squareResults = F, lagMeanStd = T, rescale = T){
  
  # calculate a ZScore
  res = createZScore(x, zlength, lagMeanStd = lagMeanStd)
  
  # cap the Z score above and below
  res[res < zfloor] = zfloor
  res[res > zceiling] = zceiling
  
  if(rescale){
    # scale to go between -1 and +1
    res[res < 0] = res[res < 0]/abs(zfloor)
    res[res > 0] = res[res > 0]/abs(zceiling)
  }

  
  if(squareResults){
    res = res^2 * sign(res)
  }
  return(res)
}


# lmWithWhiteStdErrors
# performs linear regression, but uses white standard errors
# if Breusch Pagan test for heteroskedasticity has p-value less than HeteroSkedPValue
lmWithWhiteStdErrors = function(mySymbol, mySignal, HeteroSkedPValue, RoundCoef = 3){
     
     if( class(mySymbol)[1] != "xts" ) stop("lmWithWhiteStdErrors requires xts object as mySymbol")
     if( class(mySignal)[1] != "xts" ) stop("lmWithWhiteStdErrors requires xts object as mySignal")
     
     regdata = na.omit(merge(mySymbol, mySignal))
     colnames(regdata) = c("reg_symbol",paste0("reg_signal",1:ncol(mySignal)))
     
     regres = lm(as.formula(paste("reg_symbol ~", paste(colnames(regdata)[-1], collapse = " + "))), 
                 data = regdata)
     
     regressum = summary(regres)
     # will use White standard errors if Breusch-Pagan test for heteroskedasticity
     # has a p value less than HeteroSkedPValue
     
     
     if(!require(lmtest, quietly = T)) {
          install.packages("lmtest")
          print("Installed package lmtest")
     }
     
     if(!require(sandwich, quietly = T)) {
          install.packages("sandwich")
          print("Installed package sandwich")
     }
     
     if(bptest(regres)$p.value < HeteroSkedPValue){
          # change the standard errors
          regressum$coefficients = coeftest(regres, vcov. = vcovHC(regres, type = "HC1"))[1:nrow(regressum$coef),1:ncol(regressum$coef)]
          # regres = coeftest(regres, vcov. = NeweyWest)
          
          # change the f-test results
          # wt = waldtest(regres,vcov = vcovHC(regres, type = "HC1"))
          # regressum$fstatistic = c("value" = wt$F[2],"numdf" = abs(wt$Df[2]), "dendf" = wt$Res.Df[1])
     } 
     
     
     if(ncol(regdata) > 2){
          fullsampleres = sapply(2:(nrow(regressum$coefficients)), function(x){
               
               tempres = c(regressum$coef[x,c(1,3,4)], toPct(regressum$adj.r.squared,3), index(regdata)[1], index(regdata)[nrow(regdata)])
               names(tempres) = c("Beta","T-Stat","P-Value","Adj. R-Squared","Start","End")
               
               tempres["Beta"] = round( as.numeric(tempres["Beta"]), RoundCoef)
               tempres["T-Stat"] = round( as.numeric(tempres["T-Stat"]), RoundCoef)
               tempres["P-Value"] = toPct(as.numeric(tempres["P-Value"]))
               tempres["Adj. R-Squared"] = toPct(fromPct((tempres["Adj. R-Squared"])))
               tempres["Start"] = as.character(as.yearmon(as.numeric(tempres["Start"])))
               tempres["End"] = as.character(as.yearmon(as.numeric(tempres["End"])))
               
               return(tempres)
          })
          
          fullsampleres = t(fullsampleres)
          rownames(fullsampleres) = colnames(mySignal)
          
     } else {
          fullsampleres = cbind(summarizeRegCoef(regressum, 3)[1,], index(regdata)[1], index(regdata)[nrow(regdata)])
          colnames(fullsampleres)[(ncol(fullsampleres)-1):ncol(fullsampleres)] = c("Start","End")
          rownames(fullsampleres) = colnames(mySignal)
     }
     
     
     return(fullsampleres)
}


# rollingPredictiveRegression
# does a rolling predictive regression, and returns full sample regression results
# of prediction on mySymbol, along with the prediction

rollingPredictiveRegression = function(mySymbol, mySignal, rollRegLength, HeteroSkedPValue){
     regdata = na.omit(merge(mySymbol, mySignal))
     colnames(regdata) = c("reg_symbol",paste0("reg_signal",1:ncol(mySignal)))
     
     if(nrow(regdata) < rollRegLength){
          stop(paste0("Have less data than rollRegLength, can't do rolling regression"))
     }
     
     
     rollpred = rollapplyr(index(regdata), rollRegLength + 1, fill = NA, function(x){
          
          # set dates to the correct date format
          # (rollapplyr will turn x into numeric, need to turn back to date format)
          
          x = setToDate(x, regdata)
          # in sample dates we use for regression
          x_in_sample = x[-length(x)]
          # prediction date
          x_out_of_sample = x[length(x)]
          
          as.formula(paste("reg_symbol ~", paste(colnames(regdata)[-1], collapse = " + ")))
          # in sample regression
          regres = lm( as.formula(paste("reg_symbol ~", paste(colnames(regdata)[-1], collapse = " + "))), 
                       data = regdata[x_in_sample])
          
          predict(regres, regdata[x_out_of_sample])
     })
     
     rollpred = na.omit(xts(rollpred, index(regdata)))
     rollpreddat = na.omit(merge(rollpred, mySymbol))
     colnames(rollpreddat) = c("prediction","realized")
     
     
     
     
     # rollregres = cbind(  summarizeRegCoef(summary(lm(realized ~ prediction, data = rollpreddat)))[1,], 
     #                      index(rollpreddat)[1], index(rollpreddat)[nrow(rollpreddat)])
     # colnames(rollregres)[(ncol(rollregres)-1):ncol(rollregres)] = c("Start","End")
     
     res = list()
     res[["rolling_regression"]] = lmWithWhiteStdErrors(rollpreddat$realized, rollpreddat$prediction, HeteroSkedPValue)
     res[["rolling_prediction"]] = rollpreddat$prediction
     
     return(res)
}



createECDFPctile = function(mydata, rollLength = 36){  
     ecdfpctile = na.omit(rollapplyr(mydata, rollLength + 1, fill = NA, function(x){
          
          # in sample data we use for regression
          x_in_sample = x[-length(x)]
          # prediction date
          x_out_of_sample = x[length(x)]
          
          x_in_sample_ecdf = ecdf( as.numeric(x_in_sample) )
          
          return(x_in_sample_ecdf(x_out_of_sample))
     }))
     
     return(ecdfpctile)
}


# evaluateSignal
# Evaluates market timing ability of a signal, using
# full sample regression
# Rolling regression
# t-test for difference in means and Browth Forsythe for difference in variance
# for discrete signals

# symbol = worldbarx
# signal = na.omit(spread/lag(spread, k = 1)-1) > 0
# symbol_type = NULL
# signal_type = NULL
# HeteroSkedPValue = 0.2
# rollRegLength = 5 * AnnualizationFactor
# zlength = 12
# zlagMeanStd = T
# zrescale = F
# zLevelCap = 2
evaluateSignal = function(symbol, signal, signalOnName = "Signal On", signalOffName = "Signal Off",
                          symbol_type = "monthly_return", signal_type = NULL, 
                          HeteroSkedPValue = 0.2, 
                          AnnualizationFactor = 12,
                          rollRegLength = 5 * AnnualizationFactor,
                          zlength = 12, zlagMeanStd = T, zrescale = F, zLevelCap = 2,
                          zsquareResults = F){
  
  # signal = xts(as.logical(signal),index(signal))
  
  # get symbol from dat if it is a name
  if(is.character(symbol)){
    symbol = datToXts(dat[.(symbol_type, symbol)])
    symbolraw = symbol
  } else {
    symbolraw = na.omit(symbol)
  }
  
  # get signal from dat if it is a name
  if(is.character(signal)){
    signal = datToXts(dat[.(signal_type, signal)])
    signalraw = signal
  } else {
    signalraw = na.omit(signal)
  }
  
  # remove NA from signal
  signal = na.omit(signal)
  
  # remove NA from symbol
  symbol = na.omit(symbol)

  if(is.null(colnames(symbol))){
       colnames(symbol) = "symbol"
  }
  
  if(is.null(colnames(signal))){
       colnames(signal) = "signal"
  }
  
  # Set signal and symbol to same months
  
  common_months = getCommonMonths(symbol, signal)
  symbol = symbol[common_months]
  signal = signal[common_months]
  
  res = list()
  
  
  #########################
  # Reg symbol regression #
  #########################
  
  
  ##########################
  # Full sample regression #
  ##########################

  # symbol results is meant for returns
  # squared symbol is meant for volatility
  # abs symbol is another measure for volatility

  # fullregres = rbind( lmWithWhiteStdErrors(symbol, signal, HeteroSkedPValue),
  #                     lmWithWhiteStdErrors(symbol^2, signal, HeteroSkedPValue),
  #                     lmWithWhiteStdErrors(abs(symbol), signal, HeteroSkedPValue) )
    # rownames(fullregres) = c("Return","Variance","Abs Return")
  
     fullregres = rbind( cbind(data.frame("Type" = "Return"), lmWithWhiteStdErrors(symbol, signal, HeteroSkedPValue)),
                         cbind(data.frame("Type" = "Variance"), lmWithWhiteStdErrors(symbol^2, signal, HeteroSkedPValue)),
                         cbind(data.frame("Type" = "Abs Return"), lmWithWhiteStdErrors(abs(symbol), signal, HeteroSkedPValue)))
     
 
                                         res[["full_sample_regression_results"]] = fullregres
  
  
  #################################
  # Rolling predictive regression #
  #################################


                                         
  tempres = rollingPredictiveRegression(symbol, signal, rollRegLength, HeteroSkedPValue)
  
  tempressquared = rollingPredictiveRegression(symbol^2, signal, rollRegLength, HeteroSkedPValue)
  
  tempresabs = rollingPredictiveRegression(abs(symbol), signal, rollRegLength, HeteroSkedPValue)
  
  
  rollregres = rbind( tempres$rolling_regression,
                      tempressquared$rolling_regression,
                      tempresabs$rolling_regression )
  
  rownames(rollregres) = c("Return","Variance","Abs Return")
  
  res[["roll_regression_results"]] = rollregres
  

  rollregpred = merge(tempres$rolling_prediction,
                      tempressquared$rolling_prediction,
                      tempresabs$rolling_prediction)
  
  colnames(rollregpred) = c("Return","Variance","Abs Return")
  
  res[["roll_regression_prediction"]] = rollregpred
  

  
  ##################################################################
  # Create empirical cumulative distribution function %tile signal #
  ##################################################################
  
  # Creates signal that looks at where current month is in the ecdf, finds current %tile
  # using a rolling window

  if(ncol(signal) == 1){
       regdata = merge(symbol, signal)
       colnames(regdata) = c("reg_symbol","reg_signal")
       
       
       loadPackages("ggplot2")
     
       print(qplot(reg_signal, reg_symbol, data = regdata, geom = c("point","smooth"),
             xlab = colnames(signal), ylab = colnames(symbol)))
       
       print(qplot(reg_signal, reg_symbol^2, data = regdata, geom = c("point","smooth"),
                   xlab = colnames(signal), ylab = paste(colnames(symbol),"Squared")))
       
       if(nrow(regdata) < rollRegLength){
            stop(paste0("Have less data than rollRegLength, can't do rolling regression"))
       }
       
       ecdfpctile = createECDFPctile(regdata[,"reg_signal"], rollRegLength)
       
       res[["roll_signal_ecdf_pctile"]] = ecdfpctile
       
       
       
       roll_ecdf_full_sample_regres = rbind( lmWithWhiteStdErrors(symbol, ecdfpctile, HeteroSkedPValue),
                                             lmWithWhiteStdErrors(abs(symbol), ecdfpctile, HeteroSkedPValue),
                                             lmWithWhiteStdErrors(symbol^2, ecdfpctile, HeteroSkedPValue) )
       
       rownames(roll_ecdf_full_sample_regres) = c("Return","Variance","Abs Return")
       
       res[["roll_signal_ecdf_pctile_full_sample_regression_results"]] = roll_ecdf_full_sample_regres
       
       
       # browser()
       tempres = rollingPredictiveRegression(symbol, ecdfpctile, rollRegLength, HeteroSkedPValue)
       
       tempressquared = rollingPredictiveRegression(symbol^2, ecdfpctile, rollRegLength, HeteroSkedPValue)
       
       tempresabs = rollingPredictiveRegression(abs(symbol), ecdfpctile, rollRegLength, HeteroSkedPValue)
       
       roll_ecdf_roll_regres = rbind( tempres$rolling_regression,
                                      tempressquared$rolling_regression,
                                      tempresabs$rolling_regression)
       
       rownames(roll_ecdf_roll_regres) = c("Return","Variance","Abs Return")
       
       res[["roll_signal_ecdf_pctile_roll_regression_results"]] = roll_ecdf_roll_regres
       
       roll_ecdf_roll_prediction = merge(tempres$rolling_prediction, 
                                         tempressquared$rolling_prediction, 
                                         tempresabs$rolling_prediction)
       
       colnames(roll_ecdf_roll_prediction) =  c("Return","Variance","Abs Return")
       
       res[["roll_signal_ecdf_pctile_roll_regression_prediction"]] = roll_ecdf_roll_prediction
       
       ##############################################################
       # Tests for difference in means and vol for discrete signals #
       ##############################################################
       
       if(length(unique(signal)) == 2){
            # Discrete signal
            
            loadPackages(c("car","lawstat", "SharpeR"))
            
            # t-test for difference in means
            res[["t-test difference in means"]] = t.test(symbol[as.logical(signal)], symbol[!as.logical(signal)])
            
            
            
            # tests for difference in volatility
            
            res[["Brown Forsythe difference in volatility"]] = leveneTest(as.numeric(symbol), as.factor(as.numeric(signal)),median)
            # # res[["Brown Forsythe difference in volatility 2"]] = levene.test(as.numeric(symbol), as.factor(as.numeric(signal)))
            # # res[["Bartlett difference in volatility"]] = bartlett.test( as.numeric(symbol), as.factor(as.numeric(signal)))
            # # error check, implement Brown Forsythe with 2 different functions and
            # # compare results
            # if( abs( (res[["Brown Forsythe difference in volatility"]]$`Pr(>F)`[1] /
            #    res[["Brown Forsythe difference in volatility 2"]]$p.value) - 1 ) > DiffTolerance){
            #  stop("evaluateSignal error. Brown Forsythe test has issues.")
            # }
            
            # fligner.test( as.numeric(symbol),  as.factor(as.numeric(signal)))
            
            
            # test for difference in Sharpe
            # http://arxiv.org/pdf/1505.00829v2.pdf
            res[["difference in Sharpe"]] = sr_unpaired_test( list( as.sr( as.numeric(symbol[as.logical(signal)]) ),
                                                                    as.sr( as.numeric(symbol[!as.logical(signal)]) ) ) )
            # 
            #     
            #     library(boot)
            #     
            #     
            #     
            #     srres = sapply(1:1000, function(x){
            #       sr_unpaired_test( list( as.sr( sample( as.numeric(symbol[as.logical(signal)]), replace = T) ),
            #                               as.sr( sample( as.numeric(symbol[!as.logical(signal)]), replace = T) ) ) )$p.value
            #       
            #     })
            #     
            #     ecdf(srres)(res[["difference in Sharpe"]]$estimate)
            # 
            #     
            
            niceres = data.frame("Mean" = c(toPct(tapply(symbol, signal, mean) * AnnualizationFactor), toPct(res[["t-test difference in means"]]$p.value), as.character(index(symbol)[1]), as.character(index(symbol)[length(symbol)])),
                                 "Std" = c(toPct(tapply(symbol, signal, sd) * sqrt(AnnualizationFactor)), paste0(toPct(res[["Brown Forsythe difference in volatility"]]$`Pr(>F)`[1]))#,"/",toPct(res[["Bartlett difference in volatility"]]$p.value))
                                           ,"",""),
                                 
                                 "Sharpe" = c(round(tapply(symbol, signal, function(x){mean(x)/sd(x)}) * sqrt(AnnualizationFactor),2), toPct(res[["difference in Sharpe"]]$p.value) ,"",""),
                                 "# Obs" = c(length(signal[!as.logical(signal)]), length(signal[as.logical(signal)]),"","",""),
                                 stringsAsFactors = F, check.names = F)
            
            rownames(niceres) = c( signalOffName, signalOnName,"P-Value","Start","End")
            
            res[["Discrete Results"]] = niceres
            
            
            ####################
            # Trading strategy #
            ####################
            
            
            
            
            signalret = merge(symbol, symbol * signal, symbol * !signal)
            colnames(signalret) = c("All Months", signalOnName, signalOffName)
            
            signalret[signalret == 0] = NA
            signalres = calcSummaryStats2(signalret,symbol,colnames(symbol), AnnualizationFactor = AnnualizationFactor,shortSummary = T)
            
            res[["Trading Results"]] = signalres
       } else {
            
            #################################################################
            # Creating a z-score of signal and check discrete vs continuous #
            #################################################################
            
            #############################################
            # Evaluate Avg returns and Sharpe by bucket #
            #############################################
            
            signalz = createZScoreSignal(signalraw, zlength, -zLevelCap, zLevelCap, F, zlagMeanStd,  F)
            
            
            # plot by z only if we don't have all NAs
            if(!all(is.na(signalz))){
            
                common_months = getCommonMonths(symbolraw, signalz)
                symbol2 = symbol[common_months]
                signalz = signalz[common_months]
                
                signalz_disc = round(signalz * 2,0)/2
                # res[["z"]] = signalz
                res[["mean_by_z"]] = tapply(symbol2, signalz_disc, mean) * AnnualizationFactor
                res[["sharpe_by_z"]] = na.fill(tapply(symbol2, signalz_disc, function(x){mean(x)/sd(x)}) * sqrt(AnnualizationFactor),0)
                
                layout(matrix(1:2,ncol = 2))
                bp = barplot(res[["mean_by_z"]],
                             main = "Average Returns By Z",
                             ylab = "Average Returns",
                             xlab = "Z-Score")
                
                text(x = bp, y = res[["mean_by_z"]] * 1.02, 
                     labels = table(signalz_disc),
                     pos = ifelse(res[["mean_by_z"]] > 0, 1, 3), col = "red", cex = 1.1)
                abline(v = bp[ceiling(length(bp)/2)], col = "red")
                
                bp = barplot(res[["sharpe_by_z"]],
                             main = "Sharpe By Z",
                             ylab = "Sharpe",
                             xlab = "Z-Score")
                
                text(x = bp, y = res[["sharpe_by_z"]] * 1.02, 
                     labels = table(signalz_disc),
                     pos = ifelse(res[["sharpe_by_z"]] > 0, 1, 3), col = "red", cex = 1.1)
                abline(v = bp[ceiling(length(bp)/2)], col = "red")
                
                layout(1)
                
                res[["mean_by_z"]][] = toPct(res[["mean_by_z"]])
                
                sumRowsToGet = c("Mean","Stdev","Sharpe","Max DD","Worst Month",
                                 paste("Alpha",colnames(symbol2)), paste("Alpha",colnames(symbol2),"T-Stat"),
                                 paste(colnames(symbol2), "Beta"), "Start", "End")
                
                capOptions = c(0.0000001,0.5, 1, 1.5, 2)
                if(exists("dat")){
                          symbolToUse = if(colnames(symbol) %in% dat["monthly_return", mqaid]) {colnames(symbol)} else {"shy_backfilled"}
                } else {
                          symbolToUse = NULL
                }

                zres = sapply(capOptions, function(x){
                     
                     zsig = createZScoreSignal(signalraw, zlength, -x, x, squareResults = zsquareResults, 
                                               lagMeanStd = zlagMeanStd,  rescale = T)
                     # rescale to be between 0 and 1
                     zsig = (zsig + 1)/2
                     # plot(zsig, main = x)
                     zsigres = calcSummaryStats2(symbolraw * zsig, 
                                                 if(!is.null(symbolToUse)){symbolToUse} else {symbolraw * zsig},
                                                 if(!is.null(symbolToUse)){symbolToUse} else {"Self"})
                     zsigres = zsigres[sumRowsToGet,]
                     zsigres$`Avg Position` = toPct(mean(zsig))
                     
                     return(zsigres)
                })
                colnames(zres) = capOptions
                colnames(zres)[1] = "Discrete"
                
                # add Avg position to symbol results
                symbresadd = calcSummaryStats2(symbolraw[index(signalz)], symbolToUse,symbolToUse, AnnualizationFactor = AnnualizationFactor)[sumRowsToGet,]
                symbresadd$`Avg Position` = toPct(1)
                
                zres = cbind(symbresadd, zres)
                rownames(zres) = c(sumRowsToGet,"Avg Position")
                colnames(zres)[1] = colnames(symbol)
                
                res[["Z-Continuous"]] = zres
            }
            
       }
  }
  
  
  
  
  return(res)
}


# evaluateJointSignificanceDiscrete
# Evaluates joint statistical significance of a discrete binary signal

evaluateJointSignificanceDiscrete = function(myReturns, mySignal, 
                                             signalOnName = "Signal On", signalOffName = "Signal Off",
                                             rollRegLength = 5 * if (exists("AnnualizationFactor")) {
                                                  AnnualizationFactor
                                             } else {
                                                  12
                                             }){
     
     if(length(unique(mySignal)) != 2) stop("evaluateJointSignificanceDiscrete error: signal needs to be binary signal, all entries 0, 1, or F, T")

     checkNameSetup(myReturns, mySignal)
     
     myRownames = c("",paste0(signalOffName),paste0(signalOnName),"P-Value"," ","  ",
                    paste0(signalOffName," "),paste0(signalOnName," "),"P-Value ","   ","    ",
                    paste0(signalOffName,"  "),paste0(signalOnName,"  "),"P-Value  ","     ","      ",
                    paste0(signalOffName,"   "),paste0(signalOnName,"   "),"       ","        ",
                    "Start", "End")
     
     myResults = sapply(colnames(myReturns),function(name){
          print(name)
          
          # signal is if weight is above 0
          sig = mySignal[,name]
          
          if(length(unique(sig)) > 1){
               res = evaluateSignal(myReturns[,name], sig, rollRegLength = rollRegLength)
               res = res$`Discrete Results`
               
               returnres = data.frame("test" = c("Mean",res[1:3,1], "","Std", res[1:3,2], "", 
                                                 "Sharpe",res[1:3,3], "", "# Obs",res[1:2, 4], "", "Dates",res[4:5,1]),
                                      stringsAsFactors = F)
               
          } else {

               returnres = data.frame("test" = c("Mean",rep(NA,3), "","Std", rep(NA,3), "", 
                                                 "Sharpe",rep(NA,3), "", "# Obs",rep(NA,2), "", "Dates",rep(NA,2)),
                                      stringsAsFactors = F)
               
          }
          
          
          
          
          
          
          
          rownames(returnres) = myRownames
          
          colnames(returnres) = name
          
          
          
          return(returnres)
     })
     
     
     niceres = do.call(cbind,myResults)
     colnames(niceres) = colnames(myReturns)
     rownames(niceres) = myRownames
     
     # joint significance
     # t.test(fromPct(niceres[2,]), fromPct(niceres[3,]), paired = T)$p.value
     
     niceres = cbind(toPct(apply(niceres, 1, function(x){mean(fromPct(x), na.rm = T)})),niceres)
     niceres[niceres[,1] == "NA%" | niceres[,1] == "NaN%",1] = ""
     colnames(niceres)[1] = "Average (Joint Significance Test)"
     
     # mean
     niceres[4,1] = toPct(t.test(fromPct(na.omit(niceres[2,-1])), fromPct(na.omit(niceres[3,-1])), paired = T)$p.value)
     
     # volatility
     niceres[9,1] = toPct(t.test(fromPct(na.omit(niceres[7,-1])), fromPct(na.omit(niceres[8,-1])), paired = T)$p.value)
     
     # transform average sharpe and number of months from % to a number
     niceres[c(12,13,17,18),"Average (Joint Significance Test)"] = 
          fromPct(niceres[c(12,13,17,18),"Average (Joint Significance Test)"]) * 100
     
     niceres[1,1] = "Mean"
     niceres[6,1] = "Std"
     niceres[11,1] = "Sharpe"
     niceres[16,1] = "# Obs"
     niceres[20,1] = "Dates"
     niceres[21:22,1] = niceres[21:22,2]
     
     
     
     return(niceres)
}


# calcRiskParityWeights = function(tickers, myRisk = "roll_252_day_std_l1m", myTickerAdj = NULL, myTickerAdjFactor = NULL){
#   
#   # look up myRisk data if it is a character variable
#   # If its not a character variable, then it has to be an xts object
#   if(is.character(myRisk)){
#     
#     if(!(myRisk %in% dat[,unique(type)])){
#       stop(paste(myRisk,"not in dat"))
#     }
#     
#     risk = dat[.(myRisk, tickers)]
#     risk = datToXts(risk)
#   } else {
#     if(class(myRisk) != "xts") stop ("myRisk has to be either a character variable or xts object")
#   }
# 
#   
#   # Risk parity means weights are inversely related to risk
#   wt = 1/risk
#   
#   # standardized weights to sum to 1
#   wt = wt/rowSums(wt)
#   
#   wt = na.omit(wt)
#   
#   
#   # if tickerAdjFactor is not null, then we want to increase
#   # the weight of tickerAdj by tickerAdjFactor
#   
#   if(!is.null(myTickerAdjFactor) & !is.null(myTickerAdj)){
#     
#     # increase weight of myTickerAdj when spx is in an uptrend
#     wt[, myTickerAdj] = wt[, myTickerAdj] * myTickerAdjFactor
#     
#     wt_rest = xts(rowSums(wt[, setdiff(colnames(wt),myTickerAdj)]), index(wt))
#     wt_rest_target = 1 - wt[,myTickerAdj]
#     
#     wt_rest_adj_factor = wt_rest_target/wt_rest
#     
#     # setup the spx trend data to allow multiplication
#     wt_rest_adj_factor_other = xts(apply(wt[, setdiff(colnames(wt),myTickerAdj)], 2, 
#                                          function(x){x = as.numeric(wt_rest_adj_factor); return(x)}), index(wt_rest_adj_factor))
#     
#     wt[, setdiff(colnames(wt),myTickerAdj)] =  wt[, setdiff(colnames(wt),myTickerAdj)] *
#       wt_rest_adj_factor_other
# 
#   }
#   
#   # error check to ensure weights sum to 1
#   if(any(abs(rowSums(wt) - 1) > 0.0001)){
#     stop("calcRiskParityWeights weights don't sum to 1")
#   }
#   
#   return(wt)
# }

# getCommonMonths returns the intersection of the index of x and y
getCommonMonths = function(x,y){
  commonmonths = intersect(index(x), index(y))
  
  if(class(index(x)) != class(index(y))) stop("Index of x and y aren't of the same class")
  
  commonmonths = if(class(index(x)) == "yearmon"){
    as.yearmon(commonmonths)
  } else if (class(index(x)) == "Date"){
    as.Date(commonmonths)
  } else {
    stop("calcPortfolioReturnWithWeights supports only Date and yearmon class")
  }
  
  return(commonmonths)
}


# createHedgedReturns
# Calculates unlevered long short returns of 
# symbol1 beta hedged with symbol 2, or symbol1 - symbol 2
createHedgedReturns = function(symbol1, symbol2, betaHedge = T, 
                               myHedgeRollRegLength = 36, name = "", doReturnXts = T){
  
  if(is.character(symbol1)){
    symbol1 = returnsToXts(symbol1)
  }
  
  if(is.character(symbol2)){
    symbol2 = returnsToXts(symbol2)
  }
  symbol = na.omit(merge(symbol1,symbol2))
  colnames(symbol) = c(colnames(symbol1),colnames(symbol2))
  
  if(betaHedge){
    
    symbolbeta = xts(rollapplyr(index(symbol), myHedgeRollRegLength, function(x){
      x = setToDate(x, symbol)
      coef(lm(symbol[x, 1] ~ symbol[x,2]))[2]
    }, fill = NA), index(symbol))
    
    symbolbeta = na.omit(symbolbeta)
    
    symbolbeta = lagXts(symbolbeta, 1)
    
    
    symbolWeights = xts(merge(1, -symbolbeta), index(symbolbeta))
    colnames(symbolWeights) = colnames(symbol)
    
    symbolWeights = symbolWeights/rowSums(abs(symbolWeights))
    
    
  } else {
    symbolWeights = symbol
    symbolWeights[,1] = 1
    symbolWeights[,2] = -1
  }
  
  symbol = calcPortRet(symbol, symbolWeights, name,doReturnXts)
}


# printEvaluateSignal
# Tests whether the unlevered spread of symbol1 - symbol2,
# or symbol1 beta hedged with symbol2 is sensitive
# to a discrete binary signal
# 
# symbol1 = "splv"
# symbol2 = "spy"
# signal = gp >= 0
# name = "test"
# signalName = "test2"
# myRollRegLength = 12

printEvaluateSignal = function(symbol1, symbol2 = NULL, signal, 
                               name, signalName, betaHedge = T, myHedgeRollRegLength = 36,
                               myRollRegLength = 60){
  
  if(!is.null(symbol2)){
    symbol = createHedgedReturns(symbol1, symbol2, betaHedge, myHedgeRollRegLength)
  } else {
    if(is.character(symbol1)){
      symbol = returnsToXts(symbol1)
    } else {
      symbol = symbol1
    }
    
  }
  common_months = getCommonMonths(symbol, signal)
  symbol = symbol[common_months]
  signal = signal[common_months]
  
  
  if(myRollRegLength >= nrow(symbol)){
    stop(paste("Rolling regression length of",myRollRegLength,"longer than data"))
  }
  symbol_res = evaluateSignal(symbol, signal, rollRegLength = myRollRegLength)
  
  symbol = merge(symbol,symbol[index(signal)[signal]])
  colnames(symbol) = c(paste(name,"All Months"),paste(name,signalName))
  
  write.csv( calcSummaryStats2(symbol, symbol[,1],name), paste0(name,".csv"))
  write.csv(symbol_res[["Discrete Results"]],paste(name, signalName, "statistical_tests.csv"))
  
  cumsymbol = cumprod(1+na.fill(symbol,0))
  plot(cumsymbol[,2], ylim = c(min(cumsymbol),max(cumsymbol)),
       main = paste(name, signalName))
  lines(cumsymbol[,1], col = "red")
  legend("topleft", c(paste(name,"All Months"), paste(name, signalName)),
         text.col = c("black","red"), bty = "n")                 
  return(NULL)
}







calcPortfolioReturnWithWeights = function(tickers, retName = "monthly_return", weightFunction, ...){
  
  ret = dat[.(retName, tickers)]
  ret = datToXts(ret)
  ret = na.omit(ret)
  
  # wt = calcRiskParityWeights(tickers)
  wt = weightFunction(tickers, ...)
  
  commonmonths = getCommonMonths(ret, wt)
  
  ret = ret[commonmonths]
  wt = wt[commonmonths]
  
  # check if both ret and wt have the same column names
  if( length(setdiff(colnames(ret), colnames(wt))) > 0 |
      length(setdiff(colnames(wt), colnames(ret))) > 0 ){
    stop("calcPortfolioReturnWithWeights error: Column mismatch in ret and wt")
  }
  
  # ensuring column names in wt and ret are aligned
  ret = ret[,colnames(wt)]
  
  # wt = xts(apply(wt,2,function(x){x - mean(x)}), index(wt))
  # test = merge(wt[,"spy"], ret[,"spy"])
  
  portret = xts(rowSums(ret * wt), index(ret))
  
  return(portret)
}

calcFixedWeights = function(tickers, myweights, retName = "monthly_return",
                            myFullyInvested = T){
  
  if(myFullyInvested){
    if( abs(sum(myweights) - 1) > 0.0001 ){
      stop("Weights don't sum up to 1")
    }
  }

  
  wt = dat[.(retName, tickers)]
  wt = datToXts(wt)
  wt = na.omit(wt)
  
  for(i in 1:length(myweights)){
    wt[,tickers[i]] = myweights[i]
  }
  
  return(wt)
}

# getIngredientWeights("_60_40_fixed_weights_etf_portfolio_10pct_abs_ret")
# getIngredientWeights
# aggregates the weights of all the sub portfolios in name
getIngredientWeights = function(name, weight = NULL){
  
  if(dat[,class(mqaid)] != "character"){
    stop(paste("mqaid variable in dat has to be character type, but currently is",
               dat[,class(mqaid)]))
  }
  
  # Recursion
  # if data doesn't have weight, return a weight of 1 (100% in that last symbol)
  # if a data does have weight, return current weights * getIngredientWeights(subname)
  
  # weight only serves as to set up the xts for the final recursion step
  # weight is null in the first call
  
  # datToXts(dat[paste(name, "weights", sep = "_")])
  
  
  if( nrow(dat[paste(name, "weights", sep = "_")])  == 1 ){
    if(is.null(weight)){
      # if name isn't in weight, and this is the first call
      stop(paste(name,"doesn't have weights in dat"))
    } else {
      # if there is no further weight subdivision, return 1
      return(xts(rep(1, nrow(weight)), index(weight)))
    }

  } else {
    
    if( any(abs(rowSums(datToXts(dat[paste(name, "weights", sep = "_")])) - 1) > 0.0001) ){
      warning(paste0(name," sub components weights don't sum to 1"))
    } else if( any(abs(rowSums(abs(datToXts(dat[paste(name, "weights", sep = "_")]))) - 1) > 0.0001) ){
      stop(paste0(name," sub components absolute weights don't sum to 1"))
    }
    
    # if there is further subdivision, return current weights * getIngredientWeights(subname, subweight)
    res = lapply(dat[paste(name, "weights", sep = "_"),unique(mqaid)],
                 function(x){
#                    print(name)
#                    print(nrow(dat[paste(name, "weights", sep = "_")]))
#                    print(dat[paste(name, "weights", sep = "_")])
#                    
                   comp_weight = datToXts(dat[paste(name, "weights", sep = "_")])[,x]
                   
                   sub_comp_weight = getIngredientWeights(x, comp_weight)
                   
                   # need to set the sub_comp_weight to same dates as
                   common_months = getCommonMonths(comp_weight, sub_comp_weight)
                   
                   if(ncol(sub_comp_weight) == 1){
                     
                     return( sub_comp_weight[common_months] * 
                               comp_weight[common_months])
                   } else {
                     
                     sub_comp_weight = xts(apply(sub_comp_weight[common_months],2,
                                                 function(y){
                                                   y = xts(y, common_months)
                                                   y * comp_weight[common_months]
                                                 }), 
                                           common_months)
                     
                     return(sub_comp_weight)
                   }
                   
                   
                 })
    
    names(res) = dat[paste(name, "weights", sep = "_"),unique(mqaid)]
    
    for(i in names(res)){
      
      dat_wt = datToXts(dat[paste(name, "weights", sep = "_")])[,i]
      res_wt = xts(rowSums(res[[i]]), index(res[[i]]))
      
 
      if(length(setdiff(index(dat_wt), index(res_wt))) > 0){
        # Dat can have weights if res doesn't
        # example is positions calculated using a differnt symbol, such as
        # underlying index, but returns come from ETFs with shorter history
        warning("getIngredientWeights issue: dat has these extra dates where res doesn't for:",i)
        print(round(setdiff(index(dat_wt), index(res_wt)),2))
      }
      
      if(length(setdiff(index(res_wt), index(dat_wt))) > 0){
        # Res should never have dates that dat doesn't
        stop("getIngredientWeights issue: res has these extra dates where dat doesn't for:", i)
        print(round(setdiff(index(res_wt), index(dat_wt)),2))
      }
    }
    
    
    # Need to check if there is any overlap in the tickers between res
    res_tickers = unlist(lapply(res,function(x){
      colnames(x)
    }))
    
    # if any mqaid is duplicated, we need to combine them first
    # otherwise merge data
    if( any(duplicated(res_tickers)) ){
      
      # If we have duplicated tickers in res
      # we need to sum them together for each mqaid
      
      # need to set data to same starting point
      # Find the intersect of all the indices
      common_months = getCommonMonths(res[[1]],res[[2]])
      if(length(res) > 2){
        for(i in 3:length(res)){
          common_months = intersect(common_months, index(res[[i]]))
        }
      }
      if(class(index(res[[1]])) == "yearmon"){
        common_months = as.yearmon(common_months)
      } else if(class(index(res[[1]])) == "Date"){
        common_months = as.Date(common_months)
      } else {
        stop("support only yearmon or Date")
      }
      
      # set to same dates
      for(i in 1:length(res)){
        res[[i]] = res[[i]][common_months]
      }
      
      
      
      
      
      # start with error checks to ensure all the elements in res have the same dates setup
      if(max(sapply(res, nrow)) != min(sapply(res, nrow))){
        stop("getIngredientWeights error: res elements don't have the same number of rows")
      }
      
      if(max(sapply(res,function(x){index(x)[1]})) !=
         min(sapply(res,function(x){index(x)[1]}))){
        stop("getIngredientWeights error: res elements don't have the same start date")
      }
      
      if(max(sapply(res,function(x){index(x)[nrow(x)]})) !=
         min(sapply(res,function(x){index(x)[nrow(x)]}))){
        stop("getIngredientWeights error: res elements don't have the same end date")
      }
      
      wt = xts(matrix(rep(NA, length(unique(res_tickers)) * nrow(res[[1]])), 
                      ncol = length(unique(res_tickers))), index(res[[1]]))
      
      
      colnames(wt) = unique(res_tickers)
      
      for(mqaid in unique(res_tickers)){
        res_ticker_entry = lapply(res,function(x){x[,mqaid]})
        res_ticker_entry = do.call(merge, res_ticker_entry)
        
        # sum up over dates
        res_ticker_entry = xts(rowSums(res_ticker_entry), index(res_ticker_entry))
        
        wt[,mqaid] = res_ticker_entry
      }
      
      
      # final error to check that rowSums of wt is the same as of dat big group
      # when doing unlevered long short, weights won't sum to 1, give warning in this case
      # but sum of absolute weights should always sum to 1
      if( any(abs(xts(rowSums(wt),index(wt)) - 
                  xts(rowSums(datToXts(dat[paste(name, "weights", sep = "_")])),
                      index(datToXts(dat[paste(name, "weights", sep = "_")])))) > 0.0001) ){
        warning(paste("getIngredientWeights error:", name,"Final ingredient weights don't sum up to the aggregate dat weight"))
      } else if( any(abs(xts(rowSums(abs(wt)),index(wt)) - 
                         xts(rowSums(abs(datToXts(dat[paste(name, "weights", sep = "_")]))),
                             index(datToXts(dat[paste(name, "weights", sep = "_")])))) > 0.0001) ){
        stop(paste("getIngredientWeights error:", name,"Final ingredient absolute weights don't sum up to the aggregate dat weight"))
      }
      
      res = wt
      
    } else {
      resnames = sapply(res,colnames)
      finalres = do.call(merge, res)
      colnames(finalres) = resnames
      
      # check that each name in finalres has same returns as it does in res
      # loop over entries in res
      for(res_entry in res){
        # loop over columns in res_entry
        for(name in colnames(res_entry)){
          if(any(res_entry[,name] != finalres[,name])){
            stop("Error in renaming weights when combining weights")
          }
        }
      }
        
    
    }
  }
  return(finalres)
}

# aggregateWeightTypes

# If we use getIngredientWeights to look a portfolio it up
# some portfolio types, such as _backfilled, or _index
# might have a mqaid show up as xle, xle_backfilled
# need to remove _backfilled, and _index from tickers, and aggregate them

aggregateWeightTypes = function(wt){
  if(class(wt)[1] != "xts") stop("aggregateWeightTypes requires xts object")
  
  wt = xtsToDat(wt,"weights")
  setkey(wt, mqaid)
  
  # If we use getIngredientWeights to look a portfolio it up
  # some portfolio types, such as _backfilled, or _index
  # might have a mqaid show up as xle, xle_backfilled
  # need to remove _backfilled, and _index from tickers, and aggregate them
  wt[, mqaid := gsub("_backfilled|_index","",mqaid)]
  # aggregate same mqaid together, in case it shows up as
  # _backfilled, and with no addition, or with _index, and no addition
  wt[, value := sum(value), keyby = .(year_mon, mqaid)]
  wt = unique(wt)
  
  wt = datToXts(wt)
  
  return(wt)
}


# plotWeights
# Creates filled area plots of weights over time, can be grouped by anything
# portfolio = wt
# portfolio = portfolio[,setdiff(colnames(portfolio),c("shv","shv_index","shv_backfilled"))]
# 
# portfolio = "msci_acwi_backfilled_portfolio"
# etf_group = "sub_group"
# plotTitle = "Global Macro Equity Region Allocation"
# grouping = etfs
# legendBottom = T
# scaleByAbsWt = T

plotWeights = function(portfolio, etf_group, plotTitle = "", grouping = etfs, 
                       scaleByAbsWt = T, legendBottom = F){
  
  if(is.character(portfolio)){
    wt = getIngredientWeights(portfolio)
  } else {
    wt = portfolio
  }
  
  
  # We need to rescale the weights, as the weights in dat
  # have been created such that results from getIngredientWeights
  # will have sum of absolute value of 1
  # some asset classes like strategic factors have fixed weights
  # in the first layer of weights, but at component levels
  # have weights that swing around
  # so first layer of weights, dat["port_weights"] might have
  # sum of absolute weights above 1, but once multiplied through
  # with the ingredient weights, it becomes equal or less than 1
  for(i in colnames(wt)){
    if(nrow(dat[paste(i,"weights", sep = "_")]) > 1){
      tempwt = getIngredientWeights(i)
      tempwt = abs(tempwt)
      tempwt = tempwt[index(wt)]
      wt[,i] = wt[,i] * xts(rowSums(tempwt),index(tempwt))
    }
  }
  
  if(scaleByAbsWt){
    wt = abs(wt)
    wt_before = xts(rowSums(wt), index(wt))
    wt = wt/rowSums(wt)
    wt_after = xts(rowSums(wt), index(wt))
    
    plot(wt_before, main = "Weights before Scaling")
    lines(wt_after, col = "red")  
  }
  
  wt = aggregateWeightTypes(wt)
  wt = xtsToDat(wt,"weights")
#   wt = xtsToDat(wt,"weights")
#   setkey(wt, mqaid)
#   
#   # If portfolio is character, so we use getIngredientWeights to look it up
#   # some portfolio types, such as _backfilled, or _index
#   # might have a mqaid show up as xle, xle_backfilled
#   # need to remove _backfilled, and _index from tickers, and aggregate them
#   if(is.character(portfolio))   wt[, mqaid := gsub("_backfilled|_index","",mqaid)]
#   # aggregate same mqaid together, in case it shows up as
#   # _backfilled, and with no addition, or with _index, and no addition
#   wt[, value := sum(value), keyby = .(year_mon, mqaid)]
#   wt = unique(wt)
#   
  if(is.null(grouping)){
    setnames(wt, "mqaid","group")
  } else {
    grouping_key = key(grouping)
    setkey(grouping, mqaid)
    
    wt[, group:=grouping[mqaid, get(etf_group)]]
    
    grouping[wt[,mqaid]]
    if(wt[,any(is.na(group))]){
      stop(paste(c("Following tickers don't have a grouping",wt[which(is.na(group)),unique(mqaid)]), collapse = "\n"))
    }
    wt = wt[, sum(value), keyby = .(year_mon, group)]
    setnames(wt, "V1","value")
    
    setkeyv(grouping, grouping_key)
  }

  if(!require(dplyr, quietly = T)) {
    install.packages("dplyr")
    print("Installed package dplyr")
  }
  
  if(!require(ggplot2, quietly = T)) {
    install.packages("ggplot2")
    print("Installed package ggplot2")
  }
  
  if(!require(RColorBrewer, quietly = T)) {
    install.packages("RColorBrewer")
    print("Installed package RColorBrewer")
  }
  
  # Re order data so that equities and bonds show up next to each other
  if("Equities" %in% wt[,unique(group)] &
     "Bonds" %in% wt[,unique(group)]){
     
    setkey(wt, group, year_mon)
    wt = wt[c("Bonds","Equities",setdiff(wt[,unique(group)],c("Bonds","Equities")))]
    wt[, group := factor(group, levels = rev(c("Bonds","Equities",setdiff(wt[,unique(group)],c("Bonds","Equities")))))]
  } else {
    setkey(wt, group, year_mon)
    wt[, group := factor(group, levels = rev(wt[,unique(group)]))]
  }
  
  if(legendBottom){
    legPos = "bottom"
  } else {
    legPos = "right"
  }
  
  mycolors = brewer.pal(name = "Set1", n = wt[,length(unique(group))])
  mycolors = rev(mycolors)  
  
  
  ggplot(wt, aes(x = as.numeric(year_mon), y = value, fill = group, order = -as.numeric(group))) + 
    geom_area(aes(ymin = 0, ymax = 1, x = as.numeric(year_mon))) +
    # scale_fill_brewer(palette="Set1") +
    scale_fill_manual(values=mycolors) + 
    ylab("Weight\n") + xlab("") + 
    ggtitle(paste0(plotTitle,"\n")) + 
    theme(plot.title = element_text(size=20, face="bold"),
          # axis.title.x = element_text(size = 17.5),
          axis.title.y = element_text(size = 15),
          axis.text.x = element_text(size = 15),
          axis.text.y = element_text(size = 15),
          legend.title = element_blank(),
          legend.text = element_text(size = 15),
          legend.position= legPos)
  
  ggsave(paste0(plotTitle,".png"))
  
  wt = datToXts(wt,"group")
  write.csv(data.frame(wt, check.names = F), paste0(plotTitle,".csv"))
  
  write.csv(colMeans(wt), paste0(plotTitle," average weights.csv"))
  
  # legend.direction = "horizontal")
}


# getStartDatesXts
# Takes in an xts object, and gives the index of the first non NA value
# for each column

getStartDatesXts = function(x){
  res = apply(x,2, function(y){
    findna = as.numeric(is.na(y)) * (1:length(y))
    # set all entries after first 0 to 0
    # this is to avoid an NA at end of data, to become the start point
    findna[min(which(findna == 0)):length(findna)] = 0
    index(x)[max(1, max(findna) + 1)]})
  
  if(class(index(x)) == "yearmon"){
    return(as.yearmon(res))
  } else if(class(index(x)) == "Date"){
    return(as.Date(res))
  } else {
    return(res)
  }
}

# calcNetReturns
# Subtracts cost and fee assumptions from returns

calcNetReturns = function(x){
  feefile = "C:/local_quant_qsf/Quant/qsf_etf/IMPLEMENTATION/Products_Fees_Costs.csv"
  
  if( file.exists(feefile) ){
    
    fees = read.csv(feefile, check.names = F, stringsAsFactors = F)
    
    print("Calculating net returns by subtracting all fees and costs")
    
    # Some scripts will add Long to the end of product name
    # to mean long only version, or (Old) or (New) when we are comparing
    # older research version to new
    # we still want to subtract fees and cost even if these things are 
    # in the name
    nameItemsToRemove = " [(]Old[)]| [(]New[)]| Long"
    
    for(i in colnames(x)){
      if(gsub(nameItemsToRemove,"", i) %in% colnames(fees)){
        x[,i] = x[,i] - sum(fees[,gsub(nameItemsToRemove,"", i)])/AnnualizationFactor
      } else {
        warning(paste(i,"isn't in the fee file. Will use gross for",i))
      }
      
    }
  } else {
    warning("Fee file doesn't exists. Will use gross returns.")
  }
  
  return(x)
}






calculateETFFees = function(name, x = NULL, wt_list = NULL){
  

  if(nrow(dat[paste(name,"weights", sep = "_")]) > 1){
    wt = getIngredientWeights(name)
  } else {
    wt = wt_list[[name]]
  }
  
  
  if(is.null(wt)){
    if(!is.null(x)){
      histfees = x
      histfees[,] = NA
      return(histfees)
    } else {
      warning(paste(name,"weights aren't in dat"))
      return(NA)
    }

  }
  if(!is.null(x)){
    wt = wt[index( na.omit(x[,name]) )] 
  }
  
  # remove backfilled and index from the ticker name
  # to look up the weights
  colnames(wt) = gsub("_backfilled|_index","",colnames(wt))
  
  
  if( nrow(dat["etf_fees"]) > 1 ){
    

    
    fees = datToXts(dat[.("etf_fees", colnames(wt))])
    
    # if fees has 1 NA row, then the mqaid needs to add mqaidAdjustment.
    if(nrow(fees) <= 1){
      fees = datToXts(dat[.("etf_fees", adjustMqaid(colnames(wt)))])
      colnames(fees) = gsub(mqaidAdjustment(),"",colnames(fees))
    }
    
    if( length(setdiff2(colnames(wt),colnames(fees))) > 0 ){
      stop("Fees and weights not alligned up")
    }
    
    fees = fees[index(wt),]
    
    # return NA if have no fee data
    if(nrow(fees) == 0) return(NA)
    
    for(i in colnames(wt)){
         

      if(any(is.na(wt[,i]) & !is.na(fees[,i])) |
        any(!is.na(wt[,i]) & is.na(fees[,i]))){
        warning(paste("Inconsistentcy between weight and fee data for",i))
      }

    }
    
    histfees = xts(rowSums(abs(wt) * na.fill(fees,0)), index(wt))
    
    # # Lookup in fees will depend on whether we have mqaid or tickers
    # # in column names. Fees has tickers.
    # if( all( is.na(tickerToMqaid(colnames(wt))) ) & 
    # !all( is.na(mqaidToTicker(colnames(wt))) ) ){
    #   # if we have mqaid in column names
    #   fees[, mqaid := tickerToMqaid(ETF)]
    #   setkey(fees, mqaid)
    #   
    # 
    #   curfee = wt[nrow(wt),] %*% fees[colnames(wt),`Expense ratio`]
    #   avgfee = mean(wt[(nrow(wt)-11):nrow(wt),] %*% fees[colnames(wt),`Expense ratio`])
    # } else if( !all( is.na(tickerToMqaid(colnames(wt))) ) & 
    #            all( is.na(mqaidToTicker(colnames(wt))) ) ){
    #   # if we have ticker in column names
    #   setkey(fees,ETF)
    #   
    #   curfee = wt[nrow(wt),] %*% fees[colnames(wt),`Expense ratio`]
    #   avgfee = mean(wt[(nrow(wt)-11):nrow(wt),] %*% fees[colnames(wt),`Expense ratio`])
    # } else {
    #   curfee = NA
    #   avgfee = NA
    # }
  } else {
    histfees = xts(rep(NA, nrow(wt)), index(wt))
  }
  
  return(histfees)
}

# 
# # # #dm_region_port
# x = ret
# benchmark = ret[,"60/40"]
# benchmark_name = "mom"
# AnnualizationFactor = 12
# ratioAdd = 0.2
# createPlots = F
# plotNames = colnames(x)
# period = "Month"
# shortSummary = T
# doFF = F
# wt_list = NULL # can supply weights to calculate turnover and number of securities
# increaseDownsideSkipFirst = 2 # how many of the first entries should we skip?
# # Assume first entries can be benchmarks
# # defaults to number of columns in x, no downside adjustment
# increaseDownsideSharpe = NULL # if NULL, uses the Sharpe, otherwise uses this
# netReturns = F  #, if T, will read in the fee file and subtract fees and costs
# marketing = F # if T, will adjust the short summary to remove turnover
#               # and add ETF fees

calcSummaryStats2 = function(x, benchmark = "bm_60_40", benchmark_name = "60/40", AnnualizationFactor = 12, ratioAdd = 0.2,
                             createPlots = F, plotNames = colnames(x), 
                             period = "Month", shortSummary = T, 
                             doFF = F, wt_list = NULL,
                             increaseDownsideSkipFirst = ncol(x),
                             increaseDownsideSharpe = NULL, netReturns = F,
                             marketing = F,
                             modifiedSharpe = F){
  
  if(!exists("RoundCoef")) RoundCoef = 2
  # x = na.omit(x)
  
#   if(ncol(x) == 2){
#     x = merge(x, (1 - ratioAdd) * x[,1] + ratioAdd * x[,2])
#     colnames(x)[ncol(x)] = paste((1-ratioAdd) * 100,colnames(x)[1], ratioAdd * 100, colnames(x)[2])
#   }
  
  if(is.character(x)){
    xname = x
    x = returnsToXts(x)
    
    if(nrow(x) == 1) stop(paste(xname,"isn't in dat monthly returns, and therefore can't be used to calculate summary stats"))
  }
  
  if(is.null(increaseDownsideSharpe) & increaseDownsideSkipFirst < ncol(x)){
    
    if(increaseDownsideSkipFirst == 0){
      increaseDownsideSharpe = apply(x,2,function(y){mean(y)/sd(y) * sqrt(AnnualizationFactor)})
    } else {
      increaseDownsideSharpe = apply(x[,-(1:increaseDownsideSkipFirst)],2,function(y){mean(y)/sd(y) * sqrt(AnnualizationFactor)})
    }
    
    increaseDownsideSharpe= as.numeric(increaseDownsideSharpe)
  }
  
  if(netReturns){
    
    x = calcNetReturnsLive(x)
    
  }
  
  
  
  
  
  # get BMK bmk data
  if(is.character(benchmark)){
    xbm = returnsToXts(unique(benchmark))
    
    if(nrow(xbm) == 1) stop(paste(benchmark,"isn't in dat monthly returns, and therefore can't be used as benchmark"))
  } else {
    xbm = benchmark
  }
  
  if(modifiedSharpe) {
    rf_rate = returnsToXts("monthly_treasury_bill_rates_1m")
  } else {
    rf_rate = NULL
  }
  # xbm = do.call(merge,lapply(benchmark,function(name){xbm[,name]}))
  # if we don't have 60 40 data
  if(nrow(xbm) == 0){
    missing_benchmark = T
  } else {
    missing_benchmark = F
  }
  
  if(missing_benchmark){
      xbm = x
      xbm[] = 0
  }
  if(exists("dat")){
      mkt = datToXts(dat[.("monthly_return","ada_mkt_backfilled")])
      if(nrow(mkt) <= 1){
        mkt = returnsToXts("SPY")
      }
  } else {
    mkt = xbm
  }

  # commonmonthsmkt = getCommonMonths(mkt, x)
  # commonmonthsxbm = getCommonMonths(xbm, x)
  
  ######################################
  # Set X and benchmark to same months #
  ######################################
  
  for(i in 1:ncol(x)){
    # find first non NA
    
    if(ncol(xbm) == 1){
      common_months = getCommonMonths(na.omit(x[,i]),xbm)
      x[!(index(x) %in% common_months), i] = NA
    } else {
      common_months = getCommonMonths(na.omit(x[,i]),xbm[,benchmark[i]])
      x[!(index(x) %in% common_months), i] = NA
      # xbm[!(index(xbm) %in% common_months), i] = NA      
    }
  }
  
  
  
  
  
  
  if(is.null(colnames(x))){
    colnames(x) = as.character(1:ncol(x))
  }
  
  temp = sapply(colnames(x),function(name){
    print(name)
    y = na.omit(x[,name])
    
    commonmonthsmkt = getCommonMonths(mkt, y)
    commonmonthsxbm = getCommonMonths(if(ncol(xbm) == 1){xbm} else {xbm[,benchmark[name]]}, y)

    ybmk = if(ncol(xbm) == 1){xbm[commonmonthsxbm]} else {xbm[commonmonthsxbm,benchmark[name]]}
    
    y = y[commonmonthsxbm]
    yactive =  y - ybmk
    
    if ((exists("rf_rate")) & (modifiedSharpe)) {
        yrf = rf_rate[commonmonthsxbm]
        y_yrf = y - yrf
    }
    
   # cumulative returns
     cumy = cumprod(1+y)
     
     # need to add 1 in front, in order to catch a drawdown if it happens in a single month that
     # is the first return entry, cumprod(1 + y) will show 1 + month 1 return for that month,
     # and when compare cumprod with cummax(cumprod), will miss that first month
     cumy = rbind(xts(1, min(index(y)) - 1/AnnualizationFactor), cumy)
     cumy/lagXts(cumy, 12) - 1
     
     # calendar year end values
     calyvalues = cumy[substr(as.character(index(cumy)), 1, 3) == "Dec"]
     
     c("Mean" = mean(y) * AnnualizationFactor,
      "Stdev" = sd(y) * sqrt(AnnualizationFactor),
      "Downside Deviation" = sqrt(mean((y[y<0]^2))) * sqrt(AnnualizationFactor),
      "Sharpe"= ifelse(modifiedSharpe, sqrt(AnnualizationFactor)*mean(y_yrf)/sd(y), sqrt(AnnualizationFactor)*mean(y)/sd(y)),
      "Sortino" = mean(y)/sqrt(mean((y[y<0]^2))) * sqrt(AnnualizationFactor),
      "% Positive" = mean(y >= 0),
      "Max DD" = min(cumy/cummax(cumy) - 1),
      # "Worst Rolling 12 Periods" = min(cumy/lagXts(cumy, 12) - 1),
      # "Worst Calendar Year" = min(calyvalues/lag(calyvalues, 1) - 1, na.rm = T),
      "Worst Period" = min(y),
      "Mean vs BMK" = mean(yactive) * AnnualizationFactor,
      "TE vs BMK" = sd(yactive) * sqrt(AnnualizationFactor),
      "IR" = mean(yactive)/sd(yactive) * sqrt(AnnualizationFactor),
      "Up Capture" =  ifelse(sum(ybmk > 0) > 0, (cumprod(1+y[ybmk > 0])[length(y[ybmk > 0])]^(1/length(y[ybmk > 0])) - 1)/
        (cumprod(1+ybmk[ybmk > 0])[length(ybmk[ybmk > 0])]^(1/length(ybmk[ybmk > 0])) - 1), NA),
      "Down Capture" = ifelse( sum(ybmk < 0) > 0, (cumprod(1+y[ybmk < 0])[length(y[ybmk < 0])]^(1/length(y[ybmk < 0])) - 1)/
        (cumprod(1+ybmk[ybmk < 0])[length(ybmk[ybmk < 0])]^(1/length(ybmk[ybmk < 0])) - 1), NA),
      "% >= BMK" = mean(yactive >= 0),
      "Max DD vs BMK" = min(cumprod(1+yactive)/cummax(cumprod(1+yactive)) - 1),
      "Worst Period vs BMK" = min(yactive),
      "Timing of Worst Per" = index(yactive)[which.min(yactive)])
  })
  
  
  if(increaseDownsideSkipFirst < ncol(x)){
  
    if( is.null(increaseDownsideSharpe) ){
      stop()
    }
    
    if(increaseDownsideSkipFirst == 0){
      print("Adjusting downside risks")
      # assume the benchmark is in the first column
         
      temp["Max DD",] = temp["Max DD",] * getDownsideAdjustment(increaseDownsideSharpe)
      
      # temp["Worst Rolling 12 Periods",] = temp["Worst Rolling 12 Periods",] * getDownsideAdjustment(increaseDownsideSharpe)
      
      # temp["Worst Calendar Year",] = temp["Worst Calendar Year",] * getDownsideAdjustment(increaseDownsideSharpe)
      
      temp["Worst Period",] = temp["Worst Period",] * getDownsideAdjustment(increaseDownsideSharpe)
      
      temp["Down Capture",] = temp["Down Capture",] * getDownsideAdjustment(increaseDownsideSharpe)
      
    } else {
      print(paste("Adjusting downside risks, assuming benchmark is in first", increaseDownsideSkipFirst,"column"))
      # assume the benchmark is in the first column
      temp["Max DD",-(1:increaseDownsideSkipFirst)] = 
        temp["Max DD",-(1:increaseDownsideSkipFirst)] * getDownsideAdjustment(increaseDownsideSharpe)
      
      # temp["Worst Rolling 12 Periods",-(1:increaseDownsideSkipFirst)] = 
           # temp["Worst Rolling 12 Periods",-(1:increaseDownsideSkipFirst)] * getDownsideAdjustment(increaseDownsideSharpe)
      
      # temp["Worst Calendar Year",-(1:increaseDownsideSkipFirst)] = 
           # temp["Worst Calendar Year",-(1:increaseDownsideSkipFirst)] * getDownsideAdjustment(increaseDownsideSharpe)
      
      temp["Worst Period",-(1:increaseDownsideSkipFirst)] = 
        temp["Worst Period",-(1:increaseDownsideSkipFirst)] * getDownsideAdjustment(increaseDownsideSharpe)
      
      temp["Down Capture",-(1:increaseDownsideSkipFirst)] = 
        temp["Down Capture",-(1:increaseDownsideSkipFirst)] * getDownsideAdjustment(increaseDownsideSharpe)
    }
    
    
  }
  
  ### Add information on turnover, average number of holdings, etf fees
  temp = rbind(temp, sapply(colnames(x),function(name){
    print(name)
    
    if(exists("dat")){
        if(nrow(dat[paste(name,"weights", sep = "_")]) > 1 | !is.null(wt_list)){
          
          if(nrow(dat[paste(name,"weights", sep = "_")]) > 1){
            wt = getIngredientWeights(name)
          } else {
            wt = wt_list[[name]]
          }
          
          wt = wt[index( na.omit(x[,name]) )]
          wt_fees = list()
          wt_fees[[name]] = wt
          # wt = aggregateWeightTypes(wt)
          
          if(is.null(wt)){
            warning(paste("dat doesn't have returns for the mqaid in the portfolio",
                          colnames(wt),"\n"))
            
            return(c("Avg Turnover" = NA,
                     "Fixed Trading Cost" = NA,
                     "Avg # Holdings" = NA,
                     "Current ETF Fee" = NA,
                     "ETF Fee 1Y Avg" = NA,
                     "Rebalancing Freq" = period))
          }
          
          if(nrow(wt) == 1){
            warning(paste("dat doesn't have returns for the mqaid in the portfolio",
                          colnames(wt),"\n"))
            
            return(c("Avg Turnover" = NA,
                     "Fixed Trading Cost" = NA,
                     "Avg # Holdings" = NA,
                     "Current ETF Fee" = NA,
                     "ETF Fee 1Y Avg" = NA,
                     "Rebalancing Freq" = period))
          }
          
          # Need to ensure I get backfilled ETF returns, as weights might have
          # non zero weights for an ETF, where index return was used
          # need to use backfilled returns to calculate turnover
          ret_to_get = colnames(wt)
          ret_to_get[!grepl("_backfilled|_index", ret_to_get)] = 
            paste(ret_to_get[!grepl("_backfilled|_index", ret_to_get)],"backfilled", sep = "_")
          
          ret = returnsToXts(ret_to_get)
          
          # get fixed trading costs
          fixed_trading_costs = calcFixedTransactionCosts(wt)
          fixed_trading_costs = xts(rowSums(fixed_trading_costs), index(fixed_trading_costs))
          
          # set weights and returns to same period    
          common_months = getCommonMonths(wt,ret)
          wt = wt[common_months]
          ret = ret[common_months]
          
          # calculate how much each weight grows
          wt_eom = wt * na.fill(1 + ret, 0)
          # rescale weights so they sum to 1
          wt_eom = wt_eom/rowSums(abs(wt_eom), na.rm = T)
          
          # lag wt_eom, to correspond to same date as start of next month
          wt_eom = lagXts(wt_eom, 1)
          
          # rescale weights so they sum to 1
          wt = wt/rowSums(abs(wt), na.rm = T)
          
          trading = wt_eom - wt
          
          trading = xts(rowSums(abs(trading), na.rm = T), index(trading))
          trading = trading[index(x)]
          
          
          # calculate ETF fees
          histfees = calculateETFFees(name, x, wt_fees)
          curfee = histfees[nrow(histfees)]
          
          if(length(histfees) >= 12)
          {
               avgfee = mean(histfees[(nrow(histfees)-11):nrow(histfees)])
          } else
          {
               avgfee = NA
               if(length(curfee) == 0) curfee = NA
          }
          
          
          return(c("Avg Turnover" = mean(trading) * 12,
                   "Fixed Trading Cost" = mean(fixed_trading_costs) * 12,
                   "Avg # Holdings" = mean(rowSums(abs(na.fill(wt, 0)) > 0.00001)),
                   "Current ETF Fee" = curfee,
                   "ETF Fee 1Y Avg" = avgfee,
                   "Rebalancing Freq" = period))
         } else {
              return(c("Avg Turnover" = NA,
                       "Fixed Trading Cost" = NA,
                       "Avg # Holdings" = NA,
                       "Current ETF Fee" = NA,
                       "ETF Fee 1Y Avg" = NA,
                       "Rebalancing Freq" = period))
         }
    } else {
      return(c("Avg Turnover" = NA,
               "Fixed Trading Cost" = NA,
               "Avg # Holdings" = NA,
               "Current ETF Fee" = NA,
               "ETF Fee 1Y Avg" = NA,
               "Rebalancing Freq" = period))
    }
    
  }))
    
  
  


  # Regression against market
  temp = rbind(temp,sapply(colnames(x),function(name){
    y = na.omit(x[,name])
    
    commonmonthsmkt = getCommonMonths(mkt, y)
    
    if(length(commonmonthsmkt) < 2){
      return(c("Alpha mkt" = NA,
               "Alpha T-Stat" = NA, "mkt Beta" = NA,
               "mkt Correlation" = NA))
    } else {
      lmres = lm(y[commonmonthsmkt] ~ mkt[commonmonthsmkt])
      return(c("Alpha mkt" = coef(lmres)[1] * AnnualizationFactor,
        "Alpha T-Stat" = summary(lmres)$coef[1,"t value"], "mkt Beta" = coef(lmres)[2],
        "mkt Correlation" = cor(y[commonmonthsmkt],mkt[commonmonthsmkt])))
    }

    
  }))
  
  rownames(temp)[(nrow(temp)-3):nrow(temp)] = c("Alpha mkt", "Alpha mkt T-Stat","mkt Beta","mkt Correlation")
  
  if(doFF){
    # Regression against market
    temp = rbind(temp,sapply(colnames(x),function(name){
      y = na.omit(x[,name])
      
      xvars = returnsToXts(c("mkt","ff_mom","ff_hml","ff_smb"))
      commonmonthsxvars = getCommonMonths(xvars, y)
      
      lmres = lm(y[commonmonthsxvars] ~ xvars[commonmonthsxvars])
      c("Alpha FF" = coef(lmres)[1] * AnnualizationFactor,
        "Alpha FF T-Stat" = summary(lmres)$coef[1,"t value"],
        "mkt Beta FF" = coef(lmres)[2],
        "mom Beta FF" = coef(lmres)[3],
        "hml Beta FF" = coef(lmres)[4],
        "smb Beta FF" = coef(lmres)[5],
        "FF R2" = summary(lmres)$adj.r.squared)
      
    }))
    
    rownames(temp)[(nrow(temp)-6):nrow(temp)] = c("Alpha FF", "Alpha FF T-Stat","mkt Beta FF","mom Beta FF","hml Beta FF","smb Beta FF","FF R2")
    
  } 
  
# 
#   temp = rbind(temp, 
#                apply(x[commonmonthsmkt], 2, function(y){
#                  lmres = lm(y ~ mkt[commonmonthsmkt])
#                  c("Alpha mkt" = coef(lmres)[1] * AnnualizationFactor,
#                    "Alpha T-Stat" = summary(lmres)$coef[1,"t value"], "mkt Beta" = coef(lmres)[2])
#                }))
  
  
  
  # Regression against BMK benchmark
  
  temp = rbind(temp,sapply(colnames(x),function(name){
    y = na.omit(x[,name])
    
    commonmonthsbmk = getCommonMonths(if(ncol(xbm) == 1){xbm} else {xbm[,benchmark[name]]}, y)
    
    lmres = lm(y[commonmonthsbmk] ~ if(ncol(xbm) == 1){xbm[commonmonthsbmk]} else {xbm[commonmonthsbmk,benchmark[name]]})
    c("Alpha Bmk" = coef(lmres)[1] * AnnualizationFactor,
      "Alpha T-Stat" = summary(lmres)$coef[1,"t value"], 
      "Bmk Beta" = coef(lmres)[2],
      "Bmk Correlation" = cor(y[commonmonthsbmk],if(ncol(xbm) == 1){xbm[commonmonthsbmk]} else {xbm[commonmonthsbmk,benchmark[name]]}))
    
  }))
  
#   temp = rbind(temp, 
#                apply(x[commonmonthsxbm], 2, function(y){
#                  lmres = lm(y ~ xbm[commonmonthsxbm])
#                  c("Alpha BMK" = coef(lmres)[1] * AnnualizationFactor,
#                    "Alpha T-Stat" = summary(lmres)$coef[1,"t value"], "BMK Beta" = coef(lmres)[2])
#                }))
  
  rownames(temp)[(nrow(temp)-3):nrow(temp)] = c("Alpha BMK", "Alpha BMK T-Stat","BMK Beta","BMK Correlation")
  
  
  pctrows = c("Mean","Stdev","% Positive","Max DD","Worst Period", # , "Worst Rolling 12 Periods", "Worst Calendar Year",
              "Mean vs BMK", "TE vs BMK","Up Capture","Down Capture", "% >= BMK", "Max DD vs BMK",
              "Worst Period vs BMK","Avg Turnover","Current ETF Fee", "ETF Fee 1Y Avg", "Alpha mkt", "Alpha BMK",
              if(doFF){c("Alpha FF","FF R2")})
  for(i in pctrows){
    temp[i,] = toPct(as.numeric(temp[i,]), RoundCoef)
  }
  
  for(i in setdiff(rownames(temp), c(pctrows,"Timing of Worst Per"))){
    temp[i,] = round(as.numeric(temp[i,]), RoundCoef)
  }
  
  start_dates = apply(x,2, function(y){
    findna = as.numeric(is.na(y)) * (1:length(y))
    # set all entries after first 0 to 0
    # this is to avoid an NA at end of data, to become the start point
    findna[min(which(findna == 0)):length(findna)] = 0
    index(x)[max(1, max(findna) + 1)]})
  end_dates = apply(x,2, function(y){index(x)[max(1, max(as.numeric(!is.na(y)) * (1:length(y))))]})
  
  num_periods = t(matrix(apply(x, 2, function(y){sum(!is.na(y))})))
  colnames(num_periods) = colnames(x)
  rownames(num_periods) = paste0("# ",period,"s")
  
  dates = matrix(c("Start" = if(class(index(x)) == "yearmon"){
    as.character(as.yearmon(start_dates))
  } else if(class(index(x)) == "Date"){
    as.character(as.Date(start_dates))
  } else {
    stop("Supports only yearmon and Date class")
  },
  "End" = if(class(index(x)) == "yearmon"){
    as.character(as.yearmon(end_dates))
  } else if(class(index(x)) == "Date"){
    as.character(as.Date(end_dates))
  } else {
    stop("Supports only yearmon and Date class")
  }), nrow = 2, byrow = T)
  
  colnames(dates) = colnames(x)
  rownames(dates) = c("Start","End")
  
  temp = rbind(temp, dates, num_periods)
  temp["Timing of Worst Per",] = as.character(as.yearmon(as.numeric(temp["Timing of Worst Per",])))
  if(missing_benchmark){
    # remove BMK entries from temp
    
    temp = temp[!grepl("BMK|IR",rownames(temp)),]
  }
  
  if(ncol(xbm) == 1){
    # Change BMK in name to benchmark_name
    rownames(temp)[grep("BMK",rownames(temp))] = 
      gsub("BMK", benchmark_name, rownames(temp)[grep("BMK",rownames(temp))])
  }
  
  # Change the period name to period
  rownames(temp)[grepl("Per", rownames(temp))] = 
    gsub("Period|Per", period, rownames(temp)[grepl("Per", rownames(temp))])
  
  # puts in the REbalancing Freq
  temp["Rebalancing Freq",] = paste0(period,"ly")
  
  
  
  if(shortSummary){
    
    if(marketing){
      getRows = c("Mean","Stdev","Sharpe","% Positive","Max DD", # paste0("Worst Rolling 12 ", period,"s"), "Worst Calendar Year",
                   paste("Worst", period),
                  "Mean vs BMK","TE vs BMK", "IR", "Up Capture","Down Capture", 
                  "Avg # Holdings","ETF Fee 1Y Avg", "Rebalancing Freq", 
                  "Alpha BMK", "Alpha BMK T-Stat","BMK Beta",
                  "Start","End",paste0("# ",period,"s"))
      
    } else {
      getRows = c("Mean","Stdev","Sharpe","% Positive","Max DD",paste("Worst", period),
                  "Mean vs BMK","TE vs BMK", "IR", "Up Capture","Down Capture", 
                  "Avg Turnover","Fixed Trading Cost","Avg # Holdings","Rebalancing Freq", 
                  "Alpha BMK", "Alpha BMK T-Stat","BMK Beta",
                  "Start","End",paste0("# ",period,"s"))
    }

    
    # remove the active information for columns that are the benchmark
    for(i in which(colnames(temp) %in% tolower(benchmark_name))){
      if(ncol(xbm) == 1){
        temp[gsub("BMK",benchmark_name,c("Mean vs BMK","TE vs BMK","IR", "Up Capture","Down Capture")),i] = ""
      } else {
        temp[c("Mean vs BMK","TE vs BMK","IR", "Up Capture","Down Capture"),i] = ""
      }
    }
    
    if(ncol(xbm) == 1){
      # Change BMK in name to benchmark_name
      getRows = gsub("BMK", benchmark_name, getRows)
    }
    
    temp = data.frame(temp[getRows,1:ncol(temp)], stringsAsFactors = F)
    colnames(temp) = colnames(x)  
    
  }
  
  
  if(createPlots){
    
    adjPlotNames = make.names(plotNames)
    
    
    
    xact = do.call(merge,lapply(colnames(x),function(name){
      y = na.omit(x[,name])
      
      commonmonthsbmk = getCommonMonths(if(ncol(xbm) == 1){xbm} else {xbm[,benchmark[name]]}, y)
      
      lmres = lm(y[commonmonthsbmk] ~ if(ncol(xbm) == 1){xbm[commonmonthsbmk]} else {xbm[commonmonthsbmk,benchmark[name]]})
      
      y[commonmonthsbmk] - coef(lmres)[2] * if(ncol(xbm) == 1){xbm[commonmonthsbmk]} else {xbm[commonmonthsbmk,benchmark[name]]}
      
    }))

    # remove the first column if it is a benchmark
    non_benchmarks = !(colnames(x) %in% benchmark)
    xact = xact[,non_benchmarks]
    colnames(xact) = adjPlotNames[non_benchmarks]
    
    # colnames(xact) = adjPlotNames[-1]
    
    
#     plot.default(as.matrix(xact[,c(make.names(c("Risk Parity","MA Timing")))]), 
#          xlab = "Risk Parity", ylab = "MA Timing", 
#          main = paste("Scatterplot of Risk Parity and MA Timing Returns in", benchmark_name))
    
    # calculate correlations of active returns
    xactcorr = cor(na.omit(xact))
    # diag(xactcorr) = NA
    
    
    tempcorradd = t(matrix(rep(NA, ncol(x))))
    colnames(tempcorradd) = adjPlotNames
    rownames(tempcorradd) = "Avg Pair Alpha Corr"
    tempcorradd[, colnames(xactcorr)] = round(colMeans(xactcorr, na.rm = T), 2)
    temp = rbind(temp, tempcorradd)
      
    corrplot(xactcorr, method = "number")

    # calculate rolling 1 year active returns
    xact = rollapplyr(xact, 12, mean, fill = NA)
    xact = xact[rowSums(is.na(xact)) < ncol(xact)]
    
    xact = cbind(index(xact), data.frame(xact))
    colnames(xact)[1] = "year_mon"
    xact = gather(xact, mqaid, value, -year_mon)
    xact = data.table(xact)
    xact[, mqaid := gsub("[.]"," ",mqaid)]
    adjPlotNames = gsub("[.]"," ", adjPlotNames)
    
    if(nrow(na.omit(dat[paste(colnames(x),"weights", sep = "_")])) > 0){
      roll_ret_tickers = gsub("_weights","",na.omit(dat[paste(colnames(x),"weights", sep = "_")])[,unique(type)])
    } else {
      roll_ret_tickers = colnames(x)
    }
    
    
    setkey(xact, mqaid, year_mon)
    # plot rolling 1 year active returns
    print(ggplot(xact[adjPlotNames[colnames(x) %in% roll_ret_tickers]], aes(x = as.numeric(year_mon), y = value)) +
      geom_line(aes(color = mqaid)) +
      theme(legend.position="bottom") + 
      labs(x = "", y = "Rolling 1 Year Alpha") +
      ggtitle(paste("Rolling  1 Year Alpha Against",benchmark_name,"\n")) + 
      theme(plot.title = element_text(lineheight=.8, face="bold")) +
      theme(text = element_text(size=20)))
    
    # plot weights
    weightsdat = na.omit(dat[paste(colnames(x),"weights", sep = "_")])
    
    if(nrow(weightsdat) > 0){
      for(i in 1:ncol(x)){
        weightsdat[type == paste0(colnames(x)[i],"_weights"), type := adjPlotNames[i]]
      }
      
      # set weightsdat to same starting point
      weightsdat = weightsdat[year_mon >= weightsdat[, min(year_mon), by = type][,max(V1)]]
      
      print(ggplot(weightsdat, aes(x = as.numeric(year_mon), y = value)) +
              geom_line(aes(color = type)) + facet_wrap( ~ mqaid) +
              theme(legend.position="bottom") + labs(x = "", y = "Weights") +
              ggtitle("Strategies Weights\n") + 
              theme(plot.title = element_text(lineheight=.8, face="bold")) +
              theme(text = element_text(size=20), 
                    axis.text.x = element_text(angle=90, vjust=1)))
      
      
      colnames(temp) = plotNames
    }
    
  }

    
  
  return(temp)
}









# estimateModel 
# estimateModel performs automated model selection using subsetSelection
# subsetSelection does an exhaustive search over all the data, performs linear regression
# and calculates an information criterion on it, and returns the best subset of data.
# Performs linear regression after model selection, and returns an lm object from the lm call.
estimateModel = function(mySubsetdat, varToEstimate, useIcType = "bic"){
  
  if(useIcType == "all") {
       mySubsetres = mySubsetdat
  } else {
       mySubsetres = subsetSelection(mySubsetdat, varToEstimate, ictype = useIcType)
  }
  #   print("Full sample model selection chooses")
  #   print(setdiff(colnames(subsetres), paste(myFactorName,"monthly_return", sep = "_")))
  #   
  
  # calculate model using subset selection results
  mySubsetlmres = lm(as.formula(paste(varToEstimate," ~ .")), data = mySubsetres)
  
  return(mySubsetlmres)
}





# prepareModelData
# prepareModelData 
# input: factor name, and the variable we want to predict
# output: data that can be used directly for estimateModel

# Takes all the lagged variables for the factor, mkt, and the signals we have
# merges them together along with the variable we want to predict
# removes all rows (dates) with any data missing, and returns the data.
# 
# myFactorName = "ada_ffhml_backfilled"
# myModelPredictionVar = "monthly_return"
# factorVariables = c("realized_monthly_volatility_l1m", 
#                     "roll_126_day_volatility_l1m",
#                     "roll_12_month_return_l1m")
# signalVariables =  c("panic_ada","valuespread_ada_backfilled","losercomom_ada_backfilled")

prepareModelData = function(myFactorName, myModelPredictionVar,
                            factorVariables = c("realized_monthly_volatility_l1m", 
                                                "roll_126_day_volatility_l1m",
                                                "roll_12_month_return_l1m"),
                            signalVariables = c("panic_ada","valuespread_ada_backfilled","losercomom_ada_backfilled")){
  
  ####################
  # Factors own data #
  ####################
  

  # get factor data
  model_factor_dat = datToXts(dat[mqaid == myFactorName], "type")
  model_factor_dat = model_factor_dat[,c(myModelPredictionVar, factorVariables)]
  
  # rename variables to include the factor name
  # need to do this, as market variables will otherwise have same name
  colnames(model_factor_dat) = paste(myFactorName, colnames(model_factor_dat), sep = "_")

  
  
  ###############
  # Market data #
  ###############
  
  if(myFactorName != "mkt" & myFactorName != "rm_rf" & !grepl("spy",myFactorName)){
    
    model_mkt_dat = datToXts(dat[mqaid == "ada_rm_rf_backfilled"], "type")
    model_mkt_dat = model_mkt_dat[,factorVariables]

    colnames(model_mkt_dat) = paste("rm_rf",colnames(model_mkt_dat), sep = "_")
  }
  
  
  ###############
  # Signal data #
  ###############
  
  # get signal dat
  model_signal_dat = dat[.("signal_l1m",signalVariables)]
  model_signal_dat = model_signal_dat[!mqaid %in% "panic"]
  model_signal_dat = datToXts(model_signal_dat)
  
  if(myFactorName != "mkt" & myFactorName != "rm_rf" & !grepl("spy",myFactorName)){
    model_dat = merge(model_factor_dat, model_mkt_dat)
  } else {
    model_dat = model_factor_dat
  }

  model_dat = merge(model_dat, model_signal_dat)
  
  # rowSums(is.na())
  
  # Need to remove all rows with NA that are at the beginning of the period
  # at end of period, you will have no return, but all signals
  # if some signal is lagged more, there might be extra row with some na
  # at end
  find_first_non_na_row = (rowSums(is.na(model_dat)) == 0) * (1:nrow(model_dat))
  find_first_non_na_row[find_first_non_na_row == 0] = NA
  model_dat = model_dat[min(find_first_non_na_row, na.rm = T):nrow(model_dat)]
  model_dat = model_dat[rowSums(is.na(model_dat)) < (ncol(model_dat)/2)]
  
  return(model_dat)
}












# uses estimateModel over a rolling window
# #
# myFactorName = "realized1m"
# window_length = 10*12
# myModelPredictionVar = NULL
# myUseIcType = "cp"
# modelSelectionRemoveOutliers = F
# fitMethod = "robust"
# myFactorVariables = c("realized_monthly_volatility_l1m",
#                       "roll_126_day_volatility_l1m", "roll_12_month_return_l1m")
# mySignalVariables =  c("panic_ada","valuespread_ada_backfilled","losercomom_ada_backfilled")
# full_sample_dat = voldata
estimateRollingModel = function(window_length, myFactorName, myModelPredictionVar,
                                myUseIcType = "bic", modelSelectionRemoveOutliers = T, 
                                fitMethod = "robust",
                                myFactorVariables = c("realized_monthly_volatility_l1m", 
                                                    "roll_126_day_volatility_l1m", "roll_12_month_return_l1m"),
                                mySignalVariables =  c("panic_ada","valuespread_ada_backfilled","losercomom_ada_backfilled"),
                                full_sample_dat = NULL){
  
  if(is.null(full_sample_dat)){
       full_sample_dat = prepareModelData(myFactorName, myModelPredictionVar,
                                          factorVariables = myFactorVariables,
                                          signalVariables = mySignalVariables)     
  }
  
  
  # roll over a window of dates
  # using a window_length + 1, as the window_length will be used for model fitting
  # and the + 1 for the next months prediction
  roll_res = rollapplyr(index(full_sample_dat), (window_length + 1), fill = NA, 
    function(dates){
      
      # set the dates to correct date format, so we can refer to the data using it
      if(class(index(full_sample_dat)) == "yearmon"){
        dates = as.yearmon(dates)
      } else if (class(index(full_sample_dat)) == "Date"){
        dates = as.Date(dates)
      } else {
        stop("Support only yearmon and Date classes")
      }
      
      in_sample_dates = dates[1:(length(dates)-1)]
      out_of_sample_dates = dates[length(dates)]
      
      in_sample_data = full_sample_dat[in_sample_dates]
      
      ###################
      # Model selection #
      ###################
      
      myVarToEstimate = if(is.null(myModelPredictionVar)){myFactorName} else {paste(myFactorName,myModelPredictionVar, sep = "_")}
      # use dates 1 to second last for model fitting, will use last entry in dates to predict
      window_res = estimateModel(mySubsetdat = in_sample_data, 
                                 varToEstimate = myVarToEstimate,
                                 useIcType = myUseIcType)
      
      if(modelSelectionRemoveOutliers){

        ###################
        # Remove outliers #
        ###################
        
        # calculate cook's distance
        window_res_cook = xts(cooks.distance(window_res),as.yearmon(names(cooks.distance(window_res))))
        
        # find top x% outliers by cook's distance
        outliers = index(window_res_cook)[which(window_res_cook >= quantile(window_res_cook, CookOutlierPctile))]
        
        # remove top x% outliers by cook's distance
        in_sample_data_without_outliers = in_sample_data[!index(in_sample_data) %in% outliers]
        
        window_res = NULL
        
        # model estimation
        window_res = estimateModel(mySubsetdat = in_sample_data_without_outliers, 
                                                     varToEstimate = myVarToEstimate,
                                                     useIcType = myUseIcType)
  
      }
      # get the model variables the model selected
      model_var_names = setdiff(colnames(in_sample_data),myVarToEstimate)
      
      # set up a variable that has 1 if the model choose a variable, otherwise 0
      modelvar = model_var_names %in% names(coef(window_res))[-1]
      names(modelvar) = model_var_names
      
      
      #############
      # Fit model #
      #############
      
      # Fit model on entire data
      ModelFormula = as.formula(paste(myVarToEstimate," ~ ."))
      
      ModelData = in_sample_data[,c(myVarToEstimate,
                                          names(which(modelvar))      )]
      
      window_res = NULL
      
      if(fitMethod == "lm"){
        window_res = lm(ModelFormula, data = ModelData)
      } else if(fitMethod == "robust"){
        
        # install package MASS if its missing
        # robust linear regression function rlm is from mass
        if(!require(MASS, quietly = T)) {
          install.packages("MASS")
          print("Installed package MASS")
        }
        
        window_res = rlm(ModelFormula, data = ModelData)
      }
      # will use predict(window_res, newdata = full_sample_dat[out_of_sample_dates]
      # to predict, not entirely sure if having additional unused variables will affect the
      # prediction, so check if giving in just the variables the model used changes the prediction
      # want to use the easier syntax, so will remove this once experience shows it doesn't have an effect
      if( abs(predict(window_res, newdata = full_sample_dat[out_of_sample_dates]) -
              predict(window_res, newdata = full_sample_dat[out_of_sample_dates, names(coef(window_res))[-1]])) > 0.00001){
        stop("Error in prediction")
      }
      tempcoef = window_res$coef
      names(tempcoef)[1] = "intercept"
      for (i in names(modelvar)) {if (i %in% names(tempcoef)) {modelvar[i]=tempcoef[i]}}
      modelvar = c(modelvar, tempcoef["intercept"])
      # create return variable, will be the prediction,
      # and a 1 or 0 dummy for each variable if it was included in the model
      tempres = c(predict(window_res, newdata = full_sample_dat[out_of_sample_dates]), # prediction
                  mean(in_sample_data[,myVarToEstimate]), # in sample mean
                  if(is.null(summary(window_res)$adj.r.squared)){-999} else {summary(window_res)$adj.r.squared}, # adjusted r2
                  modelvar)
      names(tempres)[1:3] = c(paste(myVarToEstimate,"prediction", sep = "_"),
                              paste(myVarToEstimate,"mean", sep = "_"),
                              paste(myVarToEstimate,"adjr2", sep = "_"))
      
      return(tempres)
      
    })
  
  roll_res = xts(roll_res, index(full_sample_dat))
  roll_res = roll_res[rowSums(is.na(roll_res)) < ncol(roll_res),]
  
  return(roll_res)
}



# analyzeTimeTrend analyzes whether there is a time trend in the series
# plots it, and rolling average of it, and fits a linear time trend to it and reports results
analyzeTimeTrend = function(x, xtitle, myRollingPredErrorLength){
  plot(x, main = xtitle)
  lines(rollmeanr(x, RollingPredErrorLength), col="red")
  legend("topleft", c(xtitle,paste("Rolling",RollingPredErrorLength,period_type,"Average")), text.col = c("black","red"), bty = "n")
  
  # Fitting Time trend
  print(summarizeRegCoef(summary(lm(x ~ I(1:length(x)))), 5)[1,])
}



# # adds weights of a portfolio to dat
# addWeightsToDat = function(myWt, myName){
#   
#   xtsToDat(myWt, myName)
#   myWt = cbind(index(myWt), data.frame(myWt))
#   colnames(myWt)[1] = "year_mon"
#   myWt = gather(myWt, mqaid, value, -year_mon)
#   myWt = data.table(myWt)
#   myWt[, type := paste(myName,"weights", sep = "_")]
#   setkeyv(myWt, datkeys)
#   rbindDat(myWt)
# }








fredDailyToMonthly = function(name, myskip, isReturns = T,
                              fred_data = c("https://research.stlouisfed.org/fred2/data/")){
  temp = fread(paste0(fred_data,name), skip = myskip, na.strings = ".")
  temp = temp[!is.na(VALUE)]
  temp[, mydate := as.Date(DATE)]
  temp[, year_mon := as.yearmon(mydate)]
  temp[, max_date := max(mydate), by = year_mon]
  temp = temp[mydate == max_date]
  if(isReturns){
    temp = temp[,xts((VALUE)/100, year_mon)]
  } else {
    temp = temp[,xts((VALUE), year_mon)]
  }
  
  return(temp)
}


fredMonthly = function(name, myskip, isReturns = T,
                              fred_data = c("https://research.stlouisfed.org/fred2/data/")){
  temp = fread(paste0(fred_data,name), skip = myskip, na.strings = ".")
  temp = data.frame(temp, stringsAsFactors = F)
  if(isReturns){
    temp = xts(temp[,2]/100, as.yearmon(as.Date(temp[,1])))
  } else {
    temp = xts(temp[,2], as.yearmon(as.Date(temp[,1])))
  }
  
  return(temp)
}


# calcPortRet
# calcPortRet takes in returs, weights, and name
# and calculates portfolio returns, returns Xts or adds to dat
# It also calculates returns on various benchmark portfolios
# and weight iterations, such as
# Equal weight portfolio - could be a natural benchmark
# Equal weight of non zero positions
# Equal risk portfolio - benchmark that has same risks on average over time
# Weights sum to 1 portfolio, turn unlevered portfolios into levered
#                 long only portfolios will have same returns, but unlevered
#                 long short portfolios are turned into levered long short
# Long weights sum to 1 portfolio, to get accurate Fama French factor loadings
#           FF factors have 1 on the long side

# myWt = getIngredientWeights("msci_eafe_ingr_etf_ols_ewret_and_constant")
# myRet = returnsToXts(colnames(myWt))
# myName = "test"
# myReturnXts = T
# rescaleToFullyInvested = T
calcPortRet = function(myRet = myRet, myWt = myWt, myName = myName, myReturnXts = F){
  
  # check that myRet and myWt have the same column names
  if(ncol(myRet) != ncol(myWt)) stop("calcPortRet error: returns and weights don't have the same number of columns")
  
  if(any(colnames(myRet) != colnames(myWt))) stop("calcPortRet error: returns and weights column names are not set up correctly, don't match")
  # Check to ensure all entires in myRet that have non zero weight 
  # have non NA returns
  
  common_months = getCommonMonths(myRet, myWt)
  
  # weights generally have weights 1 month longer than returns have
  # to have portfolio next month.
  # In some cases, where some part of the portfolio doesn't have recent data
  # some of the returns might exist for the last entry in weights, while others don't
  # need to remove the last month of common months, in cases where that happens
  if(common_months[length(common_months)] %in% index(myRet)){
    if(any(is.na(myRet[common_months[length(common_months)]]))){
      common_months = common_months[-length(common_months)]
    }
  }
  
  common_months = common_months[-length(common_months)]
  for(i in colnames(myWt)){
    # check if any return is non NA for common months, where a weight is not 0
    if(any(is.na(myRet[common_months,i][myWt[common_months,i] != 0]))){
      merge(myRet[common_months,i], myWt[common_months,i])
      print(colnames(myWt))
      stop(paste(i,"has NA returns in a month with non zero weight"))
    }
  }
#   
  
  
#   ###################
#   # IMPORTANT ERROR #
#   ###################
#   
#   # Currently, other functions don't handle netting
#   # So if there is a long and short on same ETF, then 
#   # sum of absolute weights will be below 0
#   
#   # if there is no netting, then sum of absolute weights will be 1
#   
#   if(rescaleToFullyInvested){
#     myWt = myWt/rowSums(abs(myWt), na.rm = T)
#     
#     if( abs(rowSums(abs(myWt),na.rm = T) - 1) > DiffTolerance){
#       stop("Error in calcPortRet, rescaled fully invested absolute weights don't sum to 1")
#     }
#   }
  
  
  
  
  
  ###############################
  # Create alternate portfolios #
  ###############################
  
  ##########################
  # equal weight position  #
  ##########################
  
  myWt_ew = myWt
  
  for(i in 1:nrow(myWt_ew)){
    myWt_ew[i,!is.na(myWt_ew[i,])] = 1/sum(!is.na(myWt_ew[i,]))
  }

  if( any( abs(rowSums(abs(myWt_ew), na.rm = T) - 1) > 0.0001 & # abs weights don't sum to 1
           !(abs(rowSums(abs(myWt_ew), na.rm = T)) < 0.0001) ) ){ # and weights don't sum to 0
    stop("calcPortRet error: equal weight absolute weights don't sum to 1")
  }
  
  
#   #####################################
#   # equal weight of nonzero position  #
#   #####################################
#   
#   myWt_ew_non_zero = myWt
#   
#   for(i in 1:nrow(myWt_ew_non_zero)){
#     myWt_ew_non_zero[i,!is.na(myWt_ew_non_zero[i,]) & myWt_ew_non_zero[i,] != 0] = 1/sum(!is.na(myWt_ew_non_zero[i,]) & myWt_ew_non_zero[i,] != 0)
#   }
#   
#   if( any( abs(rowSums(abs(myWt_ew_non_zero), na.rm = T) - 1) > 0.0001 ) ){
#     warning(paste("calcPortRet error: equal weight of non zero absolute weights don't sum to 1 for", myName))
#   }
  #######################
  # equal risk position #
  #######################
  
  myWt_er = myWt
  for(i in 1:ncol(myWt_er)){
    myWt_er[,i] = mean(myWt_er[,i], na.rm = T)
  }
  
  if(!all(myWt_er == 0)){
    myWt_er = myWt_er/rowSums(abs(myWt_er), na.rm = T)
  }
  
  # sometimes all myWt_er are 0, 
  if( any( abs(rowSums(abs(myWt_er), na.rm = T) - 1) > 0.0001 ) & 
      !all(myWt_er == 0)){
    stop("calcPortRet error: equal risk absolute weights don't sum to 1")
  }
  
#   ##############################
#   # Weights sum to 1 portfolio #
#   ##############################
#   
#   myWt_weights_sum_to_1 = myWt
#   myWt_weights_sum_to_1 = myWt_weights_sum_to_1/rowSums(myWt_weights_sum_to_1, na.rm = T)
#   
#   ###################################
#   # Long weights sum to 1 portfolio #
#   ###################################
#   
#   myWt_long_weights_sum_to_1 = myWt
#   myWt_long_weights_sum_to_1 = myWt_long_weights_sum_to_1/
#     apply(myWt_long_weights_sum_to_1,1,function(x){if(length(x[x>0]) == 0){ NA } else { sum(x[x>0]) }})
#   
#   
#   ################################################
#   # Long weights only, weight sum to 1 portfolio #
#   ################################################
#   
#   myWt_long_only_weights_sum_to_1 = myWt
#   myWt_long_only_weights_sum_to_1[myWt_long_only_weights_sum_to_1 < 0] = NA
#   myWt_long_only_weights_sum_to_1 = na.fill(myWt_long_only_weights_sum_to_1,0)
#   
#   myWt_long_only_weights_sum_to_1 = myWt_long_only_weights_sum_to_1/
#     rowSums(myWt_long_only_weights_sum_to_1, na.rm = T)
#   
  ################################
  # Calculate portfolio returns  #
  ################################
  
  common_months = getCommonMonths(myRet,myWt)
  
  # fill missing myReturns with 0
  myRet = na.fill(myRet,0)

  # calculate portfolio return
  portmyRet = myWt[common_months] * myRet[common_months]
  portmyRet = xts(rowSums(portmyRet, na.rm = T), index(portmyRet))
  
  if(myReturnXts){
    return(portmyRet)
  } 
  
  # calculate equal weight portfolio return
  portmyRet_ew = myWt_ew[common_months] * myRet[common_months]
  portmyRet_ew = xts(rowSums(portmyRet_ew, na.rm = T), index(portmyRet_ew))
  
#   # calculate equal weight of non zero positions portfolio return
#   portmyRet_ew_non_zero = myWt_ew_non_zero[common_months] * myRet[common_months]
#   portmyRet_ew_non_zero = xts(rowSums(portmyRet_ew_non_zero, na.rm = T), index(portmyRet_ew_non_zero))
#   
#   
  # calculate equal weight portfolio return
  portmyRet_er = myWt_er[common_months] * myRet[common_months]
  portmyRet_er = xts(rowSums(portmyRet_er, na.rm = T), index(portmyRet_er))
  
#   # calculate weights sum to 1 portfolio returns
#   portmyRet_weights_sum_to_1 = myWt_weights_sum_to_1[common_months] * myRet[common_months]
#   portmyRet_weights_sum_to_1 = xts(rowSums(portmyRet_weights_sum_to_1, na.rm = T), index(portmyRet_weights_sum_to_1))
#   
#   # calculate weights for long weights sum to 1 portfolio returns
#   portmyRet_long_weights_sum_to_1 =  myWt_long_weights_sum_to_1[common_months] * myRet[common_months]
#   portmyRet_long_weights_sum_to_1 = xts(rowSums(portmyRet_long_weights_sum_to_1, na.rm = T), index(portmyRet_long_weights_sum_to_1))
#   
#   # calculate weights for long only, weights sum to 1 portfolio returns
#   
#   portmyRet_long_only_weights_sum_to_1 =  myWt_long_only_weights_sum_to_1[common_months] * myRet[common_months]
#   portmyRet_long_only_weights_sum_to_1 = xts(rowSums(portmyRet_long_only_weights_sum_to_1, na.rm = T), index(portmyRet_long_only_weights_sum_to_1))
#   
#   
  # add weights to dat
  addXtsToDat(na.fill(myWt,0), paste(myName,"weights", sep = "_"))
  addXtsToDat(na.fill(myWt_ew,0), paste(myName,"equal_weight","weights", sep = "_"))
  # addXtsToDat(na.fill(myWt_ew_non_zero,0), paste(myName,"equal_weight_non_zero","weights", sep = "_"))
  addXtsToDat(na.fill(myWt_er,0), paste(myName,"equal_risk","weights", sep = "_"))
#   addXtsToDat(na.fill(myWt_weights_sum_to_1,0), paste(myName,"weights_sum_to_1","weights", sep = "_"))
#   addXtsToDat(na.fill(myWt_long_weights_sum_to_1,0), paste(myName,"long_weights_sum_to_1","weights", sep = "_"))
#   addXtsToDat(na.fill(myWt_long_only_weights_sum_to_1,0), paste(myName,"long_only_weights_sum_to_1","weights", sep = "_"))
#   
  
  # add myReturns to dat
  portmyRet = data.table(mqaid = myName, value = as.numeric(portmyRet),
                         year_mon = index(portmyRet), type = "monthly_return")
  
  if(nrow(dat[.("monthly_return", myName)]) > 1){
    stop(paste(myName,"already has monthly returns in dat"))
  }
  rbindDat(portmyRet)
  
  
  # add equal weight returns
  portmyRet_ew = data.table(mqaid = paste(myName,"equal_weight", sep = "_"), value = as.numeric(portmyRet_ew),
                         year_mon = index(portmyRet_ew), type = "monthly_return")
  
  if(nrow(dat[.("monthly_return", paste(myName,"equal_weight", sep = "_"))]) > 1){
    stop(paste(paste(myName,"equal_weight", sep = "_"),"already has monthly returns in dat"))
  }
  rbindDat(portmyRet_ew)
  
#   
#   # add equal weights of non zero returns
#   portmyRet_ew_non_zero = data.table(mqaid = paste(myName,"equal_weight_non_zero", sep = "_"), value = as.numeric(portmyRet_ew_non_zero),
#                             year_mon = index(portmyRet_ew_non_zero), type = "monthly_return")
#   
#   if(nrow(dat[.("monthly_return", paste(myName,"equal_weight_non_zero", sep = "_"))]) > 1){
#     stop(paste(paste(myName,"equal_weight_non_zero", sep = "_"),"already has monthly returns in dat"))
#   }
#   rbindDat(portmyRet_ew_non_zero)
  
  # add equal risk returns
  portmyRet_er = data.table(mqaid = paste0(myName,"_equal_risk"), value = as.numeric(portmyRet_er),
                            year_mon = index(portmyRet_er), type = "monthly_return")
  
  if(nrow(dat[.("monthly_return", paste0(myName,"_equal_risk"))]) > 1){
    stop(paste(paste0(myName,"_equal_risk"),"already has monthly returns in dat"))
  }
  rbindDat(portmyRet_er)
  
#   # add weights sum to 1
#   portmyRet_weights_sum_to_1 = data.table(mqaid = paste0(myName,"_weights_sum_to_1"), value = as.numeric(portmyRet_weights_sum_to_1),
#                             year_mon = index(portmyRet_weights_sum_to_1), type = "monthly_return")
#   
#   if(nrow(dat[.("monthly_return", paste0(myName,"_weights_sum_to_1"))]) > 1){
#     stop(paste(paste0(myName,"_weights_sum_to_1"),"already has monthly returns in dat"))
#   }
#   rbindDat(portmyRet_weights_sum_to_1)
#   
#   
#   # add long weights sum to 1
#   portmyRet_long_weights_sum_to_1 = data.table(mqaid = paste0(myName,"_long_weights_sum_to_1"), value = as.numeric(portmyRet_long_weights_sum_to_1),
#                                           year_mon = index(portmyRet_long_weights_sum_to_1), type = "monthly_return")
#   
#   if(nrow(dat[.("monthly_return", paste0(myName,"_long_weights_sum_to_1"))]) > 1){
#     stop(paste(paste0(myName,"_long_weights_sum_to_1"),"already has monthly returns in dat"))
#   }
#   rbindDat(portmyRet_long_weights_sum_to_1)
#   
#   # add long only weights sum to 1
#   portmyRet_long_only_weights_sum_to_1 = data.table(mqaid = paste0(myName,"long_only_weights_sum_to_1"), value = as.numeric(portmyRet_long_only_weights_sum_to_1),
#                                                year_mon = index(portmyRet_long_only_weights_sum_to_1), type = "monthly_return")
#   
#   if(nrow(dat[.("monthly_return", paste0(myName,"long_only_weights_sum_to_1"))]) > 1){
#     stop(paste(paste0(myName,"long_only_weights_sum_to_1"),"already has monthly returns in dat"))
#   }
#   rbindDat(portmyRet_long_only_weights_sum_to_1)
#   
  return(portmyRet)
}

createRiskParityWeights = function(myTickers, myRiskLength, myRequireFullData){
  
  myRet = returnsToXts(myTickers)
  
  risk = rollapplyr(myRet, myRiskLength, sd)
  risk = lagXts(risk, 1)
  
  if(myRequireFullData){
    risk = na.omit(risk)
  } else {
    # remove first entries that have no data because burn in for rolling calculation
    risk = risk[rowSums(is.na(risk)) < (ncol(risk)/2)]
  }
  
  
  wt = 1/risk
  wt = wt/rowSums(wt, na.rm = T)
  
  # fill missing weights with 0
  wt = na.fill(wt, 0)
  
  return(wt)
}

# createRiskParity
# Calculates risk parity returns before dat includes rolling vol for everything
# tickers = spy_sector_ingr
# name = "test"
# riskLength = RollSDLength
# requireFullData = T
# returnXts = T
createRiskParity = function(tickers, name, riskLength = RollSDLength, 
                                           requireFullData = T, returnXts = F){
  ret = returnsToXts(tickers)
  
  wt = createRiskParityWeights(tickers, riskLength, requireFullData)
  
  calcPortRet(ret, wt, name, returnXts)
}







# tickers = msci_eafe_ingr
# name = "test"
# riskLength = RollSDLength
# requireFullData = F
# returnXts = F

# Creates weights according to time series momentum.
# Those with positive momentum score get double the weights of those with negative
# momentum score. If all positive or negative then equal weight.
createTimeSeriesMomWeights = function(myTickers, myMALength, myRequireFullData,
                                      excludeMostRecent = 0){
  
  # get returns
  if(is.character(myTickers)){
    myRet = returnsToXts(myTickers)
  } else {
    myRet = myTickers
  }
  
  
  # calculate cumulative myReturns
  myCumRet = xts(apply(na.fill(myRet,0), 2, function(x){cumprod(1+x)}),index(myRet))
  # set missing myReturns to NA in myCumRet
  myCumRet[is.na(myRet)] = NA
  
  # calculate moving average
  myCumRetMa = rollapplyr(myCumRet, myMALength, function(x){
    mean(x[1:(length(x) - excludeMostRecent)])
  })
  
  if(myRequireFullData){
    myCumRetMa = na.omit(myCumRetMa)
  } else {
    # remove first entries that dont' have data for half of symbols
    myCumRetMa = myCumRetMa[rowSums(is.na(myCumRetMa)) < (ncol(myCumRetMa)/2)]
  }
  
  
  # calculate positions
  positions = myCumRet >= myCumRetMa
  colnames(positions) = colnames(myCumRet)
  positions = lagXts(positions, 1 + excludeMostRecent)
  
  # remove rows with all NA
  positions = positions[rowSums(is.na(positions)) < ncol(positions)]
  
  
  # positions of firms above MA are double those below
  # if all are above, then equal weighted, if all below equal weighted
  positions = positions + 1
  wt = positions/rowSums(positions, na.rm = T)
  
  if( any( abs(rowSums(wt, na.rm = T) - 1) > 0.0001 ) ) stop("createTimeSeriesMom error: Weights don't sum to 1")
  
  # fill missing weights with 0
  wt = na.fill(wt, 0)
  
  return(wt)
}


# createTimeSeriesMomWeightsLongShort
# Creates long short time series momentum portfolio.
# Those with positive momentum signal have 1 position
# Those with negative momentum signal have -1 position
# Weights are then scaled by the sum of absolute positions
# Unlevered long short portfolio

createTimeSeriesMomWeightsLongShort = function(myTickers, myMALength, myRequireFullData,
                                               excludeMostRecent = 0){
  
  # get returns
  if(is.character(myTickers)){
    myRet = returnsToXts(myTickers)
  } else {
    myRet = myTickers
  }
  
  
  # calculate cumulative myReturns
  myCumRet = xts(apply(na.fill(myRet,0), 2, function(x){cumprod(1+x)}),index(myRet))
  # set missing myReturns to NA in myCumRet
  myCumRet[is.na(myRet)] = NA
  
  # calculate moving average
  myCumRetMa = rollapplyr(myCumRet, myMALength, function(x){
    # mean(x)
    mean(x[1:(length(x) - excludeMostRecent)])
  })
  
  if(myRequireFullData){
    myCumRetMa = na.omit(myCumRetMa)
  } else {
    # remove first entries that dont' have data for half of symbols
    myCumRetMa = myCumRetMa[rowSums(is.na(myCumRetMa)) < (ncol(myCumRetMa)/2)]
  }
  
  
  # calculate positions
  positions = myCumRet >= myCumRetMa
  colnames(positions) = colnames(myCumRet)
  positions = lagXts(positions, 1 + excludeMostRecent)
  
  # remove rows with all NA
  positions = positions[rowSums(is.na(positions)) < ncol(positions)]
  
  
  # positions of firms above MA are double those below
  # if all are above, then equal weighted, if all below equal weighted
  positions[positions == 0] = -1
  wt = positions/rowSums(abs(positions), na.rm = T)
  
  if( any( abs(rowSums(abs(wt), na.rm = T) - 1) > 0.0001 ) ) stop("createTimeSeriesMomWeightsLongShort error: Absolute Weights don't sum to 1")
  
  # fill missing weights with 0
  wt = na.fill(wt, 0)
  
  return(wt)
}






# createTimeSeriesMomWeightsBinary
# Creates long only time series momentum portfolio that doesn't
# have to be fully invested, hence binary name
# Those with positive momentum signal have 1 position
# Those with negative momentum signal have 0 position
# Weights are then scaled by the number of tickers with valid data
# If all momentum signals are positive, then fully invested
# if only few, then partially invested

createTimeSeriesMomWeightsBinary = function(myTickers, myMALength, 
                                            myRequireFullData, excludeMostRecent = 0){
  
  # get returns
  if(is.character(myTickers)){
    myRet = returnsToXts(myTickers)
  } else {
    myRet = myTickers
  }
  
  
  # calculate cumulative myReturns
  myCumRet = xts(apply(na.fill(myRet,0), 2, function(x){cumprod(1+x)}),index(myRet))
  # set missing myReturns to NA in myCumRet
  myCumRet[is.na(myRet)] = NA
  
  # calculate moving average
  myCumRetMa = rollapplyr(myCumRet, myMALength, function(x){
    mean(x[1:(length(x) - excludeMostRecent)])
  })
  
  if(myRequireFullData){
    myCumRetMa = na.omit(myCumRetMa)
  } else {
    # remove first entries that dont' have data for half of symbols
    myCumRetMa = myCumRetMa[rowSums(is.na(myCumRetMa)) < (ncol(myCumRetMa)/2)]
  }
  
  
  # calculate positions
  positions = myCumRet >= myCumRetMa
  colnames(positions) = colnames(myCumRet)
  positions = lagXts(positions, 1 + excludeMostRecent)
  
  # remove rows with all NA
  positions = positions[rowSums(is.na(positions)) < ncol(positions)]
  
  
  # positions of firms above MA are double those below
  # if all are above, then equal weighted, if all below equal weighted

  wt = positions/rowSums(!is.na(positions), na.rm = T)
  
  # fill missing weights with 0
  wt = na.fill(wt, 0)
  
  return(wt)
}



# tickers = spy_sector_ingr
# name = "test"
# riskLength = MALength
# requireFullData = T
# returnXts = T
# doExcludeMostRecent = 0
createTimeSeriesMom = function(tickers, name, riskLength = MALength, 
                                              requireFullData = T, returnXts = F,
                               doExcludeMostRecent = 0){
  # get returns
  if(is.character(tickers)){
    ret = returnsToXts(tickers)
  } else {
    ret = tickers
  }
  
  wt = createTimeSeriesMomWeights(tickers, riskLength, requireFullData,
                                  excludeMostRecent = doExcludeMostRecent)

  calcPortRet(ret, wt, name, returnXts)
}



createTimeSeriesMomLongShort = function(tickers, name, riskLength = MALength, 
                               requireFullData = T, returnXts = F,
                               doExcludeMostRecent = 0){
  # get returns
  if(is.character(tickers)){
    ret = returnsToXts(tickers)
  } else {
    ret = tickers
  }
  
  wt = createTimeSeriesMomWeightsLongShort(tickers, riskLength, requireFullData,
                                           excludeMostRecent = doExcludeMostRecent)
  
  calcPortRet(ret, wt, name, returnXts)
}

createTimeSeriesMomBinary = function(tickers, name, riskLength = MALength, 
                                        requireFullData = T, returnXts = F,
                                     doExcludeMostRecent = 0){
  # get returns
  if(is.character(tickers)){
    ret = returnsToXts(tickers)
  } else {
    ret = tickers
  }
  
  wt = createTimeSeriesMomWeightsBinary(tickers, riskLength, requireFullData,
                                        excludeMostRecent = doExcludeMostRecent)
  
  calcPortRet(ret, wt, name, returnXts)
}


# createSignalStrengthWeights
# Assumes that signal is an xts, that has a signal value for each ETF.
# Can either input returns, or it will look up returns by the column names of signal
# Creates weights by signal rank order
# Ranks signal, with highest signal having highest rank
# Example, if 10 tickers, then with rank 10 has highest signal, and rank 1 lowest
# Weights are then the ranks, but normalized to sum to 1
# Highest signal mqaid has weight 10 / (sum of 1 to 10), while lowest has 1/10 
# the weight (1 / sum(of 1 to 10))

# useUpperHalfOnly. If T, and long only, uses only signal above 50%tile, otherwise top and bottom 25%
#                   If F, uses all data between lower and upper pctile
# myRequireFullData If T, requires full data
# equalWeight_bool  If T, it does equal weight of the signals in the same direction
#                   If longShort is true, will EW longs and EW shorts
# 
# 
# signal = ey
# myRequireFullData = F 
# useUpperHalfOnly = F
# longShort = T
# lagWeights = T
# returns = NULL
# equalWeight = F
# upperPctile = 0.66
# lowerPctile = 0.33
createSignalStrengthWeights = function(signal, myRequireFullData = F, 
                                       useUpperHalfOnly = F, longShort = F,
                                       lagWeights = T, returns = NULL,
                                       equalWeight = F,
                                       upperPctile = 0,
                                       lowerPctile = 0.5){
  
  if((lowerPctile > upperPctile) & longShort & !useUpperHalfOnly){
    stop("createSignalStrengthWeights error: Can't create rank order signal strength weights when lower pctile is above upper pctile")
  }
  
  # get returns
  if(is.null(returns)){
    returns = returnsToXts(colnames(signal))
  }
  
  # Sets all entries in signal, before the returns has return data, to NA
  signal = setSignalToSameReturnDates(signal,returns)
  
  # calculate the rank of signal
  mySignalRank = xts(t(apply(signal, 1, function(x){rank(x)})), index(signal))
  
  # set missing data to NA
  mySignalRank[is.na(signal)] = NA
  
  # if we are using long only, then if use upper half keep only above median, otherwise
  # the given upperPctile
  # then keep scores above median
  if(!longShort){
    
    if(useUpperHalfOnly){
      # if use upperhalf only, keep only above median
      mySignalRank = xts(t(apply(mySignalRank, 1, function(x){
        x[x < median(x, na.rm = T)] = NA
        return(x)
      })), index(mySignalRank))
    } else {
      # otherwise use the provided pctile
      mySignalRank = xts(t(apply(mySignalRank, 1, function(x){
        x[x < quantile(x, upperPctile,na.rm = T)] = NA
        return(x)
      })), index(mySignalRank))
    }
    
    # Re rank the signal, as we have dropped many rankings
    mySignalRank2 = xts(t(apply(mySignalRank, 1, function(x){rank(x)})), index(mySignalRank))
    
    # set missing data to NA
    mySignalRank2[is.na(mySignalRank)] = NA
    
    mySignalRank = mySignalRank2
    
  } else {
    
    # if we have long short
    # subtract the average from the ranks, that way results will sum to 0
    mySignalRank = mySignalRank - apply(mySignalRank, 1, mean, na.rm = T)
    
    # error check
    if(any(rowSums(mySignalRank,na.rm = T) != 0)) stop("createSignalStrengthWeight errors, long short weights don't sum to 0")
    
    # if useUpperHalfOnly, then we will discard the middle, otherwise use the provided pctiles
    if(useUpperHalfOnly){
      
      mySignalRank = xts(t(apply(mySignalRank, 1, function(x){
        x[x > quantile(x,0.25, na.rm = T) & x < quantile(x, 0.75, na.rm = T)] = NA
        return(x)
      })),index(mySignalRank))
      
      
      # Re rank the signal, as we have dropped many rankings
      mySignalRank2 = xts(t(apply(mySignalRank, 1, function(x){rank(x)})), index(mySignalRank))
      
      # set missing data to NA
      mySignalRank2[is.na(mySignalRank)] = NA
      
      mySignalRank = mySignalRank2
      
      # subtract the average from the ranks, that way results will sum to 0
      mySignalRank = mySignalRank - apply(mySignalRank, 1, mean, na.rm = T)
    } else {
      # else we will use the pctiles given
      
      mySignalRank = xts(t(apply(mySignalRank, 1, function(x){
        x[x > quantile(x,lowerPctile, na.rm = T) & x < quantile(x, upperPctile, na.rm = T)] = NA
        return(x)
      })),index(mySignalRank))
      
      
      # Re rank the signal, as we have dropped many rankings
      mySignalRank2 = xts(t(apply(mySignalRank, 1, function(x){rank(x)})), index(mySignalRank))
      
      # set missing data to NA
      mySignalRank2[is.na(mySignalRank)] = NA
      
      mySignalRank = mySignalRank2
      
      # subtract the average from the ranks, that way results will sum to 0
      mySignalRank = mySignalRank - apply(mySignalRank, 1, mean, na.rm = T)
      
    }
  }
  
  
  
  if(myRequireFullData & !useUpperHalfOnly & (upperPctile == 0 | (upperPctile == 0.5 & lowerPctile == 0.5))){
    # can only do na omit when I am using all the data
    mySignalRank = na.omit(mySignalRank)
  } else {
    
    if(useUpperHalfOnly){
      # remove first entries that dont' have data for 3/4 of symbols
      # as we are only using half of the symbols to trade, other half will be
      # NA by default, and if a half of half, so 3/4 in total is na drop it
      mySignalRank = mySignalRank[rowSums(!is.na(mySignalRank)) >= (1/2 * ncol(mySignalRank)/2)]
    } else {
      
      
      if(longShort){
        # if long short, need at least 1/2 the data that we are using,
        # data between the upper and lower pctiles
        mySignalRank = mySignalRank[rowSums(!is.na(mySignalRank)) >= ((1 - (upperPctile - lowerPctile)) * ncol(mySignalRank)/2)]
      } else {
        # if long only, we need at least half the data that are above the upperPctile
        mySignalRank = mySignalRank[rowSums(!is.na(mySignalRank)) >= ((1 - upperPctile) * ncol(mySignalRank)/2)]
      }
    }
  }
  
  
  
  
  # calculate positions, unlevered long short portfolio
  wt = mySignalRank/rowSums(abs(mySignalRank),na.rm = T)
  
  # lag weights, if we want to
  if(lagWeights){
    wt = lagXts(wt, 1)
  } 
  
  # remove if there are any first rows with NA in all columns
  wt = wt[rowSums(is.na(wt)) < ncol(wt)]
  
  
  if( any( abs(rowSums(abs(wt), na.rm = T) - 1) > 0.0001 ) ) stop("createSignalStrengthWeights error: Absolute weights don't sum to 1")
  
  # fill missing weights with 0
  wt = na.fill(wt, 0)
  
  # if we want to equal weight each part of the signal
  if(equalWeight)
  {
    wt = xts(t(apply(wt,1,function(x){
      
      x = ifelse(x < 0  , -1 / sum(x<0) , x)
      x = ifelse(x > 0  ,  1 / sum(x>0) , x)
    })), index(wt))
    
    wt = wt/rowSums(abs(wt), na.rm = T) 
  }
  
  
  
  
  return(wt)
}



# 
# myTickers = msci_eafe_ingr
# myMomLength = MALength
# myRequireFullData = F
# useSharpe = F
# useUpperHalfOnly = T
# createCrossSectionalMomWeights

createCrossSectionalMomWeights = function(myTickers, myMomLength, myRequireFullData, 
                                          useSharpe = F, useUpperHalfOnly = F,
                                          useEqualWeight = F){
  
  # get returns
  if(is.character(myTickers)){
    myRet = returnsToXts(myTickers)
  } else {
    myRet = myTickers
  }
  
  # calculate rolling 12 - 1 returns
  myRollRet = rollapplyr(myRet, myMomLength, function(x){
    if(useSharpe){
      mean(x[1:(length(x)-1)])/sd(x[1:(length(x)-1)])
    } else {
      mean(x[1:(length(x)-1)])      
    }
    
  })
  
  myRollRet = myRollRet[rowSums(is.na(myRollRet)) < ncol(myRollRet)]
  
  wt = createSignalStrengthWeights(myRollRet, myRequireFullData = myRequireFullData, 
                                   useUpperHalfOnly = useUpperHalfOnly,
                                   returns = myRet, equalWeight = useEqualWeight)

  return(wt)
}

# myTickers = msci_eafe_ingr
# myMomLength = MALength
# myRequireFullData = F
# useSharpe = F
# createCrossSectionalMomWeightsLongShort
# Creates long shortweights using cross sectional momentum measure
# Ranks myMomLength - 1 returns, 
# Subtracts the average rank, with that being the weight, normalized to sum to 1
# Top long and top short will have the same weight
createCrossSectionalMomWeightsLongShort = function(myTickers, myMomLength, myRequireFullData, 
                                                   useSharpe = F, useEqualWeight = F,
                                                   useUpperHalfOnly = F, upperPctile_t = 0.5, lowerPctile_t = 0.50){
  
  
  # get returns
  if(is.character(myTickers)){
    myRet = returnsToXts(myTickers)
  } else {
    myRet = myTickers
  }
  
  # calculate rolling 12 - 1 returns
  myRollRet = rollapplyr(myRet, myMomLength, function(x){
    if(useSharpe){
      mean(x[1:(length(x)-1)])/sd(x[1:(length(x)-1)])
    } else {
      mean(x[1:(length(x)-1)])      
    }
    
  })
  
  myRollRet = myRollRet[rowSums(is.na(myRollRet)) < ncol(myRollRet)]
  
  wt = createSignalStrengthWeights(myRollRet, myRequireFullData = myRequireFullData, 
                                   useUpperHalfOnly = useUpperHalfOnly, longShort = T,
                                   returns = myRet, equalWeight = useEqualWeight,
                                   upperPctile = upperPctile_t, lowerPctile = lowerPctile_t)
  
}

# tickers = spy_port
# name = "test"
# momLength = MALength
# requireFullData = T
# returnXts = F
# myUseSharpe = F
createCrossSectionalMomPort = function(tickers, name, momLength = MALength, 
                                       requireFullData = T, returnXts = F, myUseSharpe = F,
                                       myUseUpperHalfOnly = F){
  
  # get returns
  if(is.character(tickers)){
    ret = returnsToXts(tickers)
  } else {
    ret = tickers
  }
  
  wt = createCrossSectionalMomWeights(tickers, momLength, requireFullData, 
                                      useSharpe = myUseSharpe, useUpperHalfOnly = myUseUpperHalfOnly)
  
  calcPortRet(ret, wt, name, returnXts)
}


createCrossSectionalMomPortLongShort = function(tickers, name, momLength = MALength, 
                                       requireFullData = T, returnXts = F, myUseSharpe = F){
  
  # get returns
  if(is.character(tickers)){
    ret = returnsToXts(tickers)
  } else {
    ret = tickers
  }
  
  wt = createCrossSectionalMomWeightsLongShort(tickers, momLength, requireFullData, useSharpe = myUseSharpe)
  
  calcPortRet(ret, wt, name, returnXts)
}

createEqualWeightPort = function(tickers, name, requireFullData = T, returnXts = F){
  
  # get returns
  ret = returnsToXts(tickers)
  
  wt = ret
  wt[,] = 1
  wt[is.na(ret)] = 0
  wt = wt/rowSums(wt)
  
  calcPortRet(ret, wt, name, returnXts)
}


# code I used before I added to adjustWeightsToFullyInvest
# createFixedWeightPort = function(weight, name, requireFullData = T, returnXts = F, fullyInvested = T){
#   
#   if(fullyInvested){
#     if( abs(sum(weight) - 1) > 0.0001 ) stop("createFixedWeightPort weights don't sum to 1")
#   }
#   # get returns
#   ret = returnsToXts(names(weight))
#   
#   wt = ret
#   
#   for(i in names(weight)){
#     wt[,i] = weight[i]
#   }
#   
#   
#   if(requireFullData){
#     wt[is.na(ret)] = NA
#     wt = na.omit(wt)
#   } else {
#     wt[is.na(ret)] = 0
#     
#   }
#   
#   
#   if(fullyInvested){
#     # if fullyInvested then scale weights to sum to 1
#     wt = wt/rowSums(wt)
#   } else if(any(wt < 0)){
#     # Create unlevered long short portfolio if there is a short
#     wt = wt/rowSums(abs(wt))
#   }
#   
#   
#   calcPortRet(ret, wt, name, returnXts)
# }


# createRPModifiedFixedWeightPort
# Starts with a fixed weight portfolio, and adjusts weights from there
# dynamically according to risk parity

# weight = acwi_port
# name = "test"
# requireFullData = T
# returnXts = F
# fullyInvested = T
# riskLength = 12
# maxDeviation = 0.1 # maximum weight we can deviate from the fixed weights

# createRPModifiedFixedWeightPort(weight, "test", 12, 0.05, T, T, T)
createRPModifiedFixedWeightPort = function(weight, name, riskLength, maxDeviation, requireFullData = T, returnXts = F, fullyInvested = T){
  
  if(fullyInvested){
    if( abs(sum(weight) - 1) > 0.0001 ) stop("createRPModifiedFixedWeightPort weights don't sum to 1")
  }
  # get returns
  ret = returnsToXts(names(weight))
  
  # calculate fixed weights
  wt = ret
  
  for(i in names(weight)){
    wt[,i] = weight[i]
  }
  
  # calculate risk parity weights
  wtrp = createRiskParityWeights(names(weight), riskLength, requireFullData)
  # wtrp = lagXts(wtrp, 1)
  wtrpmean = rollapplyr(wtrp, riskLength, mean)
  wtrpmean = wtrpmean[rowSums(is.na(wtrpmean)) < ncol(wtrpmean)/2]
  
  # risk parity active weights defined as their weights minus 1 year average
  wtrpactive = (wtrp - wtrpmean)
  
  #  can deviate from fixed weights only up to maxDeviation
  # replace any excess deviation with maxDeviation
  for(i in colnames(wtrpactive)){
    wtrpactive[abs(wtrpactive[,i]) > maxDeviation,i] = maxDeviation * sign(wtrpactive[abs(wtrpactive[,i]) > maxDeviation,i])
  }
  
  if(any(abs(rowSums(wtrpactive)) > 0.0001)) stop("createRPModifiedFixedWeightPort has issues. Risk parity active weights don't sum to 0")
  
  # update my weights, wt, by adding the active risk parity weights
  
  wt = wt[index(wtrpactive)]
  
  wt = wt + wtrpactive
  
  ret = ret[index(wt)]
  if(requireFullData){
    wt[is.na(ret)] = NA
    wt = na.omit(wt)
  } else {
    wt[is.na(ret)] = 0
    
  }
  
  # if fullyInvested then scale weights to sum to 1
  if(fullyInvested){
    wt = wt/rowSums(wt)
  }
  
  
  calcPortRet(ret, wt, name, returnXts)
}






# myTickers = c("mkt","rf")
# myWeights = c(0.6, 0.4)
# myRetName = "monthly_return"
# myWeightAdj = 0.1
# myTickerAdj = "mkt"
# myTrendVar = "spx_trend"
calcTrendWeights = function(myTickers, myWeights, myRetName, myWeightAdj = 0.1, myTickerAdj, 
                            myTrendVar){
  
  # calculate the fixed weights
  wt = calcFixedWeights(myTickers, myWeights, myRetName)
  
  # get SPX trend information
  spxtrend = dat[myTrendVar]
  spxtrend = datToXts(spxtrend)
  
  
  # set data to same months
  commonmonths = getCommonMonths(spxtrend,wt)
  
  wt = wt[commonmonths]
  spxtrend = spxtrend[commonmonths]
  
  
  # increase weight of myTickerAdj when spx is in an uptrend
  wt[, myTickerAdj] = wt[, myTickerAdj] + spxtrend * myWeightAdj
  # reduce weights of all others when spx is in an uptrend pro rata
  frac_other_wt = wt[, setdiff(colnames(wt),myTickerAdj)] / rowSums(wt[, setdiff(colnames(wt),myTickerAdj)])
  
  # setup the spx trend data to allow multiplication
  spxtrend_other = xts(apply(frac_other_wt, 2, function(x){x = as.numeric(spxtrend); return(x)}), index(frac_other_wt))
  
  wt[, setdiff(colnames(wt),myTickerAdj)] =  wt[, setdiff(colnames(wt),myTickerAdj)] -
    frac_other_wt * spxtrend_other * myWeightAdj
  
  return(wt)
}




# myTickers = returnsToXts(c("xlf","xly","xlk"))
# removeRet = returnsToXts("spy")
# myRollRegLength = 36
# minNumberTickers = if(is.character(myTickers)){
#   length(myTickers)/2} else {
#     ncol(myTickers)/2}

getTrueBetaUnconstrainedWeights = function(myTickers, removeRet = paste(tickerToMqaid("spy"),"backfilled", sep = "_"), 
                                           riskFreeIndex = paste(tickerToMqaid("shy"),"backfilled", sep = "_"),
                                           myRollRegLength = RollRegTBLength,
                                    minNumberTickers = if(is.character(myTickers)){
                                                            length(myTickers)/2} else {
                                                              ncol(myTickers)/2}){
    
    if(is.character(myTickers)){
      tbret = returnsToXts(myTickers)
    } else {
      tbret = myTickers
    }
    
    # rfret = returnsToXts(riskFreeIndex)

    if(is.character(removeRet)){
      removeRet = returnsToXts(removeRet)
    }
    
    
    # calculate time series beta to removeRet
    removeBeta = rollapplyr(index(tbret), myRollRegLength, fill = NA, function(x){

      
      if(class(index(tbret)) == "yearmon"){
        x = as.yearmon(x)
      } else if (class(index(tbret)) == "Date"){
        x = as.Date(x)
      } else {
        stop("Support only yearmon and Date date classes")
      }
      # print(x[1])
    
      regyret = tbret[x]
      # regyrf = returnsToXts(riskFreeIndex)
      # regyrf = regyrf[index(regyret)]
      regxret = removeRet[x]
      
      # Calculate beta to regxret, but only if there 
      # is no NA in the return data
      # and we have data for removeRet
      # and we have data for risk free
      reg1res = sapply(colnames(tbret),function(name){
        if(any(is.na(regyret[,name])) | 
           length(setdiff(index(regyret), index(regxret))) > 0 ){ #|
           # length(setdiff(index(regyret), index(regyrf))) > 0){
          return(NA)
        } else {
          regy = regyret[,name] # - regyrf
          return(coef(lm(regy ~ regxret))[2])
        }
      })
      names(reg1res) = colnames(tbret)
      
      return(reg1res)
    })
    
    removeBeta = xts(removeBeta, index(tbret))
    
    # lag betas to do cross sectional regression
    removeBeta = lagXts(removeBeta, 1)
    
    
    tb_unconstrained_weights = sapply(index(removeBeta), function(x){
      if(class(index(removeBeta)) == "yearmon"){
        x = as.yearmon(x)
      } else if (class(index(removeBeta)) == "Date"){
        x = as.Date(x)
      } else {
        stop("Support only yearmon and Date date classes")
      }
    
      usableBeta = removeBeta[x,!is.na(removeBeta[x,])]
      
      # setup results variable
      res = rep(NA, ncol(tbret))
      names(res) = colnames(tbret)
      
      # if we have less than minNumberTickers betas, return NA
      if(length(usableBeta) < minNumberTickers){
        return(res)
      }

      # create our regression x variable
      xvar = cbind(rep(1,length(usableBeta)),t(as.matrix(usableBeta)))
      
      # calculate unconstrained weights = (X'X)^-1 * X'
      weights_unc = solve(t(xvar) %*% xvar) %*% t(xvar)
      
      # save results
      res[colnames(weights_unc)] = weights_unc[1,]
      
      return(res)
    })
    
    tb_unconstrained_weights = xts(t(tb_unconstrained_weights), index(removeBeta))
    
    tb_unconstrained_weights = tb_unconstrained_weights[rowSums(is.na(tb_unconstrained_weights)) < ncol(tb_unconstrained_weights),]
    return(tb_unconstrained_weights)
}


# 
# baseWeights = myWeights
# liquidityLimits = myLiquidity
# investedAUM = 100 
# tradePctOfAvgdolvol = 0.2
# sumOfWeights = 1
# sumOfLongWeights = 1.3
# baseWeightsUnconstrained = wt_unconstrained
# dateperiod = mydate
# useSQP = F
# allowSignFlip = T # if T, signs of weights can be different between constrained and unconstrained

# liquidityConstraintOptimization
# Does optimization to minimize squared distance from some weight
# while also honoring liquidity constraints, and 
# setting constraints on sum of weights, and sum of long weights
liquidityConstraintOptimization = function(baseWeights, liquidityLimits, investedAUM, 
                           tradePctOfAvgdolvol,
                           sumOfWeights,
                           sumOfLongWeights,
                           baseWeightsUnconstrained,
                           dateperiod,
                           useSQP = F,
                           allowSignFlip = T){

  
  # Objective function
  # minimize the squared deviation from the unconstrained weights
  obj_wt = function(x, mywt = baseWeights){
    t(x - mywt) %*% (x - mywt)
  }
  
  
  #     
  # inequality constraints
  # Absolute value of weights * investedAUM, has to be less than 
  # liquidity * % of liquidity traded for all instruments
  # return sum of the ones that are above
  # Inequality constraint has to be <= 0
  obj_ineq_cons = function(x, myliq = liquidityLimits){
#     tempval = abs(x) * investedAUM - myliq * tradePctOfAvgdolvol
#     tempval = sum(tempval[tempval>0])
    
    # calculate the ratio of what we trade and what we can trade, and subtract 1
    # positive numbers are fractions above what we can trade
    tempval = (sqrt(x^2) * investedAUM) /  (myliq * tradePctOfAvgdolvol) - 1
    tempval = tempval[tempval>0]
    
    if(length(tempval) == 0){
      return(0)
    } else {
      return(sum(tempval^2))
    }
    # add a 1000000 to the tempval to make the 
    # inequality function have larger impact than the equality one
    # care more about not trading more than we can, 
    # than we do if long weights sum to 1.3 or 1.295
    # return(tempval * 1000000)
  }
  
#   # Sum of absolute weights <= 1
#   sum_abs_wt_const = function(x){
#     return(max(sum(abs(x))-1,0)^2)
#   }
  
  # long only constraint
  # sum of negative weights squared
  long_only_const = function(x){
    if(length(x[x<0]) > 0){
      (sum(x[x<0])^2)
    } else {
      return(0)
    }
  }
  
  # fully invested constraint
  fully_inv_const = function(x){
    (sum(x) - 1)^2
  }
  
  
  
  
  
  # Equality constraints
  # Weights sum to sumOfWeights
  # Long weights sum to sumOfLongWeights
  # Constraint have to be a - b = 0
  obj_eq_cons = function(x){
    
    # return( 
#       rbind(
#         t(x) %*% rep(1, length(x)) - sumOfWeights, # weights sum to sumOfWeights
#         x[x > 0] %*% rep(1, length(x[x > 0])) - sumOfLongWeights # long weights sum to sumOfLongWeights
#         # don't need a constraint on short weights, as above 2 ensure it
#        )
       # having the constraints separately didn't achieve binding results
    # )
                  # weights sum to sumOfWeights               long weights sum to sumOfLongWeights
      consres = c(t(x) %*% rep(1, length(x)) - sumOfWeights, x[x > 0] %*% rep(1, length(x[x > 0])) - sumOfLongWeights)
      return(sum(consres^2))
      
    # )
  }
  
  
  direction_penalty = function(x, wt_unconstrained = baseWeights){
    # multiply the two weights, if the sign is negative we know we are flipping the position
    positionflip = x * wt_unconstrained
    positionflip = positionflip[positionflip < 0]
    
    if(length(positionflip) == 0){
      return(0)
    } else {
      return(sum(abs(positionflip)))
    }
  }
  
  # Optimize function using nloptr package
  # https://cran.r-project.org/web/packages/nloptr/index.html
  # http://ab-initio.mit.edu/wiki/index.php/NLopt_Algorithms
  
#   check.derivatives(baseWeights, obj_wt, function(y){
#     gradient(function(x){obj_wt(x, baseWeights)}, # gradient of objective function
#              y)
#   })
  
  
  if(useSQP){
    
    
    
    if(!require(rootSolve, quietly = T)) {
      install.packages("rootSolve")
      print("Installed package rootSolve")
    }
    
    
    
    # Calculate gradients using the rootSolve package
    # https://cran.r-project.org/web/packages/rootSolve/index.html
    res = nloptr(x0 = baseWeights, 
                 eval_f = function(x){obj_wt(x, baseWeights)}, # objective function
                 eval_grad_f = function(y){
                   gradient(function(x){obj_wt(x, baseWeights)}, # gradient of objective function
                            y)
                 },
                 lb = rep(-Inf, length(baseWeights)), # parameter lower bounds
                 ub = rep(Inf, length(baseWeights)), # parameter upper bounds
                 eval_g_ineq = function(x){obj_ineq_cons(x, liquidityLimits)}, # inequality constraints
                 eval_jac_g_ineq = function(y){
                   gradient( function(x){obj_ineq_cons(x, liquidityLimits)},
                             y)
                 }, # gradient of inequality constraints
                 eval_g_eq = function(x){obj_eq_cons(x)}, # equality constraints
                 eval_jac_g_eq = function(y){
                   gradient( function(x){obj_eq_cons(x)},
                             y)
                 }, # gradient of inequality constraints
                 opts = list("algorithm" = "NLOPT_LD_SLSQP", # algorithm choosen
                             "stopval" = -Inf,
                             "xtol_rel" = 1e-15,
                             "xtol_abs" = rep(0, length(baseWeights)),
                             "maxeval" = 100000,
                             "ftol_rel" = 0,
                             "ftol_abs" = 0,
                             # "check_derivatives" = T,
                             "tol_constraints_eq" = 1e-15,
                             "tol_constraints_ineq" = 1e-15
                             # "maxtime" = -1
                 ))
    
    baseWeightsConstrained = res$solution
    
  } else {
    
    if(!require(RcppDE, quietly = T)) {
      install.packages("RcppDE")
      print("Installed package RcppDE")
    }
    
    deoptobj = function(x){
      
#       if(obj_ineq_cons(x) > 0) return(obj_ineq_cons(x))
#       
#       if(abs(obj_eq_cons(x)) > 0.001) return(-Inf)
#       
#       return(obj_wt(x))
      
      obj_wt(x) + obj_ineq_cons(x) * 10000 + 
                  obj_eq_cons(x) * 10000 + 
                  # long_only_const(x) * 10000 + 
                  # fully_inv_const(x) * 10000 + 
                  # sum_abs_wt_const(x) * 100 + 
                  direction_penalty(x) * as.numeric(!allowSignFlip) * 10000
    }
    
    set.seed(1234)
    
    beginning_population = t(sapply(1:(length(baseWeights) * 10),function(x){
      temp = baseWeights + runif(length(baseWeights),-0.25, 0.25)
      temp = temp/sum(temp)
    }))
    
    res = DEoptim(deoptobj, lower = rep(sumOfWeights - sumOfLongWeights, length(baseWeights)), 
                  upper = rep(1, length(baseWeights)),
                  control = DEoptim.control(VTR = 0,
                                            itermax = 5000,
                                            trace = F,
                                            NP = length(baseWeights) * 10,
                                            initialpop = beginning_population))
    
    
    baseWeightsConstrained = res$optim$bestmem
    names(baseWeightsConstrained) = names(baseWeights)
  }
  
  
  
  ####################################################
  # Error checks to ensure constraints are respected #
  ####################################################
  
#   # inequality
#   if(obj_ineq_cons(baseWeightsConstrained) > 0.0005){
#     print(warning(paste("Equality constraints in",dateperiod,"are violated.")))
#   }
  
  # equality
  if(any(abs(obj_eq_cons(baseWeightsConstrained)) > 0.01)){
    print(warning(paste("Equality constraints in",dateperiod,"are violated. Long weights sum to",
                        sum(baseWeightsConstrained[baseWeightsConstrained>0]),"but should sum to", sumOfLongWeights, "while weights sum to",
                        sum(baseWeightsConstrained),"while they should sum to", sumOfWeights)))
  }
  
#   if(any(baseWeightsConstrained < -0.00001)){
#     print(warning(paste(dateperiod," has shorts",names(baseWeightsConstrained)[baseWeightsConstrained < -0.00001])))
#   }
#   
#   if(abs(sum(baseWeightsConstrained) - 1) > 0.00001){
#     print(warning(paste(dateperiod,"weights sum to",round(sum(baseWeightsConstrained),3),"not to 1")))
#   }
#   
  
  # print(paste(dateperiod,"Sum of absolute weights are", round(sum(abs(baseWeightsConstrained)),2)))
  
  
  # liquidity again
  templiq = cbind(abs(baseWeightsConstrained) * investedAUM , liquidityLimits * tradePctOfAvgdolvol)
  
  if(any(templiq[,1] > (templiq[,2] * (1 + 0.001)))){
    
    templiqerror = templiq[,1]/templiq[,2]
    templiqerror = templiqerror[templiqerror> (1 + 0.001)]
    templiqerrornames = names(templiqerror)
    templiqerror = paste0(round(templiqerror * 100 - 100,5),"%")
    names(templiqerror) = templiqerrornames
    print(paste("We are trading the following % above what we can in ", dateperiod))
    print(templiqerror)
    print(warning(paste("Liquidity constraints violated in",dateperiod)))
  }
  
  if(!allowSignFlip){
    # look for sign flip
    # sign flip if the multiplication of the signs is negative
    if(any((sign(baseWeightsConstrained) * sign(baseWeights)) < 0)){
      print(warning(paste("We are flipping signs of weights in",dateperiod)))
    }
  }

  
  ###################
  # Return solution #
  ###################
  
  
  return_res = baseWeightsUnconstrained[dateperiod]
  return_res[] = NA
  return_res[,names(baseWeights)] = t(baseWeightsConstrained)
  return(return_res)
}


# wt_unconstrained = getTrueBetaUnconstrainedWeights(etfs["msci em country stocks", mqaid], "spy_index")
# wt_avgdolvol = NULL
# AUM = 100
# pctTradedOfAvgdolvol = 0.2
# weightSum = 1
# longWeightSum = 1.3
# doUseSQP = F

# Gets weights that are closest to unconstrained true betaw weights in least
# square sense, while honoring liquidity limits, sum of weights, and sum of long weights
# limits
getTrueBetaConstrainedWeights = function(wt_unconstrained, wt_avgdolvol = NULL, 
                                         AUM = 100, pctTradedOfAvgdolvol = 0.2,
                                         weightSum = 1,
                                         longWeightSum = 1.3, doUseSQP = F,
                                         doAllowSignFlip = T){


  set.seed(1234)
  
  if(!require(foreign, quietly = T)) {
    install.packages("nloptr")
    print("Installed package nloptr")
  }
  
  if(!require(foreign, quietly = T)) {
    install.packages("rootSolve")
    print("Installed package rootSolve")
  }
  
  if(is.null(wt_avgdolvol)){
    wt_avgdolvol = datToXts(dat[.("avgdolvol",colnames(wt_unconstrained))])
    # avgdolvol is a months average dollar volume
    # need to transform it to daily average dollar volume
    wt_avgdolvol = wt_avgdolvol/20
  }
  
  wt_liq_commonmonths = getCommonMonths(wt_unconstrained, wt_avgdolvol)
  wt_unconstrained = wt_unconstrained[wt_liq_commonmonths]
  wt_avgdolvol = wt_avgdolvol[wt_liq_commonmonths]
  
  tb_constrained_weights = sapply(index(wt_unconstrained), function(mydate){
    
    print(mydate)
    
    if(class(index(wt_unconstrained)) == "yearmon"){
      mydate = as.yearmon(mydate)
    } else if (class(index(wt_unconstrained)) == "Date"){
      mydate = as.Date(mydate)
    } else {
      stop("Support only yearmon and Date date classes")
    }
    
    myWeights = wt_unconstrained[mydate][,!is.na(wt_unconstrained[mydate])]
    myWeights = as.numeric(myWeights)
    names(myWeights) = colnames(wt_unconstrained[mydate][,!is.na(wt_unconstrained[mydate])])
    
    myLiquidity = wt_avgdolvol[mydate]
    myLiquidity = as.numeric(myLiquidity[,names(myWeights)])
    names(myLiquidity) = names(myWeights)
    
    return(liquidityConstraintOptimization(baseWeights = myWeights,
                           liquidityLimits = myLiquidity,
                           investedAUM = AUM,
                           tradePctOfAvgdolvol = pctTradedOfAvgdolvol,
                           sumOfWeights = weightSum,
                           sumOfLongWeights = longWeightSum,
                           baseWeightsUnconstrained = wt_unconstrained,
                           dateperiod = mydate,
                           useSQP = doUseSQP,
                           allowSignFlip = doAllowSignFlip))
    
    
  })

  
  tb_constrained_weights = xts(t(tb_constrained_weights), index(wt_unconstrained))
  
  #####################
  # final error check #
  #####################
  
  # weights sum to weightSum
  if( any(abs(apply(tb_constrained_weights, 1, function(x){sum(x,na.rm = T)}) - weightSum) > 0.0001) ){
    warning(paste("True beta constrained weights don't sum to", weightSum, "all months"))
  }
  
  # long weights sum to longWeightSum
  if( any(abs(apply(tb_constrained_weights, 1, function(x){sum(x[x>0],na.rm = T)}) - longWeightSum) > 0.0001) ){
    warning(paste("True beta constrained weights don't sum to", longWeightSum, "all months"))
  }
  
  # liquidity
  trade_more_than_we_can = sapply(colnames(tb_constrained_weights),function(name){
    # Check the ratio of what we do trade to what we can trade
    # If any ratio is bigger than 101%, then we are trading more than we can
    return(max((abs(tb_constrained_weights[,name]) * AUM) / 
                 (wt_avgdolvol[index(tb_constrained_weights), name] * pctTradedOfAvgdolvol), na.rm = T))
    
  })
  
  
  if(any(trade_more_than_we_can > (1 + DiffTolerance))){
    print(warning(c(paste("We are trading more than we can for "),
                    paste(names(which(trade_more_than_we_can > (1 + DiffTolerance))), collapse = " "),
                    trade_more_than_we_can[which(trade_more_than_we_can > (1 + DiffTolerance))])))
  }
  
  return(tb_constrained_weights)
}




# 
# wt = wtc
# wt_avgdolvol = NULL
# AUM = 100
# pctTradedOfAvgdolvol = 0.2
# weightSum = 1
# longWeightSum = 1.3

# compareTrueBetaConstraints
# compares how much the constrained true beta results violate the constraints
compareTrueBetaConstraints = function(wt, wt_avgdolvol = NULL, AUM,pctTradedOfAvgdolvol = 0.2,
                                      weightSum = 1,
                                      longWeightSum = 1.3){
  
  
  if(is.null(wt_avgdolvol)){
    wt_avgdolvol = datToXts(dat[.("avgdolvol",colnames(wt))])
    # avgdolvol is a months average dollar volume
    # need to transform it to daily average dollar volume
    wt_avgdolvol = wt_avgdolvol/20
  }
  
  if(length(c(setdiff(colnames(wt),colnames(wt_avgdolvol)), 
    setdiff(colnames(wt_avgdolvol),colnames(wt)))) != 0){
    stop("Weight and liquidity variables don't have the same column names")
  }
  
  # set the order of wt_avgdolvol columns to the order of weight columns
  wt_avgdolvol = wt_avgdolvol[,colnames(wt)]
  
  ##############################
  # Check equality constraints #
  ##############################
  
  res = list()
  
  ##################
  # sum of weights #
  ##################
  
  res[["sum_of_weights"]] = xts(rowSums(wt, na.rm = T), index(wt))
  
  plot(res[["sum_of_weights"]], main = paste("Sum of Weights. Should be", weightSum))
  abline(h = weightSum, col = "red")
  
  #######################
  # sum of long weights #
  #######################
  
  res[["sum_of_long_weights"]] = xts(apply(wt, 1, function(x){sum(x[x>0], na.rm = T)}), index(wt))
  
  plot(res[["sum_of_long_weights"]], main = paste("Sum of Long Weights. Should be", longWeightSum))
  abline(h = longWeightSum, col = "red")
  
  
  #########################
  # liquidity constraints #
  #########################
  
  liqres = sapply(index(wt),function(mydate){
    
    if(class(index(wt)) == "yearmon"){
      mydate = as.yearmon(mydate)
    } else if (class(index(wt)) == "Date"){
      mydate = as.Date(mydate)
    } else {
      stop("Support only yearmon and Date date classes")
    }

#     # ratio of what we trade / trade_pct_of_liquidity
#     trade_pct_of_liquidity = (AUM * wt[mydate]) / (wt_avgdolvol[mydate] * pctTradedOfAvgdolvol) - 1
#     trade_pct_of_liquidity = trade_pct_of_liquidity[,trade_pct_of_liquidity > 0]
#     
    
    excess_trading = (AUM * wt[mydate]) - (wt_avgdolvol[mydate] * pctTradedOfAvgdolvol)
    excess_trading = excess_trading[,na.fill(excess_trading > 0, F)]
    
#     return(c("Average Liquidity Above Limit" = mean(trade_pct_of_liquidity),
#              "Number Above Limit" = length(trade_pct_of_liquidity),
#              "Excess Trading % of AUM" = sum(excess_trading)/AUM))
    
    return(c("Excess Trading as % of AUM" = sum(excess_trading)/AUM))
  })
  
  liqres = xts((liqres), index(wt))
  
  max_aum = xts(rowSums(wt_avgdolvol * pctTradedOfAvgdolvol, na.rm = T),index(wt_avgdolvol))
  plot(max_aum, main = "Maximum AUM Assuming We Trade All We Can")
#   plot(liqres[,"Average Liquidity Above Limit"], main = "Number of Symbols Where We Trade More Than We Can")
#   plot(liqres[,"Number Above Limit"], main = "Number of Symbols Where We Trade More Than We Can")
  plot(liqres, main = "Excess Trading as % of AUM")

  res[["excess_trading_as_pct_of_aum"]] = liqres
  res[["max_aum"]] = max_aum
  return(res)
}

# 
# tickers = etfs["MSCI EM Country Stocks", mqaid]
# name = "test"
# myremoveRet = "spy_index"
# myRollRegLength = MALength
# myMinNumberTickers = length(tickers)/2
# requireFullData = T
# returnXts = T
# deleverReturns = T

# tickers = etfs["msci eafe country stocks", mqaid]
# tickers = spx_sector_ingr
# wt_unconstrained = getTrueBetaUnconstrainedWeights(tolower(tickers))
# ptm = proc.time()
# wtc =  getTrueBetaConstrainedWeights(wt_unconstrained, doUseSQP = F)
# print(paste("It took"))
# print(proc.time()-ptm)
# compareTrueBetaConstraints(wtc,NULL, 100, 0.2, 1, 1.3)

# createUnconstrainedTrueBeta
# Creates unconstrained true beta portfolio returns for tickers after removing
# myRemoveTicker from the returns
createUnconstrainedTrueBeta  = function(tickers, name, myRemoveTicker = "spy_index",
                                        useRollRegLength = RollRegLength,
                                        myMinNumberTickers = length(tickers)/2,
                                        deleverReturns = T,
                               requireFullData = T, returnXts = F){
  # get returns
  ret = returnsToXts(tickers)
  
  wt = getTrueBetaUnconstrainedWeights(tickers, removeTicker = myRemoveTicker,
        myRollRegLength = useRollRegLength, minNumberTickers = myMinNumberTickers)

  if(deleverReturns){
    wt = wt/rowSums(abs(wt), na.rm = T)
  }

  calcPortRet(ret, wt, name, returnXts)
}




# tickers = etfs["msci em country stocks", mqaid]
# name = "test"
# myRemoveTicker = "spy_index"
# myRollRegLength = MALength
# myMinNumberTickers = length(tickers)/2
# requireFullData = T
# returnXts = T
# deleverReturns = T
# myWt_avgdolvol = NULL
# myAUM = 100
# myWeightSum = 1
# myLongWeightSum = 1.3
# mypctTradedOfAvgdolvol = 0.2

# createConstrainedTrueBeta
# Creates unconstrained true beta portfolio returns for tickers after removing
# myRemoveTicker from the returns
createConstrainedTrueBeta  = function(tickers, name, myRemoveTicker = "spy_index",
                                        useRollRegLength = RollRegLength,
                                        myMinNumberTickers = length(tickers)/2,
                                        deleverReturns = T,
                                        myWt_avgdolvol = NULL,
                                        myAUM = 100,
                                        myWeightSum = 1,
                                        myLongWeightSum = 1.3,
                                        mypctTradedOfAvgdolvol = 0.2,
                                        requireFullData = T, returnXts = F){
  # get returns
  ret = returnsToXts(tickers)
  
  wt = getTrueBetaUnconstrainedWeights(tickers, removeTicker = myRemoveTicker,
                                       myRollRegLength = useRollRegLength, minNumberTickers = myMinNumberTickers)
  
  
  wtc = getTrueBetaConstrainedWeights(wt, wt_avgdolvol = myWt_avgdolvol,
          AUM = myAUM, pctTradedOfAvgdolvol = mypctTradedOfAvgdolvol,
          weightSum = myWeightSum, longWeightSum = myLongWeightSum)
  
  if(deleverReturns){
    wtc = wtc/rowSums(abs(wtc), na.rm = T)
  }

  calcPortRet(ret, wtc, name, returnXts)
}




# 
# tickers = spx_sector_ingr
# myRollRegLength = RollRegLength
# minNumberTickers = length(tickers)/2
# myRequireFullData = T
# returnXts = T
# 
# tickers = msci_eafe_ingr
# benchmark = "efa_index"
# retAddition = 0.04
# name = "test"
# myRollRegLength = RollRegLength
# minNumberTickers = length(tickers)/2
# myRequireFullData = F
# returnXts = F
# constantOnly = T
# returnR2 = F

# spx_sector_ingr
# etfs["msci em country stocks", mqaid]
# test = createOLSPortfolio(spx_sector_ingr, myRollRegLength = 36, "test", constantOnly = F, returnXts = T)
# plot(cumprod(1+test))
# calcSummaryStats2(test, "spy","spy")
createOLSPortfolio = function(tickers, benchmark = NULL, retAddition = 0.01,name, myRollRegLength = RollRegLength,
                                    minNumberTickers = length(tickers)/2,
                              myRequireFullData = F, returnXts = F, 
                              constantOnly = T, returnR2 = F){
  
  if(is.character(tickers)){
    ret = returnsToXts(tickers)
  } else {
    ret = tickers
  }
  
  if(!is.null(benchmark)){
    if(is.character(benchmark)){
      benchmark = returnsToXts(benchmark)
    }
  }
  
  print(paste("Targeting",retAddition,"return"))
  # calculate time series beta to removeTicker
  wt = rollapplyr(index(ret), myRollRegLength, fill = NA, function(x){
    
    if(class(index(ret)) == "yearmon"){
      x = as.yearmon(x)
    } else if (class(index(ret)) == "Date"){
      x = as.Date(x)
    } else {
      stop("Support only yearmon and Date date classes")
    }
    # print(x[1])
    
    # Keep only returns that have no NAs
    regxret = ret[x]
    regxret = regxret[,colSums(is.na(regxret)) == 0]
    
    if(constantOnly){
      # our independent variable is a fixed 1% return
      regyret = regxret[,1]
      regyret[] = retAddition
    } else {
      if(is.null(benchmark)){
        regyret = xts(rowMeans(regxret, na.rm = T) + retAddition , index(regxret))
      } else {
        regyret = benchmark[x] + retAddition
      }
      
    }

    
    # create return variable
    res = rep(NA, ncol(ret))
    names(res) = colnames(ret)
    
    
    if(ncol(regxret) < minNumberTickers | nrow(regxret) != nrow(regyret)){
      if(returnR2){
        return(NA)
      } else {
        return(res)        
      }
    }
    
    regres = lm(regyret ~ 0 + regxret)
    
    res[names(regxret)] = coef(regres)
    
    if(returnR2){
      return(summary(regres)$r.squared)
    } else {
      return(res)      
    }

  })
  
  wt = xts(wt, index(ret))
  
  if(returnR2){
    return(na.omit(wt))
  }
  
  wt = wt[rowSums(is.na(wt)) < ncol(wt),]
  
  # Create unlevered long short returns
  wt = wt/rowSums(abs(wt), na.rm = T)
  
  if(myRequireFullData){
    wt = na.omit(wt)
  } else {
    # remove first entries that dont' have data for minNumberTickers
    wt = wt[rowSums(is.na(wt)) < minNumberTickers]
  }
  
  wt = na.fill(wt, 0)
  
  # lag weights
  wt = lagXts(wt, 1)
  
  calcPortRet(ret, wt, name, returnXts)
}

# myType = "volretls"
# myName = "momentum_l_winners_s_losers_etf"
# myETFList = SectorETFs
# myDataLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_MOM_ETF/D/Qt1.dta"
# longOnly = F
# useETFsCSVFile = F
# reads in Ada Alts platform Qt1 file, gets hedging loads
# sets up weights, calculates returns, and adds both to dat
getAdaPlatformETFReplication = function(myType, myName, myETFList, myDataLocation, longOnly = F,
                                        useETFsCSVFile = F){
  
  my_weights = read.dta(myDataLocation)
  
  # long short weights
  my_weights = my_weights[,c("monthnumber", grep(paste0("hload.+",myType,"$"), colnames(my_weights), value = T))]
  my_weights = xts(my_weights[,-1], as.yearmon(MonthnToYearmon[as.character(my_weights[,"monthnumber"]), yearmon]))
  colnames(my_weights) = gsub(myType,"", gsub("hload","", colnames(my_weights)))
  my_weights = my_weights[rowSums(abs(my_weights)) > 0]
  
  if(useETFsCSVFile){
    etfret = getMonthlyETFData()
    etfret = data.frame(etfret, stringsAsFactors = F)
    etfret = xts(etfret[,myETFList],
                 as.yearmon(as.Date(as.character(etfret[,"date"]), format = "%m/%d/%Y")))
  } else {
    colnames(my_weights) = tickerToMqaid(colnames(my_weights))
    etfret = returnsToXts(colnames(my_weights))
  }

  # commonmonths = getCommonMonths(my_weights, etfret)
  
  # my_weights = my_weights[commonmonths]
  
  # my_weights = my_weights/rowSums(my_weights)
  # unlevered long short
  my_weights = my_weights/rowSums(abs(my_weights))

  if(longOnly) my_weights = abs(my_weights)
  
  etfret = etfret[, colnames(my_weights)]
  
  if(length(setdiff(colnames(my_weights),colnames(etfret))) > 0 |
     length(setdiff(colnames(my_weights),colnames(etfret))) > 0){
    stop("value etf replication data is setup incorrectly")
  }
  
  
  calcPortRet(etfret, my_weights,myName,F)
#   addXtsToDat(my_weights, paste(myName,"weights", sep = "_"))
#   addXtsToDat(my_ret,"monthly_return")
#   
}



adjustStratFactWeights = function(mywt, portToIncrease = NULL){
  
  # adjust the strategic factor weights
  if(any(grepl("strategic_factors_portfolio",colnames(mywt)))){
    stratfw = datToXts(dat["strategic_factors_portfolio_weights"])
    stratname = "strategic_factors_portfolio"
  } else if(any(grepl("strategic_factors_index_portfolio",colnames(mywt)))){
    stratfw = datToXts(dat["strategic_factors_index_portfolio_weights"])
    stratname = "strategic_factors_index_portfolio"
  } else {
    stop("no strategic factors in portfolio, why call adjustStratFactWeights?")
  }
  
  stratfw = xts(rowSums(abs(stratfw)), index(stratfw))

  stratfw = stratfw[index(mywt)]
  mywt = mywt[index(stratfw)]
  # the strategic factor returns assume we invest stratfw in them
  # need to increase the weight of the rest months where
  # stratfw is not 1
  not_invested_in_stratfw = (1 - stratfw) * mywt[,stratname]
  
  
  if(is.null(portToIncrease)){
    # If we aren't increasing any particular portfolio
    mywt[,setdiff(colnames(mywt), stratname)] = apply(mywt[,setdiff(colnames(mywt), stratname)],2,function(x){
      x = xts(x,index(mywt))
      
      # need to add not_invested_in_stratfw to x in it's proportions to the rest of the portfolio
      x + not_invested_in_stratfw * x / 
        xts(rowSums(  mywt[,setdiff(colnames(mywt), stratname)] ),index(mywt))
    }) 
    
  } else {
    mywt[,portToIncrease] = mywt[,portToIncrease] +  not_invested_in_stratfw
    
  }
  return(mywt)
}







# adjustToFullyInvestedWeights
# Checks if a portfolio, portToAnalyze is fully allocated
# fully allocated is sum of absolute weights are 1
# if it is not fully allocated, it allocates the rest to
# either a specific portfolio, portToIncrease, or of its NULL
# then rest of the portfolio

adjustToFullyInvestedWeights = function(mywt, portToAnalyze,portToIncrease = NULL){
  
  # get the ingredient weights of portToAnalyze
  # if the portToAnalyze doesn't have weight in dat, assume its
  # fully invested
  if(nrow(dat[paste(portToAnalyze,"weights", sep = "_")]) <= 1){
    portToAnalyze_weights = mywt[,portToAnalyze]
    portToAnalyze_weights[] = 1
  } else {
    portToAnalyze_weights = getIngredientWeights(portToAnalyze)
  }
  
 
  if(nrow(portToAnalyze_weights) <= 1) stop(paste("no",portToAnalyze,"in portfolio, why call adjustToFullyInvestedWeights?"))

  # get how much we are invested
  portToAnalyze_weights = xts(rowSums(abs(portToAnalyze_weights), na.rm = T), index(portToAnalyze_weights))
  
  portToAnalyze_weights = portToAnalyze_weights[index(mywt)]
  mywt = mywt[index(portToAnalyze_weights)]
  
  # print(paste("Doing", portToAnalyze,"sum of abs weights are"))
  # print(portToAnalyze_weights)
  # if fully allocated, then portToAnalyze_weights should be 1
  # if not invested at all, then portToAnalyze_weights should be 0
  if(any(portToAnalyze_weights > 1.0001, na.rm = T) | any(portToAnalyze_weights < -0.0001, na.rm = T)){
    stop(paste(portToAnalyze,"sum of abs weights are not between 0 and 1"))
  }
  
  not_invested_in_portToAnalyze = (1 - portToAnalyze_weights) * mywt[,portToAnalyze]
  
  
  if(is.null(portToIncrease)){
    # If we aren't increasing any particular portfolio
    mywt[,setdiff(colnames(mywt), portToAnalyze)] = apply(mywt[,setdiff(colnames(mywt), portToAnalyze)],2,function(x){
      x = xts(x,index(mywt))
      
      # need to add not_invested_in_portToAnalyze to x in it's proportions to the rest of the portfolio
      x + not_invested_in_portToAnalyze * x / 
        xts(rowSums(  mywt[,setdiff(colnames(mywt), portToAnalyze)] ),index(mywt))
    }) 
    
  } else {
    mywt[,portToIncrease] = mywt[,portToIncrease] +  not_invested_in_portToAnalyze
    
  }
  return(mywt)
}



createVolCaptureEquityAdj = function(tilt_size = 0.1){
  
  wtsig = dat[.("signal_l1m","ada_hml_rm_rf_vol_ratio"), xts(value, year_mon)]
  
  roll_median = rollmedianr(wtsig, (15 * AnnualizationFactor + 1) )
  wtsig = wtsig[index(roll_median)]
  wtsig = xts(as.numeric(wtsig <= roll_median), index(wtsig))
  
  wt = wtsig 
  wt[wt == 1] = tilt_size
  wt[wt == 0] = - tilt_size
  return(wt)
}

# fixed_weight = dyn2
# name = "test"
# mytiltsize = 0.1
# fundingPort = "us_treasuries_etf_portfolio"
# requireFullData = T
# returnXts = T
# fullyInvested = T

createVolCapturePort = function(fixed_weight, name, mytiltsize, fundingPort = NULL, 
                                requireFullData = T, returnXts = F, fullyInvested = T){
  
  if(fullyInvested){
    if( abs(sum(fixed_weight) - 1) > 0.0001 ) stop("createVolCapturePort weights don't sum to 1")
  }
  # get returns
  ret = returnsToXts(names(fixed_weight))
  
  wt = ret
  
  for(i in names(fixed_weight)){
    wt[!is.na(ret[,i]),i] = fixed_weight[i]
  }
  
  voladj = createVolCaptureEquityAdj(mytiltsize)
  
  common_months = getCommonMonths(voladj,wt)
  wt = wt[common_months]
  voladj = voladj[common_months]
  ret = ret[common_months]
  
  
  # increase vol capture weight on equities
  wt[,names(fixed_weight)[1]] = wt[,names(fixed_weight)[1]] + voladj
   
  # decrease weights on others
  
  if(is.null(fundingPort)){
    # if fundingPort is NULL, then we fund proportionally
    rest_scale = (1 - wt[,names(fixed_weight)[1]]) / 
      xts(rowSums(wt[,setdiff(colnames(wt), names(fixed_weight)[1])]),index(wt))
    
    for(i in 2:ncol(wt)){
      wt[,i] = wt[,i] * rest_scale
    }
  } else {
    # if fundingPort is not NULL, we fund from fundingPort
    
    
    wt[, fundingPort] = wt[, fundingPort] - (wt[,names(fixed_weight)[1]] - fixed_weight[1])
  }

  
  if(any(abs(rowSums(wt) - 1) > 0.0001, na.rm = T)){
    stop("createVolCapturePort weights don't sum to 1 all months")
  }
  
  
  if(requireFullData){
    wt[is.na(ret)] = NA
    wt = na.omit(wt)
  } else {
    wt[is.na(ret)] = 0
  }
  
  
  if(fullyInvested){
    # if fullyInvested then scale weights to sum to 1
    wt = wt/rowSums(wt)
  } else if(any(wt < 0)){
    # Create unlevered long short portfolio if there is a short
    wt = wt/rowSums(abs(wt))
  }
  
  
  # Strategic factor adjustment
  # Need to increase weights of rest of portfolio
  # if strategic factors are present
  # as those weights range between 0 and X% of the allocation
  if("strategic_factors_portfolio" %in% colnames(wt)){
    wt = adjustStratFactWeights(wt)
  }
  
  calcPortRet(ret, wt, name, returnXts)
}




# createFinalFWPort = function(fixed_weight, name, myPortToIncrease = names(fixed_weight)[1], requireFullData = T, returnXts = F, fullyInvested = T){
#   
#   if(fullyInvested){
#     if( abs(sum(fixed_weight) - 1) > 0.0001 ) stop("createFinalFWPort weights don't sum to 1")
#   }
#   # get returns
#   ret = na.omit(returnsToXts(names(fixed_weight)))
#   
#   wt = ret
#   
#   for(i in names(fixed_weight)){
#     wt[,i] = fixed_weight[i]
#   }
#   
#   if(any(grepl("strategic_factors_portfolio",colnames(wt))) |
#      any(grepl("strategic_factors_index_portfolio",colnames(wt)))){
#     wt = adjustStratFactWeights(wt,myPortToIncrease)
#   }
#   
#   if(requireFullData){
#     wt[is.na(ret)] = NA
#     wt = na.omit(wt)
#   } else {
#     wt[is.na(ret)] = 0
#   }
#   
#   
#   calcPortRet(ret, wt, name, returnXts)
# }


# createFixedWeights
createFixedWeights = function(fixed_weight, scaleUpPortfolio = F,
                              myPortToIncrease = names(fixed_weight)[1]){
  wt = na.omit(returnsToXts(names(fixed_weight)))

  # need to add next month, for trading
  wt = rbind(wt,xts(wt[nrow(wt)], index(wt[nrow(wt)]) + 1/12))
  
  for(i in names(fixed_weight)){
    wt[,i] = fixed_weight[i]
  }
  
  if(scaleUpPortfolio){
    for(i in colnames(wt)){
      wt = adjustToFullyInvestedWeights(wt, i, myPortToIncrease)
    }
  }
  
  return(wt)
}

# Creates a fixed weight portfolio
# Default is it scales up the first name in the fixed_weight variable if there
# is any other variable that doesn't have sum(abs(weights)) 1
# if myPortToIncrease = NULL, then it scales everything else up proportionally
# 
# fixed_weight = global_macro_port
# name = "global_macro_etf_portfolio_55_6040_20_stratfact_10_commfx_5_goldbug_5_gold_5_usd_AR_at_35"
# myPortToIncrease = if(scaleEverythingUp) {NULL} else {names(broadening_port)[1]}
# returnXts = T
# requireFullData = F
# fullyInvested = T
# scaleUpPortfolio = T

createFixedWeightPort = function(fixed_weight, name, requireFullData = T, 
  returnXts = F, fullyInvested = T, myPortToIncrease = names(fixed_weight)[1],
  scaleUpPortfolio = T){
  
  if(fullyInvested){
    if( abs(sum(fixed_weight) - 1) > 0.0001 ) stop("createFinalFWPort weights don't sum to 1")
  }
  # get returns
  ret = na.omit(returnsToXts(names(fixed_weight)))
  
  wt = ret
  
  # need to add next month, for trading
  wt = rbind(wt,xts(wt[nrow(wt)], index(wt[nrow(wt)]) + 1/12))
  for(i in names(fixed_weight)){
    wt[,i] = fixed_weight[i]
  }
  
  if(scaleUpPortfolio){
    for(i in colnames(wt)){
      wt = adjustToFullyInvestedWeights(wt, i, myPortToIncrease)
    }
    
    #   if(any(grepl("strategic_factors_portfolio",colnames(wt))) |
    #      any(grepl("strategic_factors_index_portfolio",colnames(wt)))){
    #     wt = adjustStratFactWeights(wt,myPortToIncrease)
    #   }
  }

  

  if(requireFullData){
    wt[is.na(ret)] = NA
    wt = na.omit(wt)
  } else {
    wt[is.na(ret)] = 0
  }
  
  
  calcPortRet(ret, wt, name, returnXts)
}


createFixedWeightPortNoScale = function(fixed_weight, name, requireFullData = T){
  createFixedWeightPort(fixed_weight = fixed_weight, name = name, requireFullData = requireFullData, 
                        returnXts = F, fullyInvested = T, myPortToIncrease = NULL,
                        scaleUpPortfolio = F)
  
}


createFixedWeightPortScaleAll = function(fixed_weight, name, requireFullData = T){
  createFixedWeightPort(fixed_weight = fixed_weight, name = name, requireFullData = requireFullData, 
                        returnXts = F, fullyInvested = T, myPortToIncrease = NULL,
                        scaleUpPortfolio = T)
  
}

# 
# weight = dyn1_all
# name = "test"
# requireFullData = T
# riskLength = 12
# returnXts = T
# fullyInvested = F


createFinalRPPort = function(weight, name, riskLength = RollSDLength, requireFullData = T, returnXts = F, fullyInvested = T){
  
  # get returns
  ret = na.omit(returnsToXts(names(weight)))
  
  wt = createRiskParityWeights(names(weight), riskLength, requireFullData)
  
  
  wt = adjustStratFactWeights(wt)
  
  if(requireFullData){
    wt[is.na(ret)] = NA
    wt = na.omit(wt)
  } else {
    wt[is.na(ret)] = 0
  }
  
  
  calcPortRet(ret, wt, name, returnXts)
}





createPortfolios = function(ingr, ingr_name, need_full_data = T, doTrueBeta = F,
                            regLength = RollRegLength, myBenchmark = NULL){
  
  ###############################
  # currently have a bandaid on cases 
  # where we don't have an underlying index
  # example SP500 sectors, XLE, their index
  # starts in 2011, whereas ETF in 2000
  
  port = list()
  
  for(type in returnTypes){
    
    curr_ingr = if(type == "etf"){
      ingr
    } else if(type == "index"){
      if( all(paste(ingr,"index", sep = "_") %in% dat["monthly_return",unique(mqaid)]) ){
        # if we have _index version of the ingredients
        # then use it
        paste(ingr,"index", sep = "_")
      } else {
        # if we don't have an _index version of the ingredients
        # then use the raw ingredients
        ingr
      }
    } else if(type == "backfilled"){
      if( all(paste(ingr,"backfilled", sep = "_") %in% dat["monthly_return",unique(mqaid)]) ){
        # if we have _backfilled version of the ingredients
        # then use it
        paste(ingr,"backfilled", sep = "_")
      } else {
        # if we don't have an _backfilled version of the ingredients
        # then use the raw ingredients
        ingr
      }
    }
    
    # Risk Parity
    createRiskParity(curr_ingr,paste0(ingr_name,"_",type,"_rp"), requireFullData = need_full_data)
    
    # Equal weight
    createEqualWeightPort(curr_ingr,paste0(ingr_name,"_",type,"_ew"), requireFullData = need_full_data)
    
    # Time series momentum
    createTimeSeriesMom(curr_ingr,paste0(ingr_name,"_",type,"_ma_timing"),MALength, requireFullData = need_full_data)
    createTimeSeriesMomLongShort(curr_ingr,paste0(ingr_name,"_",type,"_ma_timing_ls"),MALength, requireFullData = need_full_data)
    createTimeSeriesMomBinary(curr_ingr,paste0(ingr_name,"_",type,"_ma_timing_binary"),MALength, requireFullData = need_full_data)
    
    # Cross sectional momentum
    createCrossSectionalMomPort(curr_ingr,paste0(ingr_name,"_",type,"_cross_mom"),MALength, requireFullData = need_full_data)
    createCrossSectionalMomPort(curr_ingr,paste0(ingr_name,"_",type,"_cross_mom_upper_half"),MALength, 
                                requireFullData = need_full_data, myUseUpperHalfOnly = T)
    createCrossSectionalMomPortLongShort(curr_ingr,paste0(ingr_name,"_",type,"_cross_mom_ls"),MALength, requireFullData = need_full_data)
    
    # Cross sectional momentum based on Sharpe ratio
    createCrossSectionalMomPort(curr_ingr,paste0(ingr_name,"_",type,"_cross_mom_sharpe"),MALength, myUseSharpe = T, requireFullData = need_full_data)
    createCrossSectionalMomPort(curr_ingr,paste0(ingr_name,"_",type,"_cross_mom_sharpe_upper_half"),MALength, myUseSharpe = T, 
                                requireFullData = need_full_data, myUseUpperHalfOnly = T)
    createCrossSectionalMomPortLongShort(curr_ingr,paste0(ingr_name,"_",type,"_cross_mom_sharpe_ls"),MALength, myUseSharpe = T, requireFullData = need_full_data)
    
#     # create OLS portfolios
#     
#     # want to calculate the portfolio that uses equal weight of curr_ingr in all cases
#     createOLSPortfolio(curr_ingr, paste0(ingr_name,"_",type,"_ols_constant"), 
#                        benchmark = NULL, retAddition = 0.01, myRollRegLength = regLength, constantOnly = T)
#     createOLSPortfolio(curr_ingr, paste0(ingr_name,"_",type,"_ols_ewret_and_constant"), 
#                        benchmark = NULL, retAddition = 0.05/12, myRollRegLength = regLength, constantOnly = F)
# #     
#     if(!is.null(myBenchmark)){
#       createOLSPortfolio(curr_ingr, paste0(ingr_name,"_",type,"_ols_constant_", myBenchmark), 
#                          benchmark = myBenchmark, retAddition = 0.01, myRollRegLength = regLength, constantOnly = T)
#       createOLSPortfolio(curr_ingr, paste0(ingr_name,"_",type,"_ols_ewret_and_constant_", myBenchmark), 
#                          benchmark = myBenchmark, retAddition = 0.05/12, myRollRegLength = regLength, constantOnly = F)
#       
#     }

    
    if(doTrueBeta){
      
      createUnconstrainedTrueBeta(curr_ingr, paste0(ingr_name,"_",type,"_true_beta_unconstrained"), 
                                  useRollRegLength = regLength, requireFullData = need_full_data)
      
      # Can only calculate constrained true beta if I have avgdolvol data
      # which I only have for etfs
      if(type == "etf"){
        createConstrainedTrueBeta(curr_ingr, paste0(ingr_name,"_",type,"_true_beta_constrained"), 
                                  useRollRegLength = regLength, requireFullData = need_full_data)
      }

      
      
    }
    
    
    
    port[[type]] = c(paste0(ingr_name,"_",type,"_rp"),
                     paste0(ingr_name,"_",type,"_ew"),
                     paste0(ingr_name,"_",type,"_ma_timing"),
                     paste0(ingr_name,"_",type,"_ma_timing_ls"),
                     paste0(ingr_name,"_",type,"_ma_timing_binary"),
                     paste0(ingr_name,"_",type,"_cross_mom"),
                     paste0(ingr_name,"_",type,"_cross_mom_upper_half"),
                     paste0(ingr_name,"_",type,"_cross_mom_ls"),
                     paste0(ingr_name,"_",type,"_cross_mom_sharpe"),
                     paste0(ingr_name,"_",type,"_cross_mom_sharpe_upper_half"),
                     paste0(ingr_name,"_",type,"_cross_mom_sharpe_ls"),
#                      paste0(ingr_name,"_",type,"_ols_constant"),
#                      paste0(ingr_name,"_",type,"_ols_ewret_and_constant"),
#                      if(!is.null(myBenchmark)){
#                        c(paste0(ingr_name,"_",type,"_ols_constant_", myBenchmark),
#                          paste0(ingr_name,"_",type,"_ols_ewret_and_constant_", myBenchmark))
#                      },
                     if(doTrueBeta){
                       c(paste0(ingr_name,"_",type,"_true_beta_unconstrained"),
                         paste0(ingr_name,"_",type,"_true_beta_constrained"))
                     })
  }
  
  return(port)
}





# creates a fixed weight portfolio for all of the return types
createAllFixedWeightPort = function(port, portname){
  for(type in returnTypes){
    if(type == "etf"){
      createFixedWeightPort(port, portname)
    } else if(type == "index"){
      
      # change port name to index
      names(port) = gsub("etf",type, names(port))
      portname = gsub("etf",type, portname)
      
      createFixedWeightPort(port, portname)
      
      # change port name back to etf
      names(port) = gsub(type, "etf", names(port))
      portname = gsub(type, "etf", portname)
    } else if(type == "backfilled"){
      
      # change port name to backfilled
      names(port) = gsub("etf",type, names(port))
      portname = gsub("etf",type, portname)
      
      createFixedWeightPort(port, portname)
      
      # change port name back to etf
      names(port) = gsub(type, "etf", names(port))
      portname = gsub(type, "etf", portname)
    }
    
  }
}


# adds x to the list of portfolios
addToPortfolioList = function(x, location, input_type = NULL){
  
  # Adds the location if it doesn't exist
  
  if(is.null(portfolios[[location]])) {
    create_new_list = T
    #     portfolios[[location]] = list()
    #     for(i in returnTypes) portfolios[[location]][[i]] = list()
  } else {
    create_new_list = F
  }
  
  if(!create_new_list){
    for(i in x){
      # find out what returnType i is
      i_type = sapply(returnTypes,function(y)grepl(y, i))
      
      # if all i_type are FALSE, then we need to add a new list
      if(any(i_type)){
        portfolios[[location]][[names(which(i_type))]] <<-
          c(portfolios[[location]][[names(which(i_type))]], i)
      } else {
        if(is.null(portfolios[[location]][[input_type]])){
          portfolios[[location]][[input_type]] <<- i
        } else {
          portfolios[[location]][[input_type]] <<- 
            c(portfolios[[location]][[input_type]], i)
        }

      }

    }
  } else {
    tempres = list()
    
    for(i in x){
      # find out what returnType i is
      i_type = sapply(returnTypes,function(y)grepl(y, i))
      
      tempres[[names(which(i_type))]] = i
    }
    
    portfolios[[location]] <<- tempres
  }
  
}


# port = goldport
# portname = "gold_etf_ma_timing5"
# port_function = function(x,y){
# createTimeSeriesMomLongShort(names(x),y, 24,T,F,1)
# }
# allReturnTypes = T

createAllPort = function(port, portname, port_function, allReturnTypes = T){
  
  if(allReturnTypes){
    for(type in returnTypes){
      if(type == "etf"){
        port_function(port, portname)
      } else if(type == "index"){
        
        # change port name to index
        names(port) = gsub("etf",type, names(port))
        portname = gsub("etf",type, portname)
        
        port_function(port, portname)
        
        # change port name back to etf
        names(port) = gsub(type, "etf", names(port))
        portname = gsub(type, "etf", portname)
      } else if(type == "backfilled"){
        
        # change port name to backfilled
        names(port) = gsub("etf",type, names(port))
        portname = gsub("etf",type, portname)
        
        port_function(port, portname)
        
        # change port name back to etf
        names(port) = gsub(type, "etf", names(port))
        portname = gsub(type, "etf", portname)
      }
      
    }
    
    # returns all the portfolio names done
    return(  sapply(returnTypes,function(x){
      gsub("etf",x, portname)
    }))
    
  } else {
    port_function(port, portname)
    return(portname)
  }
  
  

}


createAllStrategyPorts = function(port, portname, doAllReturnTypes = T, type = "etf_portfolio",
                                  addToPortListInputType = NULL){
  

  namesadd = createAllPort(port, paste0(portname,"_fixed_weights_",type), 
                           createFixedWeightPort, allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, portname, input_type = addToPortListInputType)
  
  namesadd = createAllPort(port, paste0(portname,"_fixed_weights_rp_",type), function(x,y){
    createRPModifiedFixedWeightPort(x,y,RollSDLength,maxRPDeviations)
  }, allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, portname, input_type = addToPortListInputType)
  
  
  namesadd = createAllPort(port,paste0(portname,"_rp_",type), function(x,y){
    createRiskParity(names(x),y)
  }, allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, portname, input_type = addToPortListInputType)
  
  
  namesadd = createAllPort(port,paste0(portname,"_ma_timing_",type), function(x,y){
    createTimeSeriesMom(names(x),y, MALength)
  }, allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, portname, input_type = addToPortListInputType)
  
}



# createAllFinalPorts
# Creates all the final 60/40 portfolios
createAllFinalPorts = function(my_final_port, name, doAllReturnTypes = T, type = "etf_portfolio",
                               addToPortListInputType = NULL){
  
  namesadd = createAllPort(my_final_port, paste0(name, "_fixed_weights_",type), 
                           createFixedWeightPort,allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, name, input_type = addToPortListInputType)
  
  namesadd = createAllPort(my_final_port, paste0(name,"_volcap10pct_",type), function(x,y){
    createVolCapturePort(x, y, 0.1)
  },allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, name, input_type = addToPortListInputType)
  
  namesadd = createAllPort(my_final_port, paste0(name,"_volcap20pct_",type), function(x,y){
    createVolCapturePort(x, y, 0.2)
  },allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, name, input_type = addToPortListInputType)
  
  namesadd = createAllPort(my_final_port, paste0(name,"_fixed_weights_rp_",type), function(x,y){
    createRPModifiedFixedWeightPort(x,y,RollSDLength,maxRPDeviations)
  },allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, name, input_type = addToPortListInputType)
  
  
  namesadd = createAllPort(my_final_port, paste0(name,"_rp_",type), function(x,y){
    createRiskParity(names(x),y)
  },allReturnTypes = doAllReturnTypes)
  addToPortfolioList(namesadd, name, input_type = addToPortListInputType)
  
}



# compares a portfolio to its equal risk and equal weight 
# implementation, to see if it adds statistically significant
# value above equal weight or equal risk
# Equal risk is a portfolio that has a constant average of the 
# base portfolio weights
evaluateDatPortfolio = function(name){
  ret = returnsToXts(c(name,
                 paste(name,"equal_weight", sep = "_"), 
                 paste(name, "equal_risk", sep = "_")))
  
  ercomp = as.formula(get(name) ~ get(paste(name, "equal_risk", sep = "_")))
  ewcomp = as.formula(get(name) ~ get(paste(name, "equal_weight", sep = "_")))
  
  erres = summarizeRegCoef(summary(lm(ercomp, data = ret)))[2,]
    ewres = summarizeRegCoef(summary(lm(ewcomp, data = ret)))[2,]
  
  res = rbind(erres[,-ncol(erres)], ewres[,-ncol(ewres)])
  colnames(res)[1] = "Alpha"
  
  rownames(res) = c("Equal Risk","Equal Weight")
  
  return(res)
}




# createPortSignalAdj
# Creates over and underweight matrix for a portfolio based on a signal
# port = wt_adj
# signal = gb_adj
# portIncName = setdiff(colnames(wt_adj),goldbug_name)
# portDecName = goldbug_name
# myScaleUpPortfolio = F
# portToIncrease = names(port)[1]
# createPortSignalAdj = function(port, signal, portIncName, portDecName,
#                                myScaleUpPortfolio = F, portToIncrease = names(port)[1]){
#   
#   # If we are giving numeric input, then we want to use createFixedWeights, 
#   # otherwise we supply the weights
#   if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
#     port_adj = port
#   } else {
#     port_adj = createFixedWeights(port, 
#                                   scaleUpPortfolio = myScaleUpPortfolio,
#                                   myPortToIncrease = portToIncrease)
#   }
# 
#   port_adj[,] = 0
#   
#   common_months = getCommonMonths(port_adj,signal)
#   port_adj = port_adj[common_months]
#   signal = signal[common_months]
#   if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
#     port = port[common_months]  
#   }
#   
#   # If we are increasing more than 1 symbol, need to increase it pro-rata
#   if(length(portIncName) > 1){
#     signal_inc = do.call(merge,lapply(portIncName, function(name){
#       # if we supplied weights, then need to allocate proportional to the weight that month
#       if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
#         
#         if(all(rowSums(port[,portIncName]) == 0)){
#           signal * 1/length(portIncName)
#         } else {
#           signal * port[,name]/rowSums(port[,portIncName])
#         }
#       } else {
#         if(all(port[portIncName] == 0)){
#           signal * 1/length(portIncName)
#         } else {
#           signal * port[name]/sum(port[portIncName])
#         }
#         
#       }
#       
#     }))
#     
#     colnames(signal_inc) = portIncName
#   } else {
#     signal_inc = signal
#   }
#   
#   
#   # If we are decreasing more than 1 symbol, need to decrease it pro-rata
#   if(length(portDecName) > 1){
#     signal_dec = do.call(merge,lapply(portDecName, function(name){
#       # if we supplied weights, then need to allocate proportional to the weight that month
#       if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
#         signal * port[,name]/rowSums(port[,portDecName])
#       } else {
#         signal * port[name]/sum(port[portDecName])
#       }
#     }))
#     
#     colnames(signal_dec) = portDecName
#   } else {
#     signal_dec = signal
#   }
#   
#   
#   port_adj[,portIncName] = port_adj[,portIncName] + signal_inc
#   port_adj[,portDecName] = port_adj[,portDecName] - signal_dec
#   
#   if(any(round(rowSums(port_adj),DiffTolerance)  != 0)) stop("createPortSignalAdj aggregate weight change is not 0")
#   return(port_adj)
# }
# 


createPortSignalAdj = function(port, signal, portIncName, portDecName,
                               myScaleUpPortfolio = F, portToIncrease = names(port)[1],
                               wtRatio = NULL){
  
  # If we are giving numeric input, then we want to use createFixedWeights, 
  # otherwise we supply the weights
  if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
    port_adj = port
  } else {
    port_adj = createFixedWeights(port, 
                                  scaleUpPortfolio = myScaleUpPortfolio,
                                  myPortToIncrease = portToIncrease)
  }
  
  port_adj[,] = 0
  
  common_months = getCommonMonths(port_adj,signal)
  port_adj = port_adj[common_months]
  signal = signal[common_months]
  if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
    port = port[common_months]  
  }
  
  # If we are increasing more than 1 symbol, need to increase it pro-rata
  if(length(portIncName) > 1){
    
    # if we haven't given dynamic weights in through wtRatio
    # allocate in ratio of fixed weights
    if( is.null(wtRatio) ){
      signal_inc = do.call(merge,lapply(portIncName, function(name){
        # if we supplied weights, then need to allocate proportional to the weight that month
        if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
            signal * port[,name]/rowSums(port[,portIncName])
        } else {
            signal * port[name]/sum(port[portIncName])
        }
      }))
      
      colnames(signal_inc) = portIncName
    } else {
      
      # allocate in ratio of wtRatio each month
      
      signal_inc = do.call(merge,lapply(portIncName, function(name){
        # if we supplied weights, then need to allocate proportional to the weight that month
        # if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
          signal * wtRatio[,name]/rowSums(wtRatio[,portIncName])
#         } else {
#           signal * port[name]/sum(port[portIncName])
#         }
      }))
      
      colnames(signal_inc) = portIncName
      
      
    }
  } else {
    signal_inc = signal
  }
  
  
  # If we are decreasing more than 1 symbol, need to decrease it pro-rata
  if(length(portDecName) > 1){
    
    # if we haven't given dynamic weights in through wtRatio
    # allocate in ratio of fixed weights
    if( is.null(wtRatio) ){
      signal_dec = do.call(merge,lapply(portDecName, function(name){
        # if we supplied weights, then need to allocate proportional to the weight that month
        if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
          signal * port[,name]/rowSums(port[,portDecName])
        } else {
          signal * port[name]/sum(port[portDecName])
        }
      }))
      
      colnames(signal_dec) = portDecName
    } else {
      # allocate in ratio of wtRatio each month
      
      signal_dec = do.call(merge,lapply(portDecName, function(name){
        # if we supplied weights, then need to allocate proportional to the weight that month
        # if(class(port)[1] == "xts" | class(port)[1] == "zoo"){
        signal * wtRatio[,name]/rowSums(wtRatio[,portDecName])
        #         } else {
        #           signal * port[name]/sum(port[portDecName])
        #         }
      }))
      
      colnames(signal_dec) = portDecName
    }
  } else {
    signal_dec = signal
  }
  
  
  port_adj[,portIncName] = port_adj[,portIncName] + signal_inc
  port_adj[,portDecName] = port_adj[,portDecName] - signal_dec
  
  if(any(round(rowSums(port_adj),DiffTolerance)  != 0)) stop("createPortSignalAdj aggregate weight change is not 0")
  return(port_adj)
}


# createDynamicPortfolio
# Creates a dynamic portfolio, from fixed weigths in port
# with port_adj added to it

createDynamicPortfolio = function(port, port_adj, port_name, doReturnXts = F,
                                  myScaleUpPortfolio = T, portToIncrease = NULL){
  
  port = createFixedWeights(port, myScaleUpPortfolio, portToIncrease)
  
  common_months = getCommonMonths(port, port_adj)
  port = port[common_months]
  port_adj = port_adj[common_months]
  
  port = port + port_adj
  
  ret = returnsToXts(colnames(port))
  
  calcPortRet(ret, port, port_name,doReturnXts)
}


# createSignalStrengthComparison
# Compares results of using createSignalStrengthWeights
# on a cross sectional signal
# Will compare long only upper half and all, long/short upper half and all
# signal = valdat
# bmk = "eem"
# sigName = "value"
# lagWeights = F
createSignalStrengthComparison = function(signal, bmk, sigName, lagWeights = T, myReturns = NULL){
  
  if(is.null(myReturns)){
    myReturns = returnsToXts(colnames(signal))
  }
  
  wt_long_upper_half = createSignalStrengthWeights(signal, F, T, F, lagWeights, returns = myReturns)
  wt_long_upper_half_ew = createSignalStrengthWeights(signal, F, T, F, lagWeights, returns = myReturns, equalWeight = T)
  wt_long = createSignalStrengthWeights(signal, F, F, F, lagWeights, returns = myReturns)
  wt_ls_upper_half = createSignalStrengthWeights(signal, F, T, T, lagWeights, returns = myReturns)
  wt_ls_upper_half_ew = createSignalStrengthWeights(signal, F, T, T, lagWeights, returns = myReturns, equalWeight = T)
  wt_ls = createSignalStrengthWeights(signal, F, F, T, lagWeights, returns = myReturns, upperPctile = 0.5, lowerPctile = 0.5)
  
  wt_ew = xts(wt_long != 0,index(wt_long))
  wt_ew = wt_ew/rowSums(wt_ew, na.rm = T)
  
  ret = returnsToXts(colnames(wt_long))
#   wt_long2 = wt_ew + wt_ls
#   wt_long
#   
#   rowSums(wt_long2 - wt_long)
  ret_ew = calcPortRet(ret, wt_ew,"",T)
  ret_long_upper_half = calcPortRet(ret, wt_long_upper_half, "",T)
  ret_long_upper_half_ew = calcPortRet(ret, wt_long_upper_half_ew, "",T)
  ret_long = calcPortRet(ret, wt_long, "",T)
  ret_ls_upper_half = calcPortRet(ret, wt_ls_upper_half, "",T)
  ret_ls_upper_half_ew = calcPortRet(ret, wt_ls_upper_half_ew, "",T)
  ret_ls = calcPortRet(ret, wt_ls, "",T)
  
 if(!is.null(bmk)){
       sigret = merge(returnsToXts(bmk), ret_ew,
                      ret_long, ret_long_upper_half, ret_long_upper_half_ew, 
                      ret_ls,ret_ls_upper_half,ret_ls_upper_half_ew)
  } else {
       sigret = merge(ret_ew,
                      ret_long, ret_long_upper_half, ret_long_upper_half_ew, 
                      ret_ls,ret_ls_upper_half,ret_ls_upper_half_ew)
  }
 
  sigret = na.omit(sigret)
 colnames(sigret) = c(if(!is.null(bmk)){bmk},"EW","Long","Long Upper Half","Long Upper Half EW",
                       "Long Short","Long Short Upper Half","Long Short Upper Half EW")
  
  # add the weight list
  wt_list = list()
  wt_list[["EW"]] = wt_ew
  wt_list[["Long"]] = wt_long
  wt_list[["Long Upper Half"]] = wt_long_upper_half
  wt_list[["Long Upper Half EW"]] = wt_long_upper_half_ew
  wt_list[["Long Short"]] = wt_ls
  wt_list[["Long Short Upper Half"]] = wt_ls_upper_half
  wt_list[["Long Short Upper Half EW"]] = wt_ls_upper_half_ew
  
  write.csv(calcSummaryStats2(sigret,if(!is.null(bmk)){bmk} else {ret_ew},
                              if(!is.null(bmk)){bmk} else {"EW"}, wt_list = wt_list), paste(paste0(sigName,".csv")))
  return(sigret)
}




# createSignalStrengthMonotonicity
# Evalutes a signal for monotonicity, using 4 levels, long only or long short
createSignalStrengthMonotonicity = function(signal = mySignal, bmk = myBmk, sigName = mySigName, 
                                            lagWeights = T, myReturns = NULL,
                                            longShort = F, equalWt = F,
                                            upperThresholds = if(!longShort){
                                              c(0, 0.25, 0.5, 0.75)
                                            } else {
                                              c(0.5, 0.66, 0.8, 0.9)
                                            },
                                            lowerThresholds = if(!longShort){
                                              c(0,0,0,0)
                                            } else {
                                              c(0.5, 0.33, 0.2, 0.1)
                                            }){
  
  if(is.null(myReturns)){
    myReturns = returnsToXts(colnames(signal))
  }
  
  if(!longShort){
    wt_1 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                            equalWeight = equalWt, upperPctile = upperThresholds[1])
    wt_2 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                             equalWeight = equalWt, upperPctile = upperThresholds[2])
    wt_3 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                             equalWeight = equalWt, upperPctile = upperThresholds[3])
    wt_4 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                             equalWeight = equalWt, upperPctile = upperThresholds[4])
  } else {
    wt_1 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                            equalWeight = equalWt, upperPctile = upperThresholds[1], lowerPctile = lowerThresholds[1])
    wt_2 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                             equalWeight = equalWt, upperPctile = upperThresholds[2], lowerPctile = lowerThresholds[2])
    wt_3 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                             equalWeight = equalWt, upperPctile = upperThresholds[3], lowerPctile = lowerThresholds[3])
    wt_4 = createSignalStrengthWeights(signal, F, F, longShort, lagWeights, returns = myReturns,
                                             equalWeight = equalWt, upperPctile = upperThresholds[4], lowerPctile = lowerThresholds[4])
  }

  wt_ew = xts(wt_1 != 0,index(wt_1))
  wt_ew = wt_ew/rowSums(wt_ew, na.rm = T)
  
  ret = returnsToXts(colnames(wt_1))
  #   wt_long2 = wt_ew + wt_ls
  #   wt_long
  #   
  #   rowSums(wt_long2 - wt_long)
  ret_ew = calcPortRet(ret, wt_ew,"",T)
  ret_1 = calcPortRet(ret, wt_1, "",T)
  ret_2 = calcPortRet(ret, wt_2, "",T)
  ret_3 = calcPortRet(ret, wt_3, "",T)
  ret_4 = calcPortRet(ret, wt_4, "",T)

  if(!is.null(bmk)){
       sigret = merge(returnsToXts(bmk), ret_ew,
                      ret_1, ret_2, ret_3, ret_4) 
  } else {
       sigret = merge(ret_ew,
                      ret_1, ret_2, ret_3, ret_4)
  }

  
  sigret = na.omit(sigret)
  if(longShort){
    colnames(sigret) = c(if(!is.null(bmk)){bmk},"EW","50%-50%","33%-66%","20%-80%","10%-90%")
    
    wt_list = list()
    wt_list[["EW"]] = wt_ew
    wt_list[["50%-50%"]] = wt_1
    wt_list[["33%-66%"]] = wt_2
    wt_list[["20%-80%"]] = wt_3
    wt_list[["10%-90%"]] = wt_4
    
  } else {
    colnames(sigret) = c(if(!is.null(bmk)){bmk},"EW","0% >","25% >","50% >","75% >")
    
    wt_list = list()
    wt_list[["EW"]] = wt_ew
    wt_list[["0% >"]] = wt_1
    wt_list[["25% >"]] = wt_2
    wt_list[["50% >"]] = wt_3
    wt_list[["75% >"]] = wt_4
  }
    
  
  # add the weight list


  
  write.csv(calcSummaryStats2(sigret,if(!is.null(bmk)){bmk} else {ret_ew},
                              if(!is.null(bmk)){bmk} else {"EW"}, wt_list = wt_list), paste(paste0(sigName,".csv")))
  return(sigret)
}






# createZScoreMeanReversionWeights
# Creates weights where if the z-score hits lowthres, it gets double
# the weights that haven't and that overweight is kept until z-score
# hits the highthres

createZScoreMeanReversionWeights = function(signal, myRequireFullData = T,
                               lowthres = -2, highthres = 2, scaleSumWt = T, ZScoreLength = 12){
  
  wt = lapply(colnames(signal),function(name){
    x = signal[,name]
    xz = createZScore(x,ZScoreLength)
    x = merge(x,xz)
    xz = x[,2]
    x = x[,1]
    
    
    res = x
    res[] = 1
    
    for(i in 2:length(x)){
      if( na.fill(xz[i] <= lowthres,F) ){
        res[i] = 2
      } else if( na.fill(xz[i] >= highthres, F) ){
        res[i] = 1
      } else {
        res[i] = res[i-1]
      }
    }
    
    res[is.na(x)] = NA
    
    return(res)
  })
  
  wt = do.call(merge, wt)
  
  if(scaleSumWt) wt = wt/rowSums(abs(wt), na.rm = T)
  
  
  if(myRequireFullData){
    wt = na.omit(wt)
  } else {
    # remove first entries that dont' have data for half of symbols
    wt = wt[rowSums(is.na(wt)) < (ncol(wt)/2)]
  }
  
  
  if( any( abs(rowSums(wt, na.rm = T) - 1) > 0.0001 ) & scaleSumWt ) stop("createTimeSeriesMom error: Weights don't sum to 1")
  
  # fill missing weights with 0
  wt = na.fill(wt, 0)
  
  return(wt)
}




# createLongOnlyWeights
# Creates long only weights from a weight variable
# if replaceShortWithLong is T, then we replace all shorts with a
# long position in SH, a 1X Short S&P 500 ETF
# if replaceShortWithLong is F, then we set short weights to 0.
createLongOnlyWeights = function(wt, replaceShortsWithLong = T, longSymbol = tickerToMqaid("sh")){
  
  if(is.character(wt)){
    wt = getIngredientWeights(wt)
    # wt = aggregateWeightTypes(wt)
  }
  
  if(is.data.table(longSymbol)){
    if(replaceShortsWithLong){
      
      # find out what short ETFs we will add to weights
      shortETFAdditions = length(longSymbol[colnames(wt),na.omit(unique(short_ETF))])
      shortETFNames = tickerToMqaid(longSymbol[colnames(wt),na.omit(unique(short_ETF))])
      
      # add them to weights
      wt = merge(wt,xts(matrix(0, nrow = nrow(wt),
             ncol = shortETFAdditions), index(wt)))
      
      
      colnames(wt)[(ncol(wt)- shortETFAdditions + 1) :
                     ncol(wt)] = shortETFNames
      
      for(shortETF in shortETFNames){
        
        
        wt[,shortETF] = abs(apply(wt[,longSymbol[short_ETF == mqaidToTicker(shortETF), mqaid]],1,function(x){
          sum(x[x<0])
        }))
        
        
      }
      
    }
    
  } else {
    if(replaceShortsWithLong){
      if( !(longSymbol %in% colnames(wt)) ){
        wt_names = colnames(wt)
        wt = merge(wt,xts(rep(0,nrow(wt)),index(wt)))
        colnames(wt) = c(wt_names, longSymbol)
      }
      
      
      shortwt = xts(apply(wt,1,function(x){sum(x[x<0])}),index(wt))
      
      wt[,longSymbol] = wt[,longSymbol] + abs(shortwt)
    }
  }

  
  wt[wt < 0] = 0
  
  return(wt)
}




getRollingBetaIvol = function(yret, xret, getBeta = T, RegLength = RollRegLength, lagRes = T,
                              getCorrelation = F, xretCoefToGet = 1, maxPctNAAllowed = 0){
  
  common_months = getCommonMonths(yret, xret)
  yret = yret[common_months]
  xret = xret[common_months]
  
  res = lapply(colnames(yret),function(name){
    
    tempres = xts(rollapplyr(index(yret),RegLength, function(dates){
      
      if(class(index(yret)) == "yearmon"){
        dates = as.yearmon(dates)
      } else if(class(index(yret)) == "Date"){
        dates = as.Date(dates)
      } else {
        stop("support only yearmon or Date")
      }
    
      if(sum(is.na(yret[dates,name])) > length(dates) * maxPctNAAllowed){
          NA
      } else {
           
        dates = index(na.omit(yret[dates,name]))

        if(getBeta){
             if(!getCorrelation){
                  coef(lm(yret[dates,name] ~ xret[dates]))[xretCoefToGet + 1]
             } else {
                  cor(yret[dates,name] ,xret[dates])[xretCoefToGet]
             }
          
        } else {
          sd(residuals(lm(yret[dates,name] ~ xret[dates])))
        }
      }
    }, fill = NA), index(yret))
    
    colnames(tempres) = name
    
    return(tempres)
    
  })
  
  res = do.call(merge, res)
  
  colnames(res) = colnames(yret)
  
  if(lagRes) res = lagXts(res, 1)
  
  return(res)
  
}





# setCommonSetup
# Sets all variables to the same dates and same column name setup
# Has externality, in that it changes the variables themselves in the global environment
setCommonSetup = function(x){
  
  # find the common_months
  common_months = Reduce(intersect,
                          lapply(x,function(i){index(get(i))}) )
  
  # set all variables to the column name setup of x[1]
  
  res = get(x)[1]
  
  if(class(index(res)) == "yearmon"){
    common_months = as.yearmon(common_months)
  } else if(class(index(res)) == "Date"){
    common_months = as.Date(common_months)
  } else {
    stop("support only yearmon or Date")
  }
  
  for(i in x){
    
    if(length(setdiff(colnames(res), colnames(get(i)))) > 0 |
       length(setdiff(colnames(get(i)), colnames(res))) > 0){
      stop("not all variables have the same column names")
    }
    
    assign(i, get(i)[common_months,colnames(res)], envir = .GlobalEnv)
  }
  
  return(NULL)
}

# setListToCommonMonths
# Sets all entries in the input to the same index

setListToCommonMonths = function(tempwt){
   common_months = Reduce(intersect, lapply(tempwt,index))
 
   if(class(index(tempwt[[1]])) == "yearmon"){
     common_months = as.yearmon(common_months)
   } else if(class(index(tempwt[[1]])) == "Date"){
     common_months = as.Date(common_months)
   } else {
     stop("support only yearmon or Date")
   }
 
   # set to same dates
   for(i in 1:length(tempwt)){
     tempwt[[i]] = tempwt[[i]][common_months]
   }
   
   return(tempwt)
}

# setListToCommonMonthsUnion
# Used for combining list weights when there is mismatch in when they start
setListToCommonMonthsUnion = function(tempwt){
     
     common_months = Reduce(union, lapply(tempwt,index))
     
     common_months = setToDate(common_months,tempwt[[1]])

     
     # set to same dates
     for(i in 1:length(tempwt)){
          
          
          if(length(setdiff2(common_months, index(tempwt[[i]]))) > 0){
               # Need to add NA entries in periods for dates that are not in tempwt[[i]]
               # but are in common_months
               addDates = setdiff2(common_months, index(tempwt[[i]]))
               addDates = setToDate(addDates, tempwt[[i]])
               addEntry = xts( matrix(rep(0, length(addDates) * ncol(tempwt[[i]])), ncol = ncol(tempwt[[i]])),
                               addDates)
               
               colnames(addEntry) = colnames(tempwt[[i]])
               
               tempwt[[i]] = rbind(addEntry, tempwt[[i]])
               
          }

     }
     
     return(tempwt)
}


# combineListWeights
# Combines the weights in different lists together into 1 xts object
combineListWeights = function(tempwt){
  
  
  # Need to check if there is any overlap in the tickers between tempwt
  tempwt_tickers = unlist(lapply(tempwt,function(x){
    colnames(x)
  }))
  
  # if any mqaid is duplicated, we need to combine them first
  # otherwise merge data
  if( any(duplicated(tempwt_tickers)) ){
    
    # If we have duplicated tickers in tempwt
    # we need to sum them together for each mqaid
    
    
    
    # need to set data to same starting point
    tempwt = setListToCommonMonths(tempwt)
#     # Find the intersect of all the indices
#     common_months = Reduce(intersect, lapply(tempwt,index))
#     
#     if(class(index(tempwt[[1]])) == "yearmon"){
#       common_months = as.yearmon(common_months)
#     } else if(class(index(tempwt[[1]])) == "Date"){
#       common_months = as.Date(common_months)
#     } else {
#       stop("support only yearmon or Date")
#     }
#     
#     # set to same dates
#     for(i in 1:length(tempwt)){
#       tempwt[[i]] = tempwt[[i]][common_months]
#     }
    
    
    
    
    
    # start with error checks to ensure all the elements in tempwt have the same dates setup
    if(max(sapply(tempwt, nrow)) != min(sapply(tempwt, nrow))){
      stop("getIngredientWeights error: tempwt elements don't have the same number of rows")
    }
    
    if(max(sapply(tempwt,function(x){index(x)[1]})) !=
       min(sapply(tempwt,function(x){index(x)[1]}))){
      stop("getIngredientWeights error: tempwt elements don't have the same start date")
    }
    
    if(max(sapply(tempwt,function(x){index(x)[nrow(x)]})) !=
       min(sapply(tempwt,function(x){index(x)[nrow(x)]}))){
      stop("getIngredientWeights error: tempwt elements don't have the same end date")
    }
    
    wt = xts(matrix(rep(NA, length(unique(tempwt_tickers)) * nrow(tempwt[[1]])), 
                    ncol = length(unique(tempwt_tickers))), index(tempwt[[1]]))
    
    
    colnames(wt) = unique(tempwt_tickers)
    
    for(mqaid in unique(tempwt_tickers)){
      tempwt_ticker_entry = lapply(tempwt,function(x){x[,mqaid]})
      tempwt_ticker_entry = do.call(merge, tempwt_ticker_entry)
      
      # sum up over dates
      tempwt_ticker_entry = xts(rowSums(tempwt_ticker_entry), index(tempwt_ticker_entry))
      
      wt[,mqaid] = tempwt_ticker_entry
    }
    
    
    tempwt = wt
    
  } else {
    tempwt = do.call(merge, tempwt)
    colnames(tempwt) = tempwt_tickers
  }
  
  return(tempwt)
}




# vectorToMatrix
# Takes a vector, and creates a matrix with each column being that vector, 
# with user defined number of columns
# Helpful if you are trying to multiply vectors and a matrix, and you want each 
# column in the matrix to be multiplied by the vector
vectorToMatrix = function(x, numcol, rowVector = F){
  matrix(rep(x,numcol),ncol = numcol, byrow = rowVector)
}

# vectorToXtsMatrix
# Takes a xts vector, and creates a xts matrix with each column being that vector, 
# with user defined number of columns
# Helpful if you are trying to multiply vectors and a matrix, and you want each 
# column in the matrix to be multiplied by the vector
vectorToXtsMatrix = function(x, numcol, rowVector = F){
  xts(vectorToMatrix(x,numcol, rowVector),index(x))
}


# adjustRebalancing
# Takes in weights, assumed to be rebalanced monthly, and changes the rebalancing frequency

adjustRebalancing = function(wt, rebalanceBeginPer = 1, rebalanceFreq = 3){
  
  if(is.character(wt)) wt = getIngredientWeights(wt)
  # if we get wt from getIngredientWeights, it might not account for 
  # netting, as some tickers might be xle, others might be xle_index
  # need to account for netting first
  
  # wt = aggregateWeightTypes(wt)
  wt_before = wt
  # sum of weigths before, need to ensure weights are again at teh sum of
  # weights before after doing the non rebalancing some months
  wt_sum = xts(rowSums(abs(wt)), index(wt))
  
  # get the month of the year
  wt_month = as.numeric(strftime(index(wt),"%m"))
  
  # will rebalance, starting at rebalanceBeginPer, and rebalancing every
  # rebalanceFreq
  rebalance_months = seq(rebalanceBeginPer, rebalanceBeginPer + 12, rebalanceFreq)
  rebalance_months = rebalance_months[rebalance_months <= 12]
  
  # set weights to NA, in months that are not the rebalancing months
  wt[!(wt_month %in% rebalance_months),] = NA
  
  # need to grow weights with returns the months we don't rebalance
  ret = returnsToXts(colnames(wt))
  # set weights and returns to same period    
  common_months = getCommonMonths(wt,lagXts(ret, 1))
  wt = wt[common_months]
  ret = ret[common_months]
  wt_sum = wt_sum[common_months]
  
  # calculate how much each weight grows
  for(i in 2:nrow(wt)){
    # if the month is not a rebalancing month, then I need to carry forward
    # the weights, but adjust for the returns in the month
    if(!(wt_month[i] %in% rebalance_months)){
      wt[i,] = wt[i-1,] * na.fill(1 + ret[i-1],0)
      # need to scale the wt[i,] so that they scale up to same weights as in 
      # wt_sum[i]
      
      wt[i,] = wt[i,] * as.numeric(wt_sum[i])/sum(abs(wt[i,])) # what I need it to be / what it is
    }
  }
  
  wt = na.omit(wt)
  
  return(wt)
}



# finalizeAndWriteResults
# This is used in signal files, to standardrize writing results to file and setup results

finalizeAndWriteResults = function(name, bmk){
     # write performance and returns to file
     
     # if we have index returns available, then use backfilled of bmk
     # otherwise use bmk itself
     # relevant when I create a 60/40 portfolio to use as bmk
     # then it won't have a monthly_return_index
     if(nrow(dat[.("monthly_return_index",bmk)]) > 1 |
        nrow(dat[.("monthly_return_index",paste0(mqaidAdjustment(),bmk))]) > 1){
          ret = na.omit(returnsToXts(c(name,paste(bmk,"backfilled", sep = "_"))))
          colnames(ret)[2] = mqaidToTicker(bmk)
          ret$alpha = ret[,1] - ret[,2]
          write.csv(calcSummaryStats2(ret,paste(bmk,"backfilled", sep = "_"),
                                      ifelse(is.na(mqaidToTicker(bmk)),bmk,mqaidToTicker(bmk))),"performance.csv")
     } else {
          ret = na.omit(returnsToXts(c(name,bmk)))
          colnames(ret)[2] = ifelse(is.na(mqaidToTicker(bmk)),bmk,mqaidToTicker(bmk))
          ret$alpha = ret[,1] - ret[,2]
          write.csv(calcSummaryStats2(ret,bmk,
                                      ifelse(is.na(mqaidToTicker(bmk)),bmk,mqaidToTicker(bmk))),"performance.csv")
     }
     
     
     write.csv(data.frame(ret),"returns.csv")
     
     # plot cumulative returns
     
     ret = cumprod(1+ret)
     textsize = 1.5
     
     
     png("cumulative returns.png", width = 600, height = 480)
     
     if(nrow(ret) > 2){
          plot(ret[,1], type = "n", ylim = c(min(ret),max(ret)), main = paste("Cumulative Returns"),
               cex = textsize, cex.axis = textsize, cex.main = textsize)
          lines(ret[,1], col = "black", lwd = 2)
          lines(ret[,2], col = "red", lwd = 2)
          lines(ret[,3], col = "forestgreen", lwd = 2)
          
          legend("topleft", gsub("_"," ",gsub("backfilled|index","",c(name,bmk,"alpha"))), 
                 text.col = c("black","red","forestgreen"), bty = "n", cex = textsize) 
     }
     
     dev.off()
     
     
     # change the portfolio weights name to weight
     dat <<- dat[paste(name,"weights", sep = "_"), type := "weight"]
     
     # remove backfilled from tickers
     dat <<- dat[, mqaid := gsub("_backfilled","",mqaid)]
     setkeyv(dat, datkeys)
     NULL
}




calculateTurnover = function(wt){
     
     
     ret_to_get = colnames(wt)
     ret_to_get[!grepl("_backfilled|_index", ret_to_get)] = 
          paste(ret_to_get[!grepl("_backfilled|_index", ret_to_get)],"backfilled", sep = "_")
     
     ret = returnsToXts(ret_to_get)
     colnames(ret) = gsub("_backfilled","",colnames(ret))
     # set weights and returns to same period    
     common_months = getCommonMonths(wt,ret)
     wt = wt[common_months]
     ret = ret[common_months]
     
     portret = calcPortRet(ret, wt, "", T)
     # calculate how much each weight grows
     wt_eom = wt * na.fill(1 + ret, 0)
     # rescale weights so they sum to 1
     # wt_eom = wt_eom/rowSums(abs(wt_eom), na.rm = T)
     wt_eom = wt_eom/(1 + vectorToXtsMatrix(portret, ncol(wt_eom)))
     
     # lag wt_eom, to correspond to same date as start of next month
     wt_eom = lagXts(wt_eom, 1)
     
     # rescale weights so they sum to 1
     # wt = wt/rowSums(abs(wt), na.rm = T)
     # wt = wt/(1 + vectorToXtsMatrix(portret, ncol(wt_eom)))
     
     trading = wt_eom - wt
     
     trading = xts(rowSums(abs(trading), na.rm = T), index(trading))
     
     # define AnnualizationFactor if it doesn't exist
     if(!exists("AnnualizationFactor")) AnnualizationFactor = 12
     return(c("Avg Turnover" = mean(trading) * AnnualizationFactor,
              "Avg # Holdings" = mean(rowSums(abs(na.fill(wt, 0)) > 0.00001))))
}






# rankPosAndNegSep
# takes in a signal, and ranks the positive ones separately and negative separately
# so that most positive has highest positive rank,
# and most negative has the largest negative rank, example largest negative rank is -27 if there
# are 27 negative entries.
rankPosAndNegSep = function(x){
  
  # rank the negatives, so that most negative number gets the largest negative rank
  x[x<0] = -rank(-x[x<0])
  # rank the positives, so that the largest number gets the largest rank
  x[x>0] = rank(x[x>0])
  
  return(x)
}

# rankLongShortSeparatelyWeights
# takes in a signal, and ranks the positive ones separately and negative separately
# so that most positive has highest positive rank,
# and most negative has the largest negative rank, example largest negative rank is -27 if there
# are 27 negative entries.
# Then scales the sum of shorts to shortSum and sum of longs to longSum
# Finally rescales weights to sum of absolute value of 1
# If there is no negative, or no positive entry some months, the weights are all NA
rankLongShortSeparatelyWeights = function(wt, shortSum = -0.5, longSum = 0.5){
  
  wt = na.fill(wt,0)
  
  wt_rescaled = xts(t(apply(wt, 1, function(x){
    
    
    x = rankPosAndNegSep(x)
    
    # rescale the short side to sum to shortSum
    x[x<0] = x[x<0] / sum(x[x<0]) * shortSum
    if( abs(sum(x[x<0]) - shortSum) > DiffTolerance & sum(x[x<0]) != 0) stop("Error in scaling shorts")
    
    if(length(x[x<0]) == 0){
      x[] = NA
      return(x)
    }
    
    # rescale the long side to sum to longSum
    x[x>0] = x[x>0] / sum(x[x>0]) * longSum
    if( abs(sum(x[x>0]) - longSum) > DiffTolerance & sum(x[x>0]) != 0) stop("Error in scaling shorts")
    
    if(length(x[x>0]) == 0){
      x[] = NA
      return(x)
    }
    
    # scale to unlevered fully invested
    x = x/sum(abs(x))
    return(x)
  })), index(wt))
  
  return(wt_rescaled)
}


# adjustWtBySignalWt
# Takes in a list of signal weights wt, and xts wt_adj which is the weight on each signal
# and then multiplies each holding of each signal by the weight of the signal

adjustWtBySignalWt = function(wt, wt_adj){
  
  for(i in names(wt)){
    
    wt_names = colnames(wt[[i]])
    wt[[i]] = wt[[i]] * vectorToXtsMatrix(wt_adj[,i],ncol(wt[[i]]))
    colnames(wt[[i]]) = wt_names
    #   if(any(abs(xts(rowSums(abs(wt[[i]])),index(wt[[i]])) - wt_adj[,i]) > DiffTolerance)){
    #     warning("Error in multiplying holdings weights by portfolio weight")
    #   }
  }
     
     write.csv(data.frame(wt_adj), "wt_adj.csv", quote = F)
  
  return(wt)
}


hasNetting = function(mywt){
  
  netting = matrix(F, nrow = nrow(mywt[[1]]), ncol = length(mywt))
  colnames(netting) = names(mywt)
  
  # loop over all signals up to the next last one
  for(signalA in 1:(length(mywt)-1)){
    
    # loop over all signals, starting from signalA + 1
    for(signalB in (signalA+1):length(mywt)){
      
      # calculate sum of absolute weights for signal A and B separately
      sumAbsWtA = rowSums(abs(mywt[[signalA]]))
      sumAbsWtB = rowSums(abs(mywt[[signalB]]))
      
      # calculate the sum of absolute weights for combined signal A and B
      sumAbsWtAandB = rowSums( abs( combineListWeights( mywt[c(signalA,signalB)]) ) )
      
      # scaling parameter is combined sum of absolute weights / sum of individual abs weights
      scalingParameter = sumAbsWtAandB / (sumAbsWtA + sumAbsWtB)
      
      netting[abs(scalingParameter - 1) > DiffTolerance, names(mywt)[signalA]] = T
      netting[abs(scalingParameter - 1) > DiffTolerance, names(mywt)[signalB]] = T
    }
  }
  
  #   # adjust mywt by the scaling parameters
  #   for(name in names(mywt)){
  #     mywt[[name]] = mywt[[name]] * scalingParameters[,name]
  # #     mywt2 = mywt[[name]] * scalingParameters[,name]
  # #     
  # #     rowMaxs((mywt2/mywt[[name]]),na.rm = T) - 
  # #       rowMins((mywt2/mywt[[name]]),na.rm = T) - scalingParameters[,name]
  #   }
  
  return(netting)
  
}

adjustWtForNetting = function(mywt){
  
  #   Adjusts weights for netting effects, ensuring that each 2 entries of mywt
  #   have the same sum of absolute values as the 2 entires summed individually 
  #   before netting and jointly after netting
  #   Assume we have 10 signals, and 10 weights on those signals.
  #   1.	Line up signals in any order from 1 to 10
  #     a.	Do the following for each signal number i from 1 to 10
  #     i.	Do the following for each signal from j = i + 1
  #   1.	Calculate sum of absolute weights of i and j separately
  #   2.	Combine them, and calculate sum of absolute weights
  #          a.	Sum Abs Weight combined / Sum Abs Weight Both Individually is what I need to divide weights in each signal with to account for netting
  #             ii.	I go from j = i + 1, so that each combination is run only once
  #   
#   
#   scalingParameters = matrix(1, nrow = nrow(mywt[[1]]), ncol = length(mywt))
#   colnames(scalingParameters) = names(mywt)
  
  # loop over all signals up to the next last one
  for(signalA in 1:(length(mywt)-1)){
    
    # loop over all signals, starting from signalA + 1
    for(signalB in (signalA+1):length(mywt)){
      
      # calculate sum of absolute weights for signal A and B separately
      sumAbsWtA = rowSums(abs(mywt[[signalA]]))
      sumAbsWtB = rowSums(abs(mywt[[signalB]]))
      
      # calculate the sum of absolute weights for combined signal A and B
      sumAbsWtAandB = rowSums( abs( combineListWeights( mywt[c(signalA,signalB)]) ) )
      
      # scaling parameter is combined sum of absolute weights / sum of individual abs weights
      scalingParameter = sumAbsWtAandB / (sumAbsWtA + sumAbsWtB)
      
      # scalingParameters[,signalA] =  scalingParameters[,signalA] + ( 1/scalingParameter - 1 )
      # scalingParameters[,signalB] =  scalingParameters[,signalB] + ( 1/scalingParameter - 1 )
      
      # scale each signal up
      mywt[[signalA]] = mywt[[signalA]]/scalingParameter
      mywt[[signalB]] = mywt[[signalB]]/scalingParameter
      
      # error check to ensure the sum of the absolute weights of signal A and B combined
      # equal their individual sum of absolute weights
      # calculate the sum of absolute weights for combined signal A and B
      sumAbsWtAandB = rowSums( abs( combineListWeights( mywt[c(signalA,signalB)]) ) )
      
      # scaling parameter is combined sum of absolute weights / sum of individual abs weights
      scalingParameter = sumAbsWtAandB / (sumAbsWtA + sumAbsWtB)
      
      if( any( abs(scalingParameter - 1) > DiffTolerance ) ){
        stop(paste("Error in scaling between signals",signalA, signalB))
      }
    }
  }
  
#   # adjust mywt by the scaling parameters
#   for(name in names(mywt)){
#     mywt[[name]] = mywt[[name]] * scalingParameters[,name]
# #     mywt2 = mywt[[name]] * scalingParameters[,name]
# #     
# #     rowMaxs((mywt2/mywt[[name]]),na.rm = T) - 
# #       rowMins((mywt2/mywt[[name]]),na.rm = T) - scalingParameters[,name]
#   }
  
  return(mywt)
}



# calcAmbiguity
# Calculates the ambiguity measure, motivated by Augustin and Izhakian (2016)

# I fit a normal distribution to daily returns, using the 5-minute return moments intra-day. 
# I have a different CDF for each day.
# Then, within each month: I average the daily pdfs and construct the resulting average CDF. 
# Then, for each day, I compute the Kolmogorov-Smirnov distance between the one-day CDF 
# and the average CDF, and average the distance within a month. That's my measure, "Amb".


calcAmbiguity = function(dailymean, dailysd, avgmean, avgsd){
  
  return_range = seq(-0.2, 0.2, length.out = 1200)
  
  # calculate daily pdf
  dailypdf = sapply(index(dailymean), function(x){
    diff( pnorm(return_range, dailymean[x], dailysd[x]) )
  })
  
  # calculate average of these pdfs
  averagepdf = rowMeans(dailypdf)
  
  # calculate cds
  dailycdf = apply(dailypdf,2,cumsum)
  averagecdf = cumsum(averagepdf)
  
  
  averagecdf = matrix(averagecdf, length(averagecdf), ncol(dailycdf))
  
  amb = xts(colMaxs( abs(averagecdf - dailycdf) ), index(dailymean))
  return(amb)
}

# calcAmbiguity
# calculates ambiguity, but only using trading days in the month
calcAmbiguity2 = function(myhf){
  
  hf = copy(myhf)
  # turn into monthly results
  hf[, year_mon := as.yearmon(Date)]
  # spyhfada[, year_mon := as.yearmon(Date)]
  
  
  
  # return_range = seq(-0.1, 0.1, length.out = 200)
  return_range = seq(-0.3, 0.3, length.out = 1200)
  # spyhf[Date == as.Date("1998-07-01"), diff(pnorm(return_range, hfmean, hfvol))]
  # spyhf[Date == as.Date("1998-07-01"), diff(pnorm(return_range, hfmean_monthly, hfvol_monthly))]
  
  setkey(hf, year_mon, Date)
  
  
  amb = xts(sapply(hf[, sort(unique(year_mon))],function(mydate){
    # get PDF for each day of month
    dailypdf = sapply(hf[.(mydate), Date], function(x){
      hf[.(mydate,x), diff(pnorm(return_range, hfmean, hfvol))]
    })
    
    averagepdf = rowMeans(dailypdf)
    
    dailycdf = apply(dailypdf,2,cumsum)
    averagecdf = cumsum(averagepdf)
    
    mean(colMaxs( abs(  matrix(averagecdf,length(averagecdf), ncol(dailycdf)) - dailycdf ) ))
  }), hf[, sort(unique(year_mon))])
  
  return(amb)
}


calcAmbiguityFromNonHFData = function(x, numPer = 10, avgNumPer = 13){
     
     if(is.character(x)){
          ret = returnsToXts(x)
     } else {
          ret = x
     }
     
     retmean = na.omit(rollapplyr(ret, numPer, mean))
     retsd = na.omit(rollapplyr(ret, numPer, sd))
     
     retdat = merge(ret, retmean, retsd)
     retdat = na.omit(retdat)
     colnames(retdat) = c("ret","ret_mean","ret_sd")
     
     retdatmean = rollmeanr(retdat, avgNumPer)
     
     permean = retdat[,"ret_mean"]
     persd = retdat[,"ret_sd"]
     avgmean = retdatmean[,"ret_mean"]
     avgsd = retdatmean[,"ret_sd"]
     
     amb = calcAmbiguity(permean, persd, 
                         avgmean, avgsd)
     
     return(amb)
}


# scalingAllAffectedSignalsAfterNetting
# Takes in a list mywt, with each element being a signal, or a combination of signals,
# with xts weight matrix.
# mytargetwt is the target weights of each signal, or combination of signals.
# It checks for each month which signals have netting, by checking difference in sum of
# sum of absolute weights of each signals separately, and comparing to sum after
# combining them together. Ratio of these 2 gives the scaling coefficient, and
# scales them all up proportionally.


scalingAllAffectedSignalsAfterNetting = function(mywt, mytargetwt){
  
  # combine the weights to get the dates we have weigths for
  mywtaftercombining = combineListWeights(mywt)
  
  # Calculate which signals have netting in them each month
  signalsWithNetting = xts(hasNetting(mywt),index(mywtaftercombining))
  
  # loop over dates
  for(mydate in index(mywtaftercombining)){
    
    mydate = as.yearmon(mydate)
    
    # get which portfolios have netting month mydate
    ports_with_netting = names(mywt)[which(signalsWithNetting[mydate,])]
    
    # deal with netting if there is any
    if(length(ports_with_netting) > 0){
      # find what the weight is after netting
      current_wt = sum(abs(combineListWeights(mywt[ports_with_netting])[mydate,]))
      
      # find what the target weight is
      target_wt = sum(abs(mytargetwt[mydate,ports_with_netting]))
      
      expansioncoef = target_wt/current_wt
      
      for(silo in ports_with_netting){
        mywt[[silo]][mydate,] = mywt[[silo]][mydate,] * expansioncoef
      }
    }
    
    
  }
  
  return(mywt)
}



# scalingAllSignalsProportionally
# Takes in a list mywt, with each element being a signal, or a combination of signals,
# with xts weight matrix.
# It combines the weights, calculates sum of absolute value, and scales
# each entry in mywt by 1/sum of absolute value.
# if portfolio is already fully invested, will simply multiply each entry by 1
# if it is not fully invested, will scale to make fully invested


scalingAllSignalsProportionally = function(mywt){
     
     # combine the weights to get the dates we have weigths for
     mywtaftercombining = combineListWeights(mywt)
     
     sumAbsWt = xts(rowSums(abs(mywtaftercombining)), index(mywtaftercombining))

     # loop over dates
     for(signal in names(mywt)){
          
          mywt[[signal]] = 
               mywt[[signal]] / vectorToXtsMatrix(sumAbsWt, ncol(mywt[[signal]]))
     }
     
     return(mywt)
}





scalingSequentialNetting = function(mywt, mysequence){
  
  #   Adjusts weights for netting effects, ensuring that each 2 entries of mywt
  #   have the same sum of absolute values as the 2 entries summed individually 
  #   before netting and jointly after netting
  #   Assume we have 10 signals, and 10 weights on those signals.
  #   1.	Line up signals in any order from 1 to 10
  #     a.	Do the following for each signal number i from 1 to 10
  #     i.	Do the following for each signal from j = i + 1
  #   1.	Calculate sum of absolute weights of i and j separately
  #   2.	Combine them, and calculate sum of absolute weights
  #          a.	Sum Abs Weight combined / Sum Abs Weight Both Individually is what I need to divide weights in each signal with to account for netting
  #             ii.	I go from j = i + 1, so that each combination is run only once
  #   3. Scale both signals up according to scaling factor
  #   4. Do any netting between long and shorts, so we aren't double netting when we do next signal
  #   
  #   
  #   scalingParameters = matrix(1, nrow = nrow(mywt[[1]]), ncol = length(mywt))
  #   colnames(scalingParameters) = names(mywt)
  
#   mywtplot = xts(rowSums(abs( combineListWeights(mywt[mysequence[2]]) )), 
#                  index( combineListWeights(mywt[mysequence[2]]) ))
#   plot(mywtplot, ylim = c(0.2,0.5))
  
  # loop over all signals up to the next last one
  for(signalA in 1:(length(mywt)-1)){
    
    # loop over all signals, starting from signalA + 1
    for(signalB in (signalA+1):length(mywt)){
      
#       mywtplot = xts(rowSums(abs( combineListWeights(mywt[mysequence[2]]) )), 
#                      index( combineListWeights(mywt[mysequence[2]]) ))
#       lines(mywtplot)
      ###############################
      # Calculate scaling parameter #
      ###############################
      
      # calculate sum of absolute weights for signal A and B separately
      sumAbsWtA = rowSums(abs(mywt[[ mysequence[signalA] ]]))
      sumAbsWtB = rowSums(abs(mywt[[ mysequence[signalB] ]]))
      
      # calculate the sum of absolute weights for combined signal A and B
      sumAbsWtAandB = rowSums( abs( combineListWeights( mywt[ c( mysequence[signalA],
                                                                 mysequence[signalB] ) ]) ) )
      
      # scaling parameter is combined sum of absolute weights / sum of individual abs weights
      scalingParameter = sumAbsWtAandB / (sumAbsWtA + sumAbsWtB)
      
      # scalingParameters[,signalA] =  scalingParameters[,signalA] + ( 1/scalingParameter - 1 )
      # scalingParameters[,signalB] =  scalingParameters[,signalB] + ( 1/scalingParameter - 1 )
      
      if(any( abs(scalingParameter - 1) > DiffTolerance)){
        print(paste("Netting happening between", mysequence[signalA],"and",mysequence[signalB]))
      }
      ########################
      # scale each signal up #
      ########################
      
      mywt[[ mysequence[signalA] ]] = mywt[[ mysequence[signalA] ]]/scalingParameter
      mywt[[ mysequence[signalB] ]] = mywt[[ mysequence[signalB] ]]/scalingParameter
      
      ###############
      # Error check #
      ###############
      
      # error check to ensure the sum of the absolute weights of signal A and B combined
      # equal their individual sum of absolute weights
      # calculate the sum of absolute weights for combined signal A and B
      sumAbsWtAandB = rowSums( abs( combineListWeights( mywt[c( mysequence[signalA],
                                                                mysequence[signalB] )]) ) )
      
      # scaling parameter is combined sum of absolute weights / sum of individual abs weights
      scalingParameter = sumAbsWtAandB / (sumAbsWtA + sumAbsWtB)
      
      if( any( abs(scalingParameter - 1) > DiffTolerance ) ){
        stop(paste("Error in scaling between signals",signalA, signalB))
      }
      
      
      #######################################################
      # Net out all shorts in order to avoid double netting #
      #######################################################
      
      # loop over column names in signalA
      for( name in colnames(mywt[[ mysequence[signalA] ]]) )
      {
        
        # only do something if name is in signalB, otherwise there was no netting in that ticker
        if(name %in% colnames(mywt[[ mysequence[signalB] ]]))
        {
          
          # only do something if name is a short in either signalA or signalB
          if( any( mywt[[ mysequence[signalA] ]][,name] < 0 ) |
              any( mywt[[ mysequence[signalB] ]][,name] < 0 ) )
          {
            
            # loop over dates
            for( mydate in index(mywt[[ mysequence[signalA] ]][,name]))
            {
              
              mydate = toIndexFormat(mydate, mywt[[ mysequence[signalA] ]])
              
              # net out only if signs are different
              if( sign( mywt[[ mysequence[signalA] ]][mydate,name] ) !=
                  sign( mywt[[ mysequence[signalB] ]][mydate,name] ) )
              {
                
                
                if( abs(mywt[[ mysequence[signalA] ]][mydate,name]) >=
                    abs(mywt[[ mysequence[signalB] ]][mydate,name]) )
                {
                  # if abs wt size of signalA is larger or equal than abs wt size of signalB
                  # transfer all of signalB wt to signalA, and set signalB wt to 0
                  
                  # transfer all of signalB to signalA
                  mywt[[ mysequence[signalA] ]][mydate,name] = 
                    mywt[[ mysequence[signalA] ]][mydate,name] +
                    mywt[[ mysequence[signalB] ]][mydate,name]
                  
                  # set signalB to 0
                  mywt[[ mysequence[signalB] ]][mydate,name] = 0
                  
                } else 
                {
                  # if abs wt size of signalA is smaller than abs wt size of SignalB
                  # transfer the abs wt size of signalA to B, and keep whats left in B
                  
                  
                  # transfer all of signalA to signalB
                  mywt[[ mysequence[signalB] ]][mydate,name] = 
                    mywt[[ mysequence[signalB] ]][mydate,name] +
                    mywt[[ mysequence[signalA] ]][mydate,name]
                  
                  # set signalA to 0
                  mywt[[ mysequence[signalA] ]][mydate,name] = 0
                }
              }
            }
          }
        }
      }
      
      
    }
  }
  
  #   # adjust mywt by the scaling parameters
  #   for(name in names(mywt)){
  #     mywt[[name]] = mywt[[name]] * scalingParameters[,name]
  # #     mywt2 = mywt[[name]] * scalingParameters[,name]
  # #     
  # #     rowMaxs((mywt2/mywt[[name]]),na.rm = T) - 
  # #       rowMins((mywt2/mywt[[name]]),na.rm = T) - scalingParameters[,name]
  #   }
  
  return(mywt)
}






# toIndexFormat
# Transforms x into the same class as the index of xvar
# Useful when looping over index(xvar), as R will return
# as.numeric of the index, whereas you need the index class
# when subsetting into xvar
toIndexFormat = function(x, xvar){
  
  if(class(index(xvar)) == "yearmon"){
    return( as.yearmon(x) )
  } else if( class( index(xvar) ) == "Date" ){
    return( as.Date(x) )
  } else {
    stop("Support only yearmon and Date date classes")
  }
}









# createAttributionWeights
# Takes in a list of weights, where the name of each entry
# is the signal name it came from, and the entry in the list
# is an xts matrix with weights.
# Will Transform the weights into long format, with signal name
# added to it, write the results to file with attribution_weights.csv
# name, and return the weights.

createAttributionWeights = function(mywt, addTicker = T){
  
  mywt = lapply(names(mywt), function(x){
    res = xtsToDat(mywt[[x]], x)
  })
  
  mywt = rbindlist(mywt)
  setkey(mywt, year_mon, mqaid, type)
  
  mywt = mywt[value != 0]
  
  if(addTicker){
    mywt[, ticker := mqaidToTicker(mqaid)]
    mywt = mywt[,.(year_mon, ticker, mqaid, value, type)]
  }
  write.csv(mywt, "attribution_weights.csv", row.names = F, quote = F)
  
  return(mywt)
}


createAttributionWeightsWithAllScaledPorportionally = function(mywt, addTicker = T){
     
     # Need to calculate scaling factor, and multiply each holding by it
     myportwt = combineListWeights(mywt)
     myscalingfactor = xts(1/rowSums(abs(myportwt)), index(myportwt))
     
     # scale up holdings

     mywt2 = lapply(names(mywt), function(x){
          tempres = mywt[[x]] * vectorToXtsMatrix(myscalingfactor, ncol(mywt[[x]]))
          colnames(tempres) = colnames(mywt[[x]])
          return(tempres)
     })
     names(mywt2) = names(mywt)
     
     # error check to ensure scaling is correct
     myportwt2 = combineListWeights(mywt2)
     myscalingfactor2 = xts(1/rowSums(abs(myportwt2)), index(myportwt2))
     
     checkDifference(myscalingfactor2, 1, "createAttributionWeightsWithAllScaledPorportionally: Abs weight don't all sum up to 1 after scaling everything up proportionally")
     
     # done with error check
     
     mywt = mywt2
     
     mywt = lapply(names(mywt), function(x){
          res = xtsToDat(mywt[[x]], x)
     })
     
     mywt = rbindlist(mywt)
     setkey(mywt, year_mon, mqaid, type)
     
     mywt = mywt[value != 0]
     
     if(addTicker){
          mywt[, ticker := mqaidToTicker(mqaid)]
          mywt = mywt[,.(year_mon, ticker, mqaid, value, type)]
     }
     write.csv(mywt, "attribution_weights.csv", row.names = F, quote = F)
     
     return(mywt)
}


# compareToAttributionWeights
# Compares portfolio weights to results from attribution_weights
# attribution_weights keeps all the weights from the signals, so we can track what each
# signal contributes to the portfolio weight

compareToAttributionWeights = function(myportwt){
     
     if( !file.exists("attribution_weights.csv" ) ){
          warning("compareToAttributionWeights error: attribution_weights.csv doesn't exist. Can't compare portfolio weights to it")
     } else {
          attrbwt = fread("attribution_weights.csv")
          
          # need to calculate net weights for each symbol
          attrbwt[, year_mon := as.yearmon(year_mon)]
          
          attrbwt[, value := sum(value), keyby = .(year_mon, mqaid)]
          
          # if there are 2 entries, for mqaid year_mon, it will save both
          # need to keep only unique entries
          
          attrbwt[, type := NULL]
          attrbwt = unique(attrbwt, by = NULL)
          
          attrbwt = datToXts(attrbwt)
          attrbwt = na.fill(attrbwt, 0)
          
          
          # remove backfilled from the weight names
          colnames(myportwt) = gsub("_backfilled","", colnames(myportwt))
          
          # ensure we have the same holdings
          if( length(setdiff2(colnames(attrbwt), colnames(myportwt))) != 0 ){
               warning("compareToAttributionWeights error: have differnt holdings")
               return(NULL)
          }
          
          # set to same column setup
          attrbwt = attrbwt[,colnames(myportwt)]
          
          holdingsdiff = as.numeric(attrbwt - myportwt)
          
          
          if( any(abs(holdingsdiff) > DiffTolerance) ){
               stop("compareToAttributionWeights error: Attribution weights don't match portfolio weights")
          } else {
               print("attribution weights match portfolio weight")
          }
     }
     
     return(NULL)
     
}



createNetAttributionWeights = function(mywt, addTicker = T){
     
     mywt = lapply(names(mywt), function(x){
          res = xtsToDat(mywt[[x]], x)
     })
     
     mywt = rbindlist(mywt)
     setkey(mywt, year_mon, mqaid, type)
     
     mywt = mywt[value != 0]
     
     # find which signal has the largest absolute weight
     mywt[, abs_value := abs(value)]
     mywt[, max_abs_value := max(abs_value), by = .(mqaid, year_mon)]
     
     # find which type the largest absolute value belongs to
     mywt[, max_type := ifelse(abs_value == max_abs_value, type,NA)]
     
     # calculate net weight
     mywt[, net_value := sum(value), by = .(mqaid, year_mon)]
     
     # keep only those types that have the largest absolute value, the net_value
     # will have the net weight
     mywt = mywt[!is.na(max_type)]
     mywt[, value := NULL]
     mywt[, abs_value := NULL]
     mywt[, max_abs_value := NULL]
     mywt[, type := NULL]
     
     setnames(mywt, "max_type","type")
     setnames(mywt, "net_value","value")
     
     if(addTicker){
          mywt[, ticker := mqaidToTicker(mqaid)]
          mywt = mywt[,.(year_mon, ticker, mqaid, value, type)]
     }
     
     # # test code to see if the value of each signal is same as in alloc file
     # test = mywt
     # test = test[, sum(abs(value)), keyby = .(type, year_mon)]
     # test = datToXts(test, "type","year_mon","V1")
     # test = round(test,2)
     
     write.csv(mywt, "net_attribution_weights.csv", row.names = F, quote = F)
     
     return(mywt)
}

# adjustLongOnlyAttributionWeights
# Gets in datatable that is results of attribution_weights.csv, created by
# createAttributionWeights(wt) call.
# Returns a datatable, with all excess short positions replaced with
# a long in the inverse ETF. Excess short positions are those that
# net out in a net short, need to net the long position fully with
# the short position, and then add an entry with the net short being
# at the inverse ETF
# 
adjustLongOnlyAttributionWeights = function(wt, longSymbol){
  
  mywt = copy(wt)
  # get net position
  mywt[, net_value := sum(value), by = .(year_mon, mqaid)]
  mywt[, inverse_value := 0]
  
  # find short entries
  net_short_entries = mywt[net_value < 0, .(year_mon, mqaid, value)]
  
  # keep only short entries
  net_short_entries = net_short_entries[value < 0 ]
  
  
  # will look up mywt with the year_mon mqaid and value combinations 
  # that lead to net short position, need the value part to be able to
  # isolate the short position, as a year_mon mqaid will likely have a long
  # entry as well
  setkey(mywt, year_mon, mqaid, value)
  
  
  # loop over the net short entries
  for(i in 1:nrow(net_short_entries)){
    
#     if(net_short_entries[i,year_mon == as.yearmon("Nov 2014")]){
#       
#       
#       erask
#     }
#     if(net_short_entries[i,mqaid == "xXLF" & year_mon == as.yearmon("Mar 2008")]){
#       kasdfas
#     }

    
#     netvalue >= value
#     value = -5
#     net_value = -3
#     invvalue = -5 --3 = -2
#     value = value - invvalue
#     
#     
#     value = -3
#     netvalue = -5
#     netvalue < value
#     invvalue = value
#     value = 0
#     
    if(mywt[net_short_entries[i], net_value > value]){
      # if value >= net_value and we have a short, it must mean there
      # are multiple shorts that month
      # set the value to 0, and recalculate the net_value, so that
      # i don't use stale information for next entry
      
      # save the value to be used for inverse ETF
      mywt[net_short_entries[i], inverse_value := net_value]
      
      # set value to 0
      mywt[net_short_entries[i], value := value - net_value]
      
    } else {
      mywt[net_short_entries[i], inverse_value := value]
      mywt[net_short_entries[i], value := 0]
    }

    
    # update net value
    mywt[, net_value := sum(value), by = .(year_mon, mqaid)]

    
    # add an entry with the inverse etf and the positive of net value as weight
    setkey(mywt, year_mon, mqaid, value)
    
    tempadd = copy(mywt[net_short_entries[i,.(year_mon, mqaid)]])
    tempadd = tempadd[inverse_value != 0]
    

    
    for(j in 1:nrow(tempadd)){
      
      new_tempadd = copy(tempadd[j])
      # set the mqaid and ticker of the add entry
      if(is.data.table(longSymbol)){
        new_tempadd[, mqaid := tickerToMqaid(longSymbol[new_tempadd[,mqaid], short_ETF])]
      } else {
        new_tempadd[, mqaid := longSymbol]
      }
      new_tempadd[, ticker := mqaidToTicker(mqaid)]
      
      # set the value of the add entry
      new_tempadd[, value := abs(inverse_value)]
      
      # set inverse_value to 0 so we don't recount it
      new_tempadd[, inverse_value := 0]
      # reset the inverse_value of the old entry
      mywt[net_short_entries[i,.(year_mon, mqaid)], inverse_value := 0]
      # add add entry to mywt
      mywt = rbindlist(list(mywt, new_tempadd))
      
      # reset the key as we adjusted mywt
      setkey(mywt, year_mon, mqaid, value)
      
      rm(new_tempadd)
    }
    
    
    
  }
  
  # need to aggregate all the newly added add entries
  mywt[, value := sum(value), by = .(year_mon, ticker, type)]
  setkey(mywt, year_mon, mqaid, type)
  mywt = unique(mywt)
  
  # remove the net_value column
  mywt[, net_value := NULL]
  mywt[, inverse_value := NULL]
  
  return(mywt)
}


# createLongOnlyAttributionWeights
# Transforms long short attribution weights into long only attribution weights
# where net shorts have been replaced with longSymbol, either a single mqaid
# with inverse ETF, or data.table with inverse ETF map

createLongOnlyAttributionWeights = function(lsAttrbFileLocation, longSymbol, myLongWt){
  
  # adjust attribution weights
  attrwt = fread(lsAttrbFileLocation)
  attrwt[, mqaid := adjustMqaid(mqaid)]
  attrwt[, year_mon := as.yearmon(year_mon)]
  
  attrwtl = adjustLongOnlyAttributionWeights(attrwt, longSymbol)
  # write to file
  write.csv( data.frame(attrwtl), "attribution_weights.csv", row.names = F)
  attrwtl_signals = copy(attrwtl)
  
  attrwtl = attrwtl[, sum(value), keyby = .(year_mon, mqaid)]
  setnames(attrwtl,"V1","weight")
  
  
  
  # error checks
  attrwtl = datToXts(attrwtl,"mqaid","year_mon","weight")
  attrwtl = na.fill(attrwtl,0)
  # 
  # res = sapply(colnames(myLongWt),function(x){
  #   c(max(myLongWt[,x] - attrwtl[,x] ), min(myLongWt[,x] - attrwtl[,x]))
  # })
  # hist(res[1,])
  # 
  # test = merge(myLongWt[,"x74347R50"], attrwtl[,"x74347R50"])
  # test[,2] - test[,1]
  # 
  # t(round(res,6))
  
  if( length(setdiff2(colnames(myLongWt), colnames(attrwtl))) != 0 ){
    stop("error in attribution weights")
  }
  
  attrwtl = attrwtl[,colnames(myLongWt)]
  
  
  ret = returnsToXts(paste(colnames(myLongWt),"backfilled", sep = "_"))
  colnames(ret) = gsub("_backfilled","", colnames(ret))
  
  if( any( abs(calcPortRet(ret,myLongWt,"",T) - calcPortRet(ret,attrwtl,"",T)) > DiffTolerance ) ){
    stop("error in attribution")
  }
  
  return( list("xts" = attrwtl,"signals" = attrwtl_signals) )

}

# setdiff2
# Checks both ways setdiff
# setdiff(x,y), only looks at what's in x and not in y
# setdiff2(x,y) looks both ways

setdiff2 = function(x,y){
  c(setdiff(x,y), setdiff(y,x))
}



# gets intraday mean and volatility from the tradestation setup
getHFVolMeanTS = function(fileLocation, returnXts = F, vixData = F){
  #### High frequency, SPY 5 min intraday volatility
  hf = fread(fileLocation)
  # hf = fread("P:/RWork/55 Capital/R/Volcapture Portfolio/volatility term structure/Leonid's implementation/spy5mindata.txt")
  
  if(vixData){
       # keep only 9:35 and onward
       # times starting in 11:20:00 pm have 2 digits for hour
       # whereas times starting in 3:45:00 pm have 1 digit
       # time_offset will be 1 in 11 case and 0 in 3 case
       # will use it to add to the substr start and/or end points
       hf[, time_offset := nchar(V2) - 10]
       
       hf[, hour := substr(V2, 1, 1 + time_offset)]
       
       hf[, minute := substr(V2, 3 + time_offset, 4 + time_offset)]
       hf[, period := substr(V2, 9 + time_offset, 10 + time_offset)]
       
       # test that the time subsetting is correct
       hf[, V2a := paste0(hour,":",minute, ":00 ", period)]
       
       hf[, if(any(V2 != V2a)) stop("Error in decomposing time")]
       
       setnames(hf,"V1","Date")
       setnames(hf,"V2","Time")
       setnames(hf,"V3","Close")
       
       # remove AM periods before 9 am
       hf[, hour := ifelse(period == "PM" & hour != 12, as.numeric(hour) + 12, as.numeric(hour))]
       
       hf = hf[ !(period == "AM" & hour < 9) ]
       
       hf = hf[ !(hour == 9 & minute < 35) ]
       # add 0 in front of hour
       hf[, hour := as.character(hour)]
       
       hf[, hour := ifelse(nchar(hour) == 1, paste0("0",hour), hour)]
       
       hf[, Time := paste0(hour, ":", minute)]
       
  }
  # keep relevant columns
  hf = hf[,.(Date, Time, Close)]
  hf[, Date := as.Date(Date, format = "%m/%d/%Y")]
  setkey(hf, Date, Time)
  
  hf[, Close_l1d := if(length(Close) > 1){
    c(NA_real_,Close[1:(length(Close)-1)])
  } else {
    NA_real_
  }, by = Date]
  
  hf = na.omit(hf)
  
  # calculate log returns
  hf[, ret := log(Close/Close_l1d)]
  
  toDaily = 77
  # calcualte daily std and mean
  hf = hf[, list("hfvol" = sqrt(var(ret) * toDaily), "hfmean" = mean(ret) * toDaily), keyby = Date]
  
  if(returnXts){
    hf = xts(hf[,-1, with = F], hf[,Date])
  }
  return(hf)
}



# getDownsideAdjustment
# Adjusts statistics upwards according to an exponential formula

getDownsideAdjustment = function(x){
  sharpe_range = matrix( c(0.5,2))
  mult = matrix(c(log(1),log(1.5)))
  # colnames(mult) = "adjustment"
  res = lm(mult ~ sharpe_range)
  
  adjustseq = matrix(seq(0.5, 10, 0.01))
  
  adjustment = res$coef[1] + res$coef[2] * adjustseq
  adjustment = exp(adjustment)
  rownames(adjustment) = adjustseq
  
  
  return(sapply(x,function(nx){
    if(round(nx,2) %in% rownames(adjustment)){
      adjustment[as.character(round(nx,2)),1]
    } else {
      1
    }
  }))
  # ifelse(round(x,2) %in% rownames(adjustment), adjustment[as.character(round(x,2)),1], 1)
  # # plot(adjustseq, adjustment, xlab = "Sharpe", ylab = "Downside Adjustment", main = "Backtesting Downside Adjustment")
  # return(adjustment[as.character(round(x,2)),1])
}





# getSignalAlphaTree
# gets monthly alpha's from each signal and its subsignals
getSignalAlphaTree = function(sigName, 
                              signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_",
                              callingName = NA, level = 1, minQuantileLength = 12,
                              date_start = NULL, date_end = NULL){

  # sigName = "ALL_DYNAMIC_GLOBAL_MACRO"
  # signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
  # callingName = NA
  # minQuantileLength = 12
  # level = 1

  # print(paste("calling",sigName,"from",callingName))
  
     # read in returns, keep alpha, and setup and return results
    if ( file.exists(paste0(signalLocation,sigName,"/D/returns.csv")) ) {
          ret = read.csv(paste0(signalLocation,sigName,"/D/returns.csv"))
          ret = xts(ret[,-1], as.yearmon(ret[,1]))
          ret = ret[,c("backfilled","benchmark")]
          ret = na.omit(ret)
          colnames(ret) = c(tolower(sigName),"benchmark")
          ret = merge(ret, ret[,tolower(sigName)] - ret[,"benchmark"])
          colnames(ret)[ncol(ret)] = "alpha"
          if (file.exists(paste0(signalLocation, sigName,"/D/summary.csv") )) {
            sumtemp = read.csv(paste0(signalLocation, sigName,"/D/summary.csv"))
            bmkname = names(sumtemp)[3]
          } else {
            bmkname = colnames(ret)[2]
          }
     } else if( file.exists(paste0(signalLocation,sigName,"/returns.csv")) ){
          ret = read.csv(paste0(signalLocation,sigName,"/returns.csv"))
          ret = xts(ret[,-1], as.yearmon(ret[,1]))
          bmkname = colnames(ret)[2]
     } else {
          stop("Missing returns.csv file")
     }
     
  
  if(!is.null(date_start)){
       if(!class(date_start) %in% c("yearmon","Date")) stop("date_start needs to have a valid date format")
       
       ret = ret[index(ret) >= date_start]
  }
  
  
  if(!is.null(date_end)){
       if(!class(date_end) %in% c("yearmon","Date")) stop("date_end needs to have a valid date format")
       
       ret = ret[index(ret) <= date_end]
  }
  
  
  
  #bmkname = colnames(ret)[2]
  # ret = ret[,"alpha"]
  # colnames(ret)[1] = sigName
  
  retquant = ret
  retquant[] = NA
  
  if(length(ret) >= (minQuantileLength + 1)){
       for(mycol in 1:ncol(ret)){
            for(i in ((minQuantileLength + 1):nrow(ret))){
                 retquant[i, mycol] = ecdf(as.numeric(ret[1:(i-1), mycol]))(as.numeric(ret[i, mycol]))
       }

    }
  }
  
  res = data.table("Parent_Signal" = ifelse(is.na(callingName),sigName,callingName),
                   "Sub_Signal" = sigName,
                   "Date" = index(ret), 
                   "Return" = as.numeric(ret[,1]),
                   "Return_Pctile" = as.numeric(retquant[,1]),
                   "Benchmark_Return" = as.numeric(ret[,2]),
                   "Alpha" = as.numeric(ret[,3]),
                   "Alpha_Pctile" = as.numeric(retquant[,3]),
                   "Bmk_Name" = bmkname, 
                   "Signal_Level" = level
  )
  
  
  if(file.exists(paste0(signalLocation,sigName,"/alloc_", sigName,".csv"))){
    
    # if there exists an alloc file, we need to continue going on level deeper
    
    alloc = read.csv(paste0(signalLocation,sigName,"/alloc_", sigName,".csv"), stringsAsFactors = F)
    
         subres = lapply(alloc[,"strategy"],function(x){
      getSignalAlphaTree(x, signalLocation, sigName, level + 1, minQuantileLength,
                         date_start, date_end)
    })
    
    # combine all subresults together
    subres = rbindlist(subres)
    
    # combine current results with subresults
    res = rbindlist(list(res, subres))
  }
  
  return(res)
  
}





# getSignalReturnTree
# gets monthly returns's and alphas from each signal and its subsignals,
# along with default wt and current wt. Default wt is the weight without any timing indicator.
getSignalReturnTree = function(sigName, 
                              signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_",
                              signalWt = 1, callingName = NA, level = 1, minQuantileLength = 12,
                              date_start = NULL, date_end = NULL,
                              alloc = NULL, weightInCalling = NULL, timingWeightInCalling = NULL,
                              fees = NULL){
     
     # sigName = "EQUITIES_US"
     # signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
     # signalWt = 1
     # callingName = NA
     # level = 1
     # minQuantileLength = 12
     # date_start = as.yearmon("Apr 2004")
     # date_end = as.yearmon("Jun 2016")
     # alloc = NULL
     # weightInCalling = NULL
     # timingWeightInCalling = NULL
     
     # print(paste("calling",sigName,"from",callingName))
     
     # read in returns, keep alpha, and setup and return results
     
     # if(sigName == "EQUITIES_US_TRUE_BETA"){
     #      print("test")
     # }
     if (file.exists( paste0(signalLocation, sigName,"/D/returns.csv") )) {
          ret = read.csv(paste0(signalLocation, sigName,"/D/returns.csv"))
          ret = xts(ret[,c("backfilled","benchmark")], as.yearmon(ret[,"year_mon"]))
          last = index(ret)[length(index(ret))]
          if (last ==  date_end) {
              for (i in names(ret)) {
                 if (is.na(ret[last,i])) {
                    ret[last,i] = 0
                 }
              }
          }
          ret = merge(ret, ret[,"backfilled"] - ret[,"benchmark"])
          colnames(ret)[3] = "alpha"
          if (file.exists(paste0(signalLocation, sigName,"/D/summary.csv") )) {
            sumtemp = read.csv(paste0(signalLocation, sigName,"/D/summary.csv"))
            bmkname = names(sumtemp)[3]
          } else {
            bmkname = colnames(ret)[2]
          }
     } else if(file.exists(paste0(signalLocation,sigName,"/returns.csv"))) {
          ret = read.csv(paste0(signalLocation,sigName,"/returns.csv"))
          ret = xts(ret[,-1], as.yearmon(ret[,1]))
          bmkname = colnames(ret)[2]
     } else {
          stop( paste(sigName,"missing returns.csv file"))
     }
     
     colnames(ret)[2:ncol(ret)] = c("benchmark", "alpha")
     
     
     if(!is.null(date_start)){
          if(!class(date_start) %in% c("yearmon","Date")) stop("date_start needs to have a valid date format")
          
          ret = ret[index(ret) >= date_start]
     } else {
          date_start = index(ret)[1]
     }
     
     if(!is.null(date_end)){
          if(!class(date_end) %in% c("yearmon","Date")) stop("date_end needs to have a valid date format")
          
          if(index(ret)[nrow(ret)] < date_end){
               stop(paste(as.character(date_end),"isn't available in",sigName,"returns"))
          }
          ret = ret[index(ret) <= date_end]
     } else {
          date_end = index(ret)[nrow(ret)]
     }

     if (is.null(fees)) {
        fees = xts(rep(0,length(index(ret))),index(ret))
     } else if (class(fees)[1] != "xts") {
        fees = xts(rep(as.numeric(fees),length(index(ret))),index(ret))
     } else {
        fees = fees[index(ret),1]
     }
     
     # subtract fees
     if(!is.null(weightInCalling)){
          # need to scale fees according to signalWt/weightInCalling
          # because the weightInCalling, coming from attribution weights
          # sums to above 1, so when we calculate contribution as ret * weight
          # we are multiplying the fees part by a number above 1, and attribution won't match
          
          scalingfee = (timingWeightInCalling/weightInCalling)
          
          # if attrbwt is 0, then scalingbmk will be Inf, need to replace with 1
          scalingfee[!is.finite(scalingfee)] = 1
          
          if(any(scalingfee > (1+DiffTolerance)))stop("getSignalReturnTree: Fee scaling parameter should never be above 1")
          
          
          ret[index(scalingfee),1] = ret[index(scalingfee),1] + fees[index(scalingfee),1] * scalingfe
          ret[index(scalingfee),"alpha"] = ret[index(scalingfee),"alpha"] + fees[index(scalingfee),1] * scalingfe
     } else {
          ret[,1] = ret[,1] + fees[,1]
          ret[,"alpha"] = ret[,"alpha"] + fees[,1]
     }
     
     
     res = data.table("parent_signal" = ifelse(is.na(callingName),sigName,callingName),
                      "signal" = sigName,
                      "date" = index(ret), 
                      "return" = (as.numeric(ret[,1])),
                      "benchmark" = (as.numeric(ret[,2])),
                      "signal_ret_alpha" = (as.numeric(ret[,3])),
                      "benchmark_name" = bmkname, 
                      "signal_wt" = signalWt,
                      "signal_level" = level,
                      "signal_current_wt" = if(!is.null(weightInCalling)) {as.numeric(weightInCalling[index(ret)])} else { 
                           if(!is.null(timingWeightInCalling)) {as.numeric(timingWeightInCalling[index(ret)])} else { rep(signalWt, nrow(ret))}},
                      "signal_timing_wt" = if(is.null(timingWeightInCalling)) {rep(signalWt, nrow(ret))} else {as.numeric(timingWeightInCalling[index(ret)])}
                      
     )
     
     
     # If we haven't given a specific alloc file, then it will look at the 
     # current folder alloc file, and recursively search through it until there is none
     if(!is.null(alloc) | 
        (is.null(alloc) & 
         file.exists(paste0(signalLocation,sigName,"/alloc_", sigName,".csv")))){
          
          
          
          print(signalLocation)
          timingwt = createFileWeights(signalLocation, sigName, alloc,"wt_adj.csv")
          timingwt = timingwt[index(ret)]
          
          attrbwt = createFileWeights(signalLocation, sigName, alloc,"attribution_weights.csv")
          attrbwt = attrbwt[index(ret)]  
          
          if ((is.null(alloc)) & (file.exists(paste0(signalLocation,sigName,"/alloc_", sigName,".csv")))) {
               # if there exists an alloc file, we need to continue going on level deeper
               alloc = read.csv(paste0(signalLocation,sigName,"/alloc_", sigName,".csv"), stringsAsFactors = F)
               
          }
          
          

          
          subres = lapply(as.character(alloc[,"strategy"]),function(x){
               
               getSignalReturnTree(x, signalLocation, signalWt = alloc[alloc[,"strategy"] == x,"lweight"], 
                                   callingName = sigName, level = level + 1, minQuantileLength = minQuantileLength,
                                   date_start = date_start, date_end = date_end, 
                                   weightInCalling = if((!is.null(attrbwt)) & (x %in% colnames(attrbwt))) {attrbwt[,x]} else { 
                                        if((!is.null(timingwt)) & (x %in% colnames(timingwt))) {timingwt[,x]} else { xts(rep(alloc[alloc[,"strategy"] == x,"lweight"], nrow(ret)), index(ret))}},
                                   timingWeightInCalling = if(!is.null(timingwt)) {timingwt[,x]} else { xts(rep(alloc[alloc[,"strategy"] == x,"lweight"], nrow(ret)), index(ret))},
                                   fees = fees)
          })
          
          # combine all subresults together
          subres = rbindlist(subres, use.names = T)
          
          
          # combine current results with subresults
          res = rbindlist(list(res, subres), use.names = T)
          
     }
          
     
     return(res)
     
}

# createFileWeights
# Reads in from weights file in the TRADING/SIGNAL_.... folders
# Either wt_adj, timing weights, or attribution_weights, and returns them

# mySignalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
# mySigName = "EQUITIES_US"
# my_alloc = NULL
# wtName = "attribution_weights.csv"
createFileWeights = function(mySignalLocation, mySigName, my_alloc, wtName){
     # check if wt_adj exists, if it exists, then the current weight and default weight will differ
     if( file.exists(paste0(mySignalLocation,mySigName,"/",wtName)) ){
          mycurrwt = read.csv(paste0(mySignalLocation,mySigName,"/",wtName), stringsAsFactors = F, check.names = F)
          
          if(wtName == "attribution_weights.csv") {
               mycurrwt = data.table(mycurrwt)
               mycurrwt[, year_mon := as.yearmon(year_mon)]
               
               # Need to include the timing element
               # Signal imps are constructed assuming no timing element
               # signal files might include timing element
               # If they include timing, then a wt_adj is written to file
               # which has the timing component
               # If there is timing involved, then need to multiply the signal imp
               # weights by the sign of the timing signal
               if(file.exists(paste0(mySignalLocation,mySigName,"/wt_adj.csv"))){
                    wt_adj = read.csv(paste0(mySignalLocation,mySigName,"/wt_adj.csv"))
                    wt_adj = xts(wt_adj[,-1], as.yearmon(wt_adj[,1]))
               } else {
                    wt_adj = NULL
               }
               
               # Error check to ensure the attribution_weights match the signal imp weights
               # on the ETF level
               # Note, this only compares the % distribution of weights within a signal,
               # because we scale by rowSums(abs(wt))
               # doesn't check the overall magnitude of it in the calling signal
               #
               # in the signal imps
               
               setkey(mycurrwt, type, year_mon)
               
               for(i in unique(mycurrwt[,type])){
                    print(i)
                    tempwt = na.fill(datToXts(mycurrwt[i]),0)
                    
                    # scale up to 100% weight
                    tempwt = tempwt/rowSums(abs(tempwt))
                    
                    
                    # read in the signal imp
                    sigwt = signalImpToXts(paste0(mySignalLocation,i,"/signal_IMP_M.csv"))
                    
                    # add timing signal component
                    if(!is.null(wt_adj)){
                         
                         # need to multiply signal imp weights with wt_adj to incorporate timing
                         # if we have timing value set at 0, or negative
                         sigwt = sigwt * sign(vectorToXtsMatrix(wt_adj[,i], ncol(sigwt)))
                         
                         # # This error check below is faulty. Example EMN_EM_FLOWS, wt_adj
                         # # will always show positive exposure to it, but the net exposure of it is 0.
                         # # error check that sign of net position in wt_adj and attribution weights 
                         # # is the same
                         # signtest = merge(sign(wt_adj[,i]), xts(rowSums(tempwt), index(tempwt)), all = T)
                         # signtest = na.fill(signtest, 0)
                         # signtest = sign(signtest)
                         # checkDifference(signtest[,1], signtest[,2], 
                         #                 paste("calcCtrb error: sign of net position in wt_adj and attribution weights is not the same for", i))
                    }
                    
                    # print(paste("******Comparing",i, "from",mySigName,"attribution weights with signal imp"))
                    
                    compareWeights(tempwt, sigwt, i, myWarningOnly=T)
               }
               
               # done with error check
               
               # get the sum of abs weights
               mycurrwt[, abs_value := abs(value)]
               
               # # get if signal is net long or short
               # mycurrwt[, net_position := sign(sum(value)), keyby = .(year_mon, type)]
               # # if net position is 0, then net_position will show 0, as sign of 0 is 0
               # # need to replace 0 with 1, as multiplying with 0 will cancel our any values in the
               # # signal weight calculations. Replacing 0 with 1 will have no effect on signal weight calcultion
               # # we effectively only care about finding when net_positions are -1, as then we need to adjust
               # # the signal weight by multiplying by -1
               # mycurrwt[, net_position := ifelse(net_position == 0, 1, net_position)]
               # 
               # # when calcualte signal weight, need to multiply the sum(abs_value) with the signal net_position
               # # otherwise, you will get a positive weight in months where you are net short
               # mycurrwt = mycurrwt[, sum(abs_value), keyby = .(year_mon, type, net_position)]
               # mycurrwt[, V1 := V1 * net_position]
               mycurrwt = mycurrwt[, sum(abs_value), keyby = .(year_mon, type)]
               mycurrwt = na.fill(datToXts(mycurrwt, "type","year_mon","V1"), 0)
          } else {
               mycurrwtnames = colnames(mycurrwt)[-1]
               mycurrwt = xts(mycurrwt[,-1], as.yearmon(mycurrwt[,1]))
               colnames(mycurrwt) = mycurrwtnames
          }
          
          # i = "FACTORS_US_MOMENTUM"
          # test = merge(wt_adj[,i], mycurrwt[,i])
          # checkDifference(abs(test[,1]), abs(test[,2]))
          # 
          # xts(toPct(abs(test[,1]) - abs(test[,2]),6), index(test))
          # 
          # xts(toPct((test[,1]) - (test[,2]),6), index(test))
          # 
          if(!is.null(my_alloc)){
               # if the my_alloc file has been manually inputted, so it is not NULL
               # then the my_alloc file looks different from the one in the signal folder
               # This is relevant for dynamic macro, where we aggregate bond portfolio
               # for the attribution, but the signal file has it disaggregated
               # Need to look at the my_alloc files for each of the sub signals in the custom
               # my_alloc file, and create a map between the sub signals in the custom my_alloc file
               # and the signals in the custom my_alloc file  
               
               sigSubSigMap = lapply(as.character(my_alloc[,"strategy"]), function(x){
                    mapmy_allocfile = read.csv(paste0(mySignalLocation,x,"/alloc_",x,".csv"), stringsAsFactors = F)
                    
                    return(mapmy_allocfile[,"strategy"])
                    # return(data.frame("mySigName" = rep(x, nrow(mapmy_allocfile)),
                    # "submySigName" = mapmy_allocfile[,"strategy"], stringsAsFactors = F))
               })
               
               names(sigSubSigMap) = as.character(my_alloc[,"strategy"])
               
               tempmycurrwt = xts( matrix(rep(NA, length(sigSubSigMap) * nrow(mycurrwt)), ncol = length(sigSubSigMap)),
                                   index(mycurrwt))
               colnames(tempmycurrwt) = names(sigSubSigMap)
               
               for(i in names(sigSubSigMap)){
                    
                    if(i %in% colnames(mycurrwt)){
                         # if the name is currently in the wt_adj
                         tempmycurrwt[,i] = mycurrwt[,i]
                    } else {
                         # this is where the my_alloc file has single signal
                         # but the implementation has the sub signal instead of single parent signal
                         tempmycurrwt[,i] = xts(rowSums(mycurrwt[,sigSubSigMap[[i]]]), index(mycurrwt))
                    }
                    
               }
               
               checkDifference(rowSums(tempmycurrwt), 1, "createFileWeights error: Manual creation of current weights from custom my_alloc don't sum to 1 all months")
               
               mycurrwt = tempmycurrwt
          }
          
     } else {
          mycurrwt = NULL
     }
     
     return(mycurrwt)
}



# getSignalWeightTree
# For a signal, gets the weights and lagged 1 month weights, calculates trading in the month
# and ranks it. Then for each sub signal, does the same thing recursively and returns.
getSignalWeightTree = function(sigName, 
                               signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_",
                               signalWt = 1, callingName = NA, level = 1, minQuantileLength = 12,
                               date_start = NULL, date_end = NULL,
                               alloc = NULL, weightInCalling = NULL, timingWeightInCalling = NULL,
                               fees = 0){
     
     
     # sigName = "ALL_DYNAMIC_GLOBAL_MACRO"
     # signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
     # signalLocation = "S:/Quant/qsf_etf/marketing/trading/SIGNAL_"
     # signalWt = 1
     # callingName = NA
     # level = 1
     # date_start = as.yearmon("Apr 2004")
     # date_end = as.yearmon("Jun 2016")
     # alloc = NULL
     # weightInCalling = NULL
     # timingWeightInCalling = NULL
     
# if(sigName == "TREASURIES_US_DURATION"){
#      print("arrived")
# }
     # print(paste("calling",sigName,"from",callingName))
     
     # read in weights
     
     if(file.exists(paste0(signalLocation,sigName,"/signal_IMP_M.csv"))){
          
          wt = fread(paste0(signalLocation,sigName,"/signal_IMP_M.csv"))
          wt[, mqaid := as.character(mqaid)]
          wt = wt[mqaid != ""]
          
          # weight column has absolute weight, need to multiply it by signal to get real weight
          wt[, weight := weight * signal]
          
          wt[, ticker := mqaidToTicker(mqaid)]
          wt[, year_mon := as.yearmon(MonthnToYearmon[wt[,monthnumber], yearmon])]
          
          wt = na.fill(datToXts(wt,"ticker", "year_mon","weight"),0)
          
          mytimeperiod = index(wt)
          # need to multiply wt by the sign of the weights in the calling signal
          # as the trading folder convention is that timing signal is in the parent signal
          if(!is.null(timingWeightInCalling)){

               if(class(timingWeightInCalling)[1] == "xts"){
                    wt = wt * vectorToXtsMatrix(sign(timingWeightInCalling), ncol(wt))
               } else {

                    #asef
                    wt = wt * sign(timingWeightInCalling)
               }

          }

          if( any(rowSums(abs(wt)) == 0) ){
               wt2 = wt
               wt2 = wt2[rowSums(abs(wt2)) != 0,]
               
               checkDifference(rowSums(abs(wt2)), 1, paste("getSignalWeightTree error:", sigName, "signal_IMP_M.csv absolute weights don't sum to 1"))
               
          } else {
               checkDifference(rowSums(abs(wt)), 1, paste("getSignalWeightTree error:", sigName, "signal_IMP_M.csv absolute weights don't sum to 1"))
          }
          
          lagwt = lagXts(wt, 1)
          
          wt = xtsToDat(wt, "weight")
          
  
          lagwt = xtsToDat(lagwt, "weight_l1m")
          
          setnames(wt,"mqaid","ticker")
          setnames(lagwt,"mqaid","ticker")
          
          setnames(wt, "value", "weight")
          setnames(lagwt,"value","weight_l1m")
          
          wt[, type := NULL]
          lagwt[, type := NULL]
          
          # set key
          setkey(wt, ticker, year_mon)
          setkey(lagwt, ticker, year_mon)
          
          # merge together
          
          wt = lagwt[wt]
          
          # weights_l1m will have NA for the first month
          # need to remove it
          
          #wt = wt[year_mon != min(year_mon)]
          #wt = wt[year_mon == min(year_mon), weight_l1m := 0]
          wt = wt[is.na(weight_l1m), weight_l1m := 0]
          
          if(any(is.na(wt))){
               stop("getSignalWeightTree error: unexpected outcome. Shouldn't be any NA's.")
          }
          
          wt[, weight_change := weight - weight_l1m]
          wt[, abs_weight_change := abs(weight_change)]
          
          # calculate the rank of absolute weight change
          # 1 will be the largest, N will be the smallest
          # This way I can filter on top X absolute weight changes
          
          wt[, rank_abs_weight_change := frankv(abs_weight_change, order = -1), by = year_mon]
          # if changes match, they will have the average rank, so 14 and 15 will show up as 14.5
          # will round down so that I don't miss them when asking for top 14
          wt[, rank_abs_weight_change := floor(rank_abs_weight_change)]
          
          wt[, change_direction := ifelse(weight_change < 0, "Sell", ifelse(weight_change > 0, "Buy",""))]
          
          
     } else {
          stop( paste(sigName,"missing signal_IMP_M.csv file"))
     }
     
     if(!is.null(date_start)){
          if(!class(date_start) %in% c("yearmon","Date")) stop("date_start needs to have a valid date format")
          
          wt = wt[year_mon >= date_start]
     } else {
          date_start = wt[,min(year_mon)]
     }
     
     
     if(!is.null(date_end)){
          if(!class(date_end) %in% c("yearmon","Date")) stop("date_end needs to have a valid date format")
          
          if(wt[,max(year_mon)] < date_end){
               if (!(sigName %in% c("EMN_STEALTH","BONDS_MUNI", "EMN_VOL_VXX", "EMN_VOL_XIV", "EMN_VOL_TS", "EMN_VOL_MRI"))) {
                 stop(paste(as.character(date_end),"isn't available in",sigName,"signal_IMP_M.csv"))
               }
          }
          wt = wt[year_mon <= date_end]
     } else {
          date_end = wt[,max(year_mon)]
     }
     
     # set weights to same time period
     weightInCalling = weightInCalling[index(weightInCalling) >= date_start & index(weightInCalling) <= date_end]
     timingWeightInCalling = timingWeightInCalling[index(timingWeightInCalling) >= date_start & index(timingWeightInCalling) <= date_end]
     
     res = copy(wt)
     
     res[, parent_signal := ifelse(is.na(callingName),sigName,callingName)]
     res[, signal := sigName]
     
     res[,signal_wt := signalWt]
     res[, signal_level := level]
     
     
     if(!is.null(weightInCalling)) {
          weightInCalling = data.table("year_mon" = index(weightInCalling),
                                       "signal_current_wt" = as.numeric(weightInCalling))
          setkey(weightInCalling, year_mon)
          setkey(res, year_mon, ticker)
          res = weightInCalling[res]
   
     } else if(!is.null(timingWeightInCalling)){
          weightInCalling = data.table("year_mon" = index(timingWeightInCalling),
                                       "signal_current_wt" = as.numeric(timingWeightInCalling))
          
          setkey(weightInCalling, year_mon)
          setkey(res, year_mon, ticker)
          res = weightInCalling[res]
     } else {
          res[, signal_current_wt := signalWt]
     }
     
     
     if(!is.null(timingWeightInCalling)){
          timingWeightInCalling = data.table("year_mon" = index(timingWeightInCalling),
                                       "signal_timing_wt" = as.numeric(timingWeightInCalling))
          
          setkey(timingWeightInCalling, year_mon)
          setkey(res, year_mon, ticker)
          res = timingWeightInCalling[res]
     } else {
          res[, signal_timing_wt := signalWt]
     }
     
     # end node is a boolean that stores if there exists an alloc file in the folder or not
     # if there is no alloc file, then we've reached the end of a portfolio, and no further sub signal exists
     res[, end_node := if(file.exists(paste0(signalLocation,sigName,"/alloc_", sigName,".csv"))) {F} else {T}]
     
     # If we haven't given a specific alloc file, then it will look at the 
     # current folder alloc file, and recursively search through it until there is none
     if(!is.null(alloc) | 
        (is.null(alloc) & 
         file.exists(paste0(signalLocation,sigName,"/alloc_", sigName,".csv")))){
          
          timingwt = createFileWeights(signalLocation, sigName, alloc,"wt_adj.csv")

          if (!is.null(timingwt)) {
              if( any(!(mytimeperiod %in% index(timingwt))) ){
                   stop(paste("getSignalWeightTree error:",mytimeperiod[!(mytimeperiod %in% index(timingwt))],
                              "is not in",sigName,"wt_adj.csv", "and we are trying to run analysis up to",as.character(date_end)))
              }
              
              timingwt = timingwt[mytimeperiod]
          }



          attrbwt = createFileWeights(signalLocation, sigName, alloc,"attribution_weights.csv")
          
          #if (is.null(attrbwt)) {stop("getSignalWightTree error: Did not find attribution_weights for a signal that has an alloc file.")}
          if (!is.null(attrbwt)) {
              if( any(!(mytimeperiod %in% index(attrbwt))) ){
                   stop(paste("getSignalWeightTree error:",mytimeperiod[!(mytimeperiod %in% index(attrbwt))],
                              "is not in",sigName,"attribution_weights.csv", "and we are trying to run analysis up to",as.character(date_end)))

          }}
          
          attrbwt = attrbwt[mytimeperiod]
          
          if(is.null(alloc)){
               # if there exists an alloc file, we need to continue going on level deeper
               alloc = read.csv(paste0(signalLocation,sigName,"/alloc_", sigName,".csv"), stringsAsFactors = F)
               
          }
          
          
          
          
          subres = lapply(as.character(alloc[,"strategy"]),function(x){
               getSignalWeightTree(x, 
                                   signalLocation,
                                   signalWt = alloc[alloc[,"strategy"] == x,"lweight"], 
                                   callingName = sigName, level = level + 1, minQuantileLength = minQuantileLength,
                                   date_start = date_start, date_end = date_end,
                                   weightInCalling = if(!is.null(attrbwt)) {attrbwt[,x]} else { 
                                        if(!is.null(timingwt)) {timingwt[,x]} else { xts(rep(alloc[alloc[,"strategy"] == x,"lweight"], length(mytimeperiod)), mytimeperiod)}},
                                   timingWeightInCalling = if(!is.null(timingwt)) {timingwt[,x]} else { xts(rep(alloc[alloc[,"strategy"] == x,"lweight"], length(mytimeperiod)), mytimeperiod)},
                                   fees = fees)
          })
          
          # combine all subresults together
          subres = rbindlist(subres, use.names = T)
          
          
          # combine current results with subresults
          res = rbindlist(list(res, subres), use.names = T)
          
     }
     
     
     return(res)
     
}

# formatSignalWtAttribution
# Formats results from getSignalWeightTree
formatSignalWtAttribution = function(myres, keepTopX = 5, reportMonth){
     
     if(class(reportMonth) != "yearmon"){
          stop("formatSignalWtAttribution error: reportMonth needs to be in yearmon format.")
     }
     
     res = copy(myres)
     
     # keep only report month
     res = res[year_mon == reportMonth]
     
     # keep only top x weight changes
     res = res[rank_abs_weight_change <= keepTopX]
     setkey(res, signal, rank_abs_weight_change)
     
     
     res = res[,.(signal, ticker, year_mon, weight, weight_l1m, weight_change,change_direction)]
     
     res = res[weight_change != 0]
     res[, year_mon := NULL]
     
     # format results nicely
     weightRoundCoef = 2
     res[, weight := toPct(weight, weightRoundCoef)]
     res[, weight_l1m := toPct(weight_l1m, weightRoundCoef)]
     res[, weight_change := toPct(weight_change, weightRoundCoef)]
     
     resToRemove = res[is.na(portfolioNameMap[signal, name]),unique(signal)]
     
     if(length(resToRemove) > 0){
          warning(paste("Removing following signals"))
          warning(resToRemove) 
     }

     
     res = res[!(signal %in% resToRemove)]
     res[, signal := portfolioNameMap[signal, name]]
     
     setnames(res, "signal","Signal Name")
     setnames(res, "ticker","Ticker")
     setnames(res, "weight", paste("Weight in", reportMonth))     
     setnames(res, "weight_l1m", paste("Weight in", reportMonth - 1/12))
     setnames(res, "weight_change","Change")
     setnames(res, "change_direction","Trade Direction")
     
     
     # set to data frame and remove signal names that are repeated
     res = data.frame(res, stringsAsFactors = F, check.names = F)
     
     # add empty line after each signal ends
     # and then line for column names
     for(i in unique(res[,"Signal Name"])){
          if(i != unique(res[,"Signal Name"])[1]){
               newres = rbind(newres,
                              rep("",ncol(newres)),
                              colnames(newres),
                              res[res[,"Signal Name"] == i,])
          } else {
               newres = res[res[,"Signal Name"] == i,]
          }
     }
     
     res = newres
     
     rownamesToRemove = rep(F, nrow(res))
     
     for(i in 2:nrow(res)){
          if(res[i, "Signal Name"] == res[i-1, "Signal Name"]){
               rownamesToRemove[i] = T
          }
     }
     
     res[rownamesToRemove,"Signal Name"] = ""
     
     # Add an empty row before each signal start
     
     
     return(res)
     
}

# doSignalAttribution
# Performs attribution on a signal, by looking up the alpha of each sub signals, 
# and the signal itself.
# Recursive function, taking advantage of the structure of the TRADING folder.
doSignalAttribution = function(mySigName, 
                               mySignalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_",
                               myCallingName = NA, maxSignalLevel = 4){
  
  # mySigName = "ALL_DYNAMIC_GLOBAL_MACRO"
  # mySignalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
  # myCallingName = NA
  # maxSignalLevel = 4
  
  
  alphatree = getSignalAlphaTree( mySigName, mySignalLocation, myCallingName)
  setkeyv(alphatree, c("Date", "Signal_Level","Parent_Signal", "Alpha"))
  
  # set max granularity
  alphatree = alphatree[Signal_Level <= maxSignalLevel]
  
  return(alphatree)
}

addToErrorLog = function(errorMessage = "", myErrorLogFile = errorLogFile){
     write.table(errorMessage, myErrorLogFile, append = T, sep = ",", col.names = F, row.names = F)
}


# netSPYAndSH
# Nets out SPY and SH.
# SPY + SH = 0
# SPY - SH is the net SPY position.
# Nets these 2, taking in attribution weight long output.

netSPYAndSH = function(myattrbwtsig){
  
  myattrbwtsignew = copy(myattrbwtsig)
  wtlist = list()
  
  for(i in myattrbwtsignew[,unique(type)]){
    
    tempwt = na.fill( datToXts(myattrbwtsignew[i]), 0 )
    
    # need to merge with a full time period XTS to ensure we have all dates
    # merge with NA xts for entire time period, to get all months
    # thenr emove that NA xts, and fill NA with 0
    mydates = myattrbwtsignew[,seq(min(year_mon),max(year_mon), 1/12)]
    mydates = xts(rep(NA, length(mydates)), as.yearmon(mydates))
    
    tempwt = merge(mydates, tempwt)
    tempwt = tempwt[,-1]
    tempwt = na.fill(tempwt, 0)
    
    # There are 2 scenarios
    # We have SPY and SH both in the signal
    #   Set SPY = SPY - SH
    #     Any long position in SH gets netted against long position in SPY
    #     And anything that isn't netted against a long adds a short position
    #     in SPY, Long SH is equivalent to short SPY
    # We have SH but not SPY in the signal
    #   Set SH = -SH
    #   Change SH name to SPY
    #     Turn a long position in SH to a short position in SPY
    
    
    
    if( all( c( tickerToMqaid("spy"), tickerToMqaid("sh") ) %in% colnames(tempwt) ) ){
      # We have SPY and SH both in the signal
      #   Set SPY = SPY - SH
      #     Any long position in SH gets netted against long position in SPY
      #     And anything that isn't netted against a long adds a short position
      #     in SPY, Long SH is equivalent to short SPY
      
      
      
      # save the sum of the weights each month
      # as we need to rescale to this sum
      sumtempwtold = rowSums(abs(tempwt))
      
      
      
      # save spy and sh values before to compare difference of them before and after
      # should be same before and after
      spyold = tempwt[,tickerToMqaid("spy")]
      shold = tempwt[,tickerToMqaid("sh")]
      
      tempwt[,tickerToMqaid("spy")] = tempwt[,tickerToMqaid("spy")] - tempwt[,tickerToMqaid("sh")]
      tempwt[,tickerToMqaid("sh")] = 0
      
      # error check to ensure difference of SPY and SH is same before and after
      checkDifference( tempwt[,tickerToMqaid("spy")] - tempwt[,tickerToMqaid("sh")],
                       spyold - shold ) 
      
      
      
      
      # calculate the sum of abs weights each month after netting
      sumtempwtnew = rowSums(abs(tempwt))
      
      # error check, sum of abs weight should always be equal or lower to what it
      # was before
      if( any( (sumtempwtnew - sumtempwtold) > DiffTolerance ) ){
        stop("Error in netting SPY and SH")
      }
      
      # rescale weights to the absolute sum they had before
      tempwt = (tempwt/sumtempwtnew) * sumtempwtold
      
      # error check that sum of abs tempwt are the same before and after scaling
      checkDifference(rowSums(abs(tempwt)), sumtempwtold, "Error in netting SPY and SH. Sum of abs tempwt is not same before and after scaling")
      
      # remove SH columns
      if( any( tempwt[,tickerToMqaid("sh")] != 0 ) ){
        stop("SH should have all 0 but doesn't")
      }
      
      
      tempwt = tempwt[,setdiff(colnames(tempwt), tickerToMqaid("sh"))]
      
      if( any( abs(rowSums(abs(tempwt)) - sumtempwtold) > DiffTolerance ) ){
        stop("Sum of abs weights not equal to before netting SPY and SH")
      }
      
      
    } else if( tickerToMqaid("sh") %in% colnames(tempwt) ){
      
      # We have SH but not SPY in the signal
      #   Set SH = -SH
      #   Change SH name to SPY
      #     Turn a long position in SH to a short position in SPY
      
      tempwt[, tickerToMqaid("sh")] = -tempwt[, tickerToMqaid("sh")]
      colnames(tempwt)[colnames(tempwt) == tickerToMqaid("sh")] = tickerToMqaid("spy")
      
    }
    
    wtlist[[i]] = tempwt
  }
  
  return(wtlist)
  
}




netSpyAndShScaleAffectedSignals = function(myattrbwt, mywt, myLsSignalLocation){
  myattrbwtsig = myattrbwt$signals
  setkey(myattrbwtsig, type)
  
  myattrbwt = myattrbwt$xts
  
  # error check to ensure long only attribution weights and 
  # long only weights have same ETFs 
  if( length( setdiff2( colnames(myattrbwt), colnames(mywt) ) ) != 0 ){
    stop("Attribution weights and weights have different column names")
  }
  
  # error check to ensure they have the same ETF order
  if( any(colnames(mywt) != colnames(myattrbwt)) ){
    stop("Attribution weights and weights don't have same column  setup")
  }
  
  # error check to ensure the weights are equal
  if( any( abs(mywt - myattrbwt) > DiffTolerance ) ){
    stop("Attribution long only weights don't match long only weights")
  }
  
  
  
  
  #########################################################
  # Net out SPY and SH, and scale up only affected siloes #
  #########################################################
  
  # Effectively net out SPY and SH in each silo, and leave only a short SPY position
  # so SH are eliminated. Then net the SPY positions.
  # I return short SPY positions, and no SH, so will need to create long only weights again.
  
  
  wtlist = netSPYAndSH(myattrbwtsig)
  
  wt_adj = read.csv(paste0(myLsSignalLocation,"wt_adj.csv"))
  wt_adj = xts(wt_adj[,-1], as.yearmon(wt_adj[,1]))
  
  
  mywt = scalingAllAffectedSignalsAfterNetting(wtlist, wt_adj)
  
  
  
  
  mywt = combineListWeights(mywt)
  # portwt2 = combineListWeights(wtlist)
  # 
  # 
  # test = merge(xts(rowSums(abs(wtlist[["ABS_RETURN_PORTFOLIO"]])),index(wtlist[["ABS_RETURN_PORTFOLIO"]])) +
  #         xts(rowSums(abs(wtlist[["CREDIT_US_CREDIT_RISK_SPY"]])),index(wtlist[["CREDIT_US_CREDIT_RISK_SPY"]])) +
  #           xts(rowSums(abs(wtlist[["EQUITIES_ACWI"]])),index(wtlist[["EQUITIES_ACWI"]]))   ,
  #       xts(rowSums(abs(wt_adj[,c("ABS_RETURN_PORTFOLIO","CREDIT_US_CREDIT_RISK_SPY","EQUITIES_ACWI")])), index(wt_adj)))
  # colnames(test) = c("bef","Af")
  # # 
  # # 
  # rowSums(abs(portwt2))
  return(mywt)
}




netSpyAndShScaleSpecificSignals = function(myattrbwtsig, signalToScale ){
  
  myattrbwtsignew = copy(myattrbwtsig)
  
  wtlist = netSPYAndSH(myattrbwtsignew)
  
  # calculate scaling factor
  scalingFactor = 1 - rowSums(abs(combineListWeights(wtlist)))
  
  counter = 1
  
  while(any(scalingFactor > DiffTolerance)){
    print(counter)
    # calculate scaling factor
    scalingFactor = 1 - rowSums(abs(combineListWeights(wtlist)))
    
    # signalToScale = c("ABS_RETURN_PORTFOLIO","EQUITIES_ACWI")
    # signalToScale = c("ABS_RETURN_PORTFOLIO")
    # scale desired signal
    signalScaling = sapply(signalToScale, function(name){
      rowSums(abs(wtlist[[name]]))
    })
    
    # calculate the % distribution of the scalingFactor to each signalToScale
    signalPctScaling = signalScaling/rowSums(signalScaling)
    
    # calculate the scaling of each signal
    signalScaling = signalPctScaling * scalingFactor
    
    for(i in signalToScale){
      
      # calculate signal size
      signalSize = rowSums(abs(wtlist[[i]]))
      
      # scale it to sum to 100%
      # need to fill NA with 0, as if signalSize is 0 some months
      # it will create NA
      wtlist[[i]] = na.fill(wtlist[[i]] / signalSize, 0)

      # scale it to sum to scalingFactor + signalScaling
      wtlist[[i]] = wtlist[[i]] * (signalScaling[,i] + signalSize)

    }
    # signalScaling = rowSums(abs(wtlist[[signalToScale]]))
    # 
    # # scale it to sum to 100%
    # wtlist[[signalToScale]] = wtlist[[signalToScale]] / signalScaling
    # 
    # # scale it to sum to scalingFactor + signalScaling
    # wtlist[[signalToScale]] = wtlist[[signalToScale]] * (signalScaling + scalingFactor)
    # 
    # # this can create additional netting now, so need to repeat
    # 
    counter = counter + 1
  }
  
  wt = combineListWeights(wtlist)
  
  # apply(wt,2,function(x){mean(x[x<0])})
  
  # attrbwt going into netSpyAndShScaleAffectedSignals have all shorts exactly matched with longs
  # by rescaling the affected signal, the exact balance between longs and shorts has been disturbed
  # and the portfolio might have net shorts. Need to replace shorts with SH.
  
  # apply(wt, 2, function(x){toPct(na.fill(min(x[x<0]),0))})
  # need to create long only weights again
  wt = createLongOnlyWeights(wt, replaceShortsWithLong = T, tickerToMqaid("sh"))#shortList)
  
  # creating long only weights again has created long SH positions, that could now be netter against
  # any possible SPY position
  # there are small residual SPY positions left, that I can now net out directly
  
  
  # Net out SPY and SH
  # Subtract SH from SPY, and set SH to 0.
  # any negative SPY weight, needs to be moved to SH and set to 0 in SPY
  # any positive SPY weights are still kept in SPY
  
  spyold = wt[,tickerToMqaid("spy")]
  shold = wt[,tickerToMqaid("sh")]
  
  wt[,tickerToMqaid("spy")] = wt[,tickerToMqaid("spy")] - wt[,tickerToMqaid("sh")]
  wt[,tickerToMqaid("sh")] = 0
  
  # find months with short spy position
  shortSPYMonths = wt[,tickerToMqaid("spy")] < 0
  
  # move short SPY positions to being long SH
  wt[ shortSPYMonths , tickerToMqaid("sh") ]  = -wt[ shortSPYMonths , tickerToMqaid("spy") ]
  
  # set short SPY positions to 0
  wt[ shortSPYMonths , tickerToMqaid("spy") ]  = 0
  
  ########################
  # Netting error checks #
  ########################
  
  # Error check to ensure the difference between SPY and SH is the same before and after
  # SPY - SH is the net SPY position, has to be the same before and after netting
  checkDifference(wt[,tickerToMqaid("spy")] - wt[,tickerToMqaid("sh")], spyold - shold)
  
  # Error check to ensure that anytime there is a long SPY position, we don't have a position in SHY.
  longSPYMonths = wt[,tickerToMqaid("spy")] > 0
  
  if( any( abs(wt[ longSPYMonths, tickerToMqaid("sh")]) > DiffTolerance ) ){
    stop("Still have a long SPY and long SH")
  }
  
  # Error check to ensure there are no shorts left 
  if( any( wt < -DiffTolerance ) ){
    stop("We still have shorts in what is supposed to be a long only portfolio")
  }
  
  
  # Need to scale up weights after we have netted SPY and SH
  # Will scale everything proportionally
  
  plot(xts(1-rowSums(abs(wt)), index(wt)), main = "Dynamic: Amount of Netting Between SPY and SH")
  
  wt = wt/rowSums(abs(wt))
  
  return(wt)
}




# findDrawdownPer
# Takes in price series, and drawdown threshold (negative number)
# and finds start, end dates, and max DD of each drawdown period.
# Define the end of the drawdown as the period of when the loss was the largest.
# Keep looking for a new drawdown once a drawdown has ended.
# keeps only drawdowns above some threshold.

findDrawdownPer = function(ret = ret, ddthres = -0.05){
  
  if(ddthres > 0){
    stop("Drawdown threshold is currently positive. Needs to be set as negative. -5% Drawdown should be entered as -0.05")
  }
  
  dd = ret
  dd[] = 0
  
  
  # pre allocate ddlist, can't be longer than the nrows of cumret
  ddlist = data.frame(matrix(rep(NA, 3 * nrow(ret)), ncol = 3))
  colnames(ddlist) = c("Start","End","Max DD")
  
  ddlistentry = 1
  
  
  current_month = 1
  
  # look over all months
  # calculate drawdowns, find next drawdown, the start, the end
  # the max DD, save it in ddlist, and then continue from the end of the drawdown
  while( current_month <= nrow(ret) ){
    # print(current_month)
    cumret = cumprod(1+ret[current_month:length(ret)])
    
    # add value in front starting at 1, so if the first month is negative
    # we catch that as a drawdown
    cumret = rbind(xts(1, if(class(index(cumret)) == "yearmon"){
      index(cumret)[1] - 1/12
    } else if(class(index(cumret)) == "Date"){
      index(cumret)[1] - 1
    } else {
      stop("support only Date and yearmon")
    }), cumret)
    
    cummaxcumret = cummax(cumret)
    
    dd = cumret/cummaxcumret - 1
    
    dd = dd[-1]
    ddper = dd < 0
    
    
    for(i in 1:length(ddper)){
      # print(i)
     
      if(i == 1){
        if( as.logical(ddper[i]) ){
          # if we are at first month, and we have a drawdown, we also have a start of a drawdown
          
          ddlist[ddlistentry,"Start"] = as.character(index(ddper)[i])
        }
      } else {
        if( as.logical(ddper[i]) & !as.logical(ddper[i-1]) ){
          # If dd is true this period but was false previous period, we have a start of a drawdown
          
          ddlist[ddlistentry,"Start"] = as.character(index(ddper)[i])
          
        } else if( !as.logical(ddper[i]) & as.logical(ddper[i-1]) ){
          # If dd is false this period but was true previous period, 
          # we have an end of a drawdown
          # Need to stop the loop, and update current_month to be the
          # end of the drawdown month
          
          
          # update current_month to be end of the drawdown month
          ddend = which(index(ret) == setToDate(ddlist[ddlistentry,"End"], dd))
          current_month = ifelse( current_month == ddend, current_month + 1, ddend + 1)

          # augment ddlistentry so we know that we should move on to next row
          ddlistentry = ddlistentry + 1
          
          # stop the loop
          break()
          
          
        }
        
      }
      
      # if dd is true this period, check if max DD is higher than the current entry
      if( as.logical(ddper[i]) ){
        # update max DD to be the current drawdown
        
        # if the current drawdown is larger than the entry, update the entry, otherwise keep it
        if(dd[i] < na.fill(ddlist[ddlistentry, "Max DD"],0)){
          
          ddlist[ddlistentry,"Max DD"] = dd[i]
          
          ddlist[ddlistentry,"End"] = as.character(index(ddper)[i])

        } 
        
        
        
      }
      
      
    }
    
    # if we finished the i loop, that means we are still in a drawdown that 
    # hasn't ended and are at the end of the data, so need to stop the while loop 
    if(i == length(ddper)){
      break()
    }
  }
  

  # remove the unused ddlist entries
  ddlist = ddlist[rowSums(is.na(ddlist)) !=  ncol(ddlist),]

  # keep only drawdowns that are above our threshold
  ddlist = ddlist[ddlist[,"Max DD"] <= ddthres,]
  
  return(ddlist)
}


# signalImpToXts
# Takes in signal imp file location, and transforms it into 
# an xts weight object, with mqaid column names adjusted
# Option to return mqaid or ticker in the colum names
signalImpToXts = function(fileLocation, returnMqaid = T){
  
  loadPackages("data.table")
  
  wt = fread(fileLocation)
  wt[, weight := weight * signal]
  wt[, year_mon := as.yearmon(MonthnToYearmon[wt[,monthnumber],yearmon])]
  wt[, monthnumber := NULL]
  wt[, return := NULL]
  wt[, mqaid := adjustMqaid(mqaid)]
  wt[, ticker := mqaidToTicker(mqaid)]
  
  setnames(wt,"weight","value")
  
  wt = datToXts(wt, ifelse(returnMqaid,"mqaid","ticker"))
  wt = na.fill(wt,0)
  

  return(wt)
}


# fromPct
# Transforms a number in % form, 5.3%, to numeric 0.053
# Convenient to use with results from toPct, if we want to go back to numeric
fromPct = function(x){
  as.numeric(gsub("%","",x))/100
}


# loadCsvWithDates
# Loads csv and creates an xts object with Date class
loadCsvWithDates = function(url_obj, dateFormat = "%Y-%m-%d", dateColName = "date"){
     
     
     loadPackages(c("data.table","xts"))
     
     tdat = fread(url_obj)
     tdat[,eval(dateColName) := as.Date(get(dateColName), format = dateFormat)]
     
     tdat = xts(tdat[,setdiff(colnames(tdat), dateColName), with = F], tdat[,get(dateColName)])
     
     return(tdat)
}


###########################################################################################################
## loadCsvYearmon takes a file whose first col is a yearmon with headers being etf tickers and converts it
## into a xts object it returns
############################################################################################################
loadCsvYearmon =  function(url_obj)
{
     Obj_xts = read.csv(url_obj, header = T,sep = ",", stringsAsFactors = FALSE, strip.white = TRUE)
     Date_yrMon = as.yearmon(Obj_xts[,1])
     Obj_xts = Obj_xts[,-1]
     Obj_xts = xts(Obj_xts , (Date_yrMon))
     
     return(Obj_xts)
}





loadPackages = function(x){
     for(i in x){
          if(!require(i, character.only = T, quietly = T)) {
               install.packages(i)
               print(paste("Installed package",i))
               require(i)
          }
     }
}



# add1RowToXts
# Adds a row to xts variable, either at beginning or end with content decided by user
# Assumes a yearmon index, and won't work with Date class.
add1RowToXts = function(contentExtraRow = NA, modelXts = obj_xts, addAtBeginning = F )
{
     
     if(addAtBeginning){
          extraRow_xts = xts(matrix(data = contentExtraRow, nrow  = 1 , ncol =  ncol(modelXts)), as.yearmon(min(index(modelXts))-1/12))
          colnames(extraRow_xts) = colnames(modelXts)
          
          modelXts = rbind(extraRow_xts,modelXts)  
     } else {
          
          extraRow_xts = xts(matrix(data = contentExtraRow, nrow  = 1 , ncol =  ncol(modelXts)), as.yearmon(max(index(modelXts))+1/12))
          colnames(extraRow_xts) = colnames(modelXts)
          
          modelXts = rbind(modelXts,extraRow_xts)   
     }
     
     return(modelXts)
}




# SubsetDates_xts
# Subsets Xts, Zoo, or similar objects between start and end date, inclusive of both.
# Supports yearmon and Date classes as the index class.

SubsetDates_xts = function(Object_xts,start_dt,end_dt)
{

     if( class(index(Object_xts)) == "yearmon"){
          Object_xts = Object_xts[index(Object_xts) >= as.yearmon(start_dt) & index(Object_xts) <= as.yearmon(end_dt)]
     } else if( class(index(Object_xts)) == "Date"){
          Object_xts = Object_xts[index(Object_xts) >= as.Date(start_dt) & index(Object_xts) <= as.Date(end_dt)]
     } else {
          stop("Support only Date and yearmon")
     }
     
     return(Object_xts)
}




###################################################################################################
## # ReturnsToXts and subsets with dates
###################################################################################################

returnsToXts_subset = function(ETF_Ticker, start_dt, end_dt)
{
     return(SubsetDates_xts(returnsToXts(ETF_Ticker), start_dt, end_dt) )
}



###################################################################################################
## ## Below ft  will return a specific nbr of decimals  
###################################################################################################

specify_decimal <- function(x, k) {format(round(x, k), nsmall=k)}







do3PartAttributionIncorrectFramework = function(ret, retBmk, retNoAlts, retNoTilts, retNoRiskMgmt,
                              doNetReturns = doNetReturns, doMarketing = doMarketing)
{
     
     # Input error check
     if(ncol(ret) != 1) stop("ret has more than 1 column")
     if(ncol(retBmk) != 1) stop("retBmk has more than 1 column")

     

     # Value add is made up of
     # Factor tilts
     # Adding alternatives
     # Managing risk
     
     
     # Need to transform into additive process
     # Will evaluate value loss from marginally removing each, that value loss will be
     # its value add. Then sum up all value adds, and calculate each's % contribution.
     # This ignores any interaction effects
     
     
     # Set all series to same period
     
     common_months = Reduce(intersect, list(index(ret),
                                            index(retBmk),
                                            index(retNoAlts),
                                            index(retNoTilts), 
                                            index(retNoRiskMgmt)))
     
     common_months = setToDate(common_months, ret)
     
     ret = ret[common_months]
     retBmk = retBmk[common_months]
     retNoAlts = retNoAlts[common_months]
     retNoTilts = retNoTilts[common_months]
     retNoRiskMgmt = retNoRiskMgmt[common_months]
     
     
     if(!is.null(retNoAlts)){
          # no alts
          retNoAltsres =  calcSummaryStats2(retNoAlts,
                                            retBmk, colnames(retBmk),  increaseDownsideSkipFirst = 0, 
                                            netReturns = doNetReturns,
                                            marketing = doMarketing)  
     }

     
     if(!is.null(retNoTilts)){
          # no tilts
          retNoTiltsres =  calcSummaryStats2(retNoTilts,
                                             retBmk, colnames(retBmk),  increaseDownsideSkipFirst = 0, 
                                             netReturns = doNetReturns,
                                             marketing = doMarketing)
     }

     
     if(!is.null(retNoRiskMgmt)){
          # no riskmgmt
          retNoRiskMgmtres =  calcSummaryStats2(retNoRiskMgmt,
                                                retBmk, colnames(retBmk),  increaseDownsideSkipFirst = 0, 
                                                netReturns = doNetReturns,
                                                marketing = doMarketing) 
     }

     
     # 
     # valueAddMonthly = ret[,c("60/40",colnames(ret))]
     # valueAddMonthly = calcNetReturns(valueAddMonthly)
     # 
     # valueAddMonthly = merge(valueAddMonthly,
     #                                 calcNetReturns(retNoTilts),
     #                                 calcNetReturns(retNoAlts))
     # colnames(valueAddMonthly) = c("60/40",colnames(ret), "Managing Risk","Adding Alternatives")
     # 
     # valueAddMonthly = na.omit(valueAddMonthly)
     # 
     # valueAddMonthly[,"Managing Risk"] = valueAddMonthly[,colnames(ret)] - valueAddMonthly[,"Managing Risk"]
     # valueAddMonthly[,"Adding Alternatives"] = valueAddMonthly[,colnames(ret)] - valueAddMonthly[,"Adding Alternatives"]
     # 
     # valueAddMonthlyTotal = rowSums(valueAddMonthly[,c("Managing Risk","Adding Alternatives")])
     # 
     # valueAddMonthly[,"Managing Risk"] = valueAddMonthly[,"Managing Risk"] / valueAddMonthlyTotal
     # valueAddMonthly[,"Adding Alternatives"] = valueAddMonthly[,"Adding Alternatives"] / valueAddMonthlyTotal
     # 
     # # should sum up to 1
     # checkDifference(rowSums(valueAddMonthly[,c("Managing Risk","Adding Alternatives")]),
     #                 1)
     # 
     # valueAddMonthly[,"Managing Risk"] = (valueAddMonthly[,colnames(ret)] -
     #                     valueAddMonthly[,"60/40"]) * valueAddMonthly[,"Managing Risk"]
     # 
     # valueAddMonthly[,"Adding Alternatives"] = (valueAddMonthly[,colnames(ret)] -
     #                                                   valueAddMonthly[,"60/40"]) * valueAddMonthly[,"Adding Alternatives"]
     
     
     
     # setup results
     
     numEntries = 5
     
     valueAdd = data.frame("Mean" = rep(NA, numEntries), 
                           "Sharpe" = rep(NA, numEntries),
                           "Max DD" = rep(NA, numEntries), check.names = F)
     rownames(valueAdd) = c(colnames(retBmk),"Managing Risk","Adding Alternatives","Factor Tilts","Total")
     
     
     
     pctColumns = c("Mean","Max DD")
     nonPctColumns = "Sharpe"
     
     colNames = c( pctColumns[1], nonPctColumns[1],pctColumns[2])
     
     
     RoundCoef = 3
     
     fullret = na.omit(merge(retBmk, ret))
     colnames(fullret) = c(colnames(retBmk), colnames(ret))
     
     
     fullprodres = calcSummaryStats2(fullret,
                                     retBmk, colnames(retBmk),  increaseDownsideSkipFirst = 1, 
                                     netReturns = doNetReturns,
                                     marketing = doMarketing)
     
     for(i in colnames(valueAdd)){
          valueAdd[colnames(retBmk),i] = fullprodres[i,colnames(retBmk)]
          valueAdd["Total",i] = fullprodres[i,colnames(ret)]
     }
     
     
     if(!is.null(retNoAlts)){
          # value add from adding alternatives
          
          addAltsValueAdd = rep(NA, ncol(valueAdd))
          names(addAltsValueAdd) = colNames
          
          # % columns
          addAltsValueAdd[pctColumns] = fromPct(fullprodres[pctColumns,colnames(ret)]) - 
               fromPct(retNoAltsres[pctColumns,colnames(ret)])
          
          # non % columns
          addAltsValueAdd[nonPctColumns] = fromPct(fullprodres[nonPctColumns,colnames(ret)]) - 
               fromPct(retNoAltsres[nonPctColumns,colnames(ret)])
     }
     
     
     
     
     if(!is.null(retNoTilts)){
          # value add from adding tilts
          
          addTiltsValueAdd = rep(NA, ncol(valueAdd))
          names(addTiltsValueAdd) = c( pctColumns[1], nonPctColumns[1],pctColumns[2])
          
          # % columns
          addTiltsValueAdd[pctColumns] = fromPct(fullprodres[pctColumns,colnames(ret)]) - 
               fromPct(retNoTiltsres[pctColumns,colnames(ret)])
          
          # non % columns
          addTiltsValueAdd[nonPctColumns] = fromPct(fullprodres[nonPctColumns,colnames(ret)]) - 
               fromPct(retNoTiltsres[nonPctColumns,colnames(ret)])
     }

     
     
     if(!is.null(retNoRiskMgmt)){
          # value add from adding riskmgmt
          
          addRiskMgmtValueAdd = rep(NA, ncol(valueAdd))
          names(addRiskMgmtValueAdd) = c( pctColumns[1], nonPctColumns[1],pctColumns[2])
          
          # % columns
          addRiskMgmtValueAdd[pctColumns] = fromPct(fullprodres[pctColumns,colnames(ret)]) - 
               fromPct(retNoRiskMgmtres[pctColumns,colnames(ret)])
          
          # non % columns
          addRiskMgmtValueAdd[nonPctColumns] = fromPct(fullprodres[nonPctColumns,colnames(ret)]) - 
               fromPct(retNoRiskMgmtres[nonPctColumns,colnames(ret)])
     }

     
     
     
     
     # Total value add
     totalValueAdd = 0
     
     if(!is.null(retNoAlts)) totalValueAdd = totalValueAdd + addAltsValueAdd
     if(!is.null(retNoTilts)) totalValueAdd = totalValueAdd + addTiltsValueAdd
     if(!is.null(retNoRiskMgmt)) totalValueAdd = totalValueAdd + addRiskMgmtValueAdd
     

     # value add breakdown
     if(!is.null(retNoTilts)) addTiltsValueAdd = addTiltsValueAdd/totalValueAdd
     if(!is.null(retNoAlts)) addAltsValueAdd = addAltsValueAdd/totalValueAdd
     if(!is.null(retNoRiskMgmt)) addRiskMgmtValueAdd = addRiskMgmtValueAdd/totalValueAdd
     
     
     # transforming table results into numeric
     valueAdd[,pctColumns] = 
          apply( data.frame(valueAdd[,pctColumns], stringsAsFactors = F), 2, fromPct)
     valueAdd[,nonPctColumns] = 
          apply( data.frame(valueAdd[,nonPctColumns], stringsAsFactors = F), 2, as.numeric)
     
     
     # value add from tilts
     
     if(!is.null(retNoTilts)){
          valueAdd["Factor Tilts",] = (valueAdd["Total",] - valueAdd[colnames(retBmk),]) *
               addTiltsValueAdd
     }

     if(!is.null(retNoAlts)){
          valueAdd["Adding Alternatives",] = (valueAdd["Total",] - valueAdd[colnames(retBmk),]) *
               addAltsValueAdd
     }     

     
     if(!is.null(retNoRiskMgmt)){
          valueAdd["Managing Risk",] = (valueAdd["Total",] - valueAdd[colnames(retBmk),]) *
               addRiskMgmtValueAdd
     }

     
     valueAdd = valueAdd[rowSums(is.na(valueAdd)) < ncol(valueAdd),]
     
     # transforming table results into nice format
     valueAdd[,pctColumns] = 
          apply( data.frame(valueAdd[,pctColumns], stringsAsFactors = F), 2, function(x) toPct(x, RoundCoef))
     valueAdd[,nonPctColumns] = 
          apply( data.frame(valueAdd[,nonPctColumns], stringsAsFactors = F), 2, function(x)round(x,2))
     
     colnames(valueAdd) = colNames
     rownames(valueAdd)[rownames(valueAdd) == "Total"] = colnames(ret)
     
     write.csv(valueAdd,paste0("attribution ", colnames(ret),".csv"))
     
     
     
     
     
     
     
     
     
     
     
     
     #####################
     # monthly value add #
     #####################
     
     valueAddMonthly = fullret
     
     valueAddMonthly = calcNetReturns(valueAddMonthly)
     
     if(!is.null(retNoTilts)){
          valueAddMonthly$`Factor Tilts Alpha` = (valueAddMonthly[,colnames(ret)] -
                                                       valueAddMonthly[,colnames(retBmk)]) * addTiltsValueAdd["Mean"]
          
          colnames(valueAddMonthly) = c(colnames(retBmk),colnames(ret),"Factor Tilts Alpha")
          
     }
     
     
     if(!is.null(retNoAlts)){
          valueAddMonthly$`Adding Alternatives Alpha` = (valueAddMonthly[,colnames(ret)] -
                                                              valueAddMonthly[,colnames(retBmk)]) * addAltsValueAdd["Mean"]
          
          colnames(valueAddMonthly) = c(colnames(retBmk),colnames(ret),if(!is.null(retNoTilts)){"Factor Tilts Alpha"},"Adding Alternatives Alpha")
          
     }

     if(!is.null(retNoRiskMgmt)){
          valueAddMonthly$`Managing Risk Alpha` = (valueAddMonthly[,colnames(ret)] -
                                                        valueAddMonthly[,colnames(retBmk)]) * addRiskMgmtValueAdd["Mean"]
          
          colnames(valueAddMonthly) = c(colnames(retBmk),colnames(ret),
                                        if(!is.null(retNoTilts)){"Factor Tilts Alpha"},
                                        if(!is.null(retNoAlts)){"Adding Alternatives Alpha"},
                                        "Managing Risk Alpha")
          
     }

     write.csv(data.frame(valueAddMonthly, check.names = F),paste0("attribution ", colnames(ret)," monthly contribution.csv"))
     
     
     ##############################
     # performance without 1 item #
     ##############################
     
     res = cbind(fullprodres[,c(colnames(retBmk), colnames(ret))])
     
     if(!is.null(retNoTilts)){
          res = cbind(res, retNoTiltsres)
     }
     
     if(!is.null(retNoAlts)){
          res = cbind(res, retNoAltsres) 
     }
     
     if(!is.null(retNoRiskMgmt)){
          res = cbind(res, retNoRiskMgmtres)
     }
     
     colnames(res) = c(colnames(retBmk), colnames(ret), 
                       if(!is.null(retNoTilts)){paste(colnames(ret),"No Factors Tilts")},
                       if(!is.null(retNoAlts)){paste(colnames(ret),"No Alternatives")},
                       if(!is.null(retNoRiskMgmt)){paste(colnames(ret),"No Managing Risk")})
     
     write.csv(res, paste0("attribution ", colnames(ret)," performance summary.csv"))
     
     
}

# dynamicName = "Dynamic Macro"
# # 60/40
# ret6040 = ret[,"60/40"]
# retBmk = ret6040
# wtBmk = 0.65
# 
# # dynamic portfolio
# dynamic = read.csv(paste0(returnLocation,"Raw Data/returns ","Dynamic Macro",".csv"))
# dynamic = xts(dynamic[,2], as.yearmon(dynamic[,1]))
# colnames(dynamic) = dynamicName
# dynamic = calcNetReturns(dynamic)
# 
# ret = dynamic
# 
# 
# dynamiceb = read.csv(paste0(returnLocation,"Raw Data/returns ","60 40 tactical tilts",".csv"))
# dynamiceb = xts(dynamiceb[,2], as.yearmon(dynamiceb[,1]))
# dynamiceb = dynamiceb[index(dynamic)]
# colnames(dynamiceb) = dynamicName
# dynamiceb = calcNetReturns(dynamiceb)
# colnames(dynamiceb) = "Equity Bond"
# 
# retNoAlts = dynamiceb
# wtNoAlts = 0.65
# 
# 
# dynamictilt = read.csv(paste0(returnLocation,"Raw Data/returns ","60 40 tactical",".csv"))
# dynamictilt = xts(dynamictilt[,2], as.yearmon(dynamictilt[,1]))
# colnames(dynamictilt) = dynamicName
# dynamictilt = calcNetReturns(dynamictilt)
# 
# retNoAltsNoTilts = dynamictilt
# wtNoAltsNoTilts = 0.65
# 
# 
# 
# 
# dynamicriskmgmt = read.csv(paste0(returnLocation,"Raw Data/returns ","60 40 tilts",".csv"))
# dynamicriskmgmt = xts(dynamicriskmgmt[,2], as.yearmon(dynamicriskmgmt[,1]))
# colnames(dynamicriskmgmt) = dynamicName
# dynamicriskmgmt = calcNetReturns(dynamicriskmgmt)
# 
# retNoAltsNoRiskMgmt = dynamicriskmgmt
# 
# wtNoAltsNoRiskMgmt = 0.65


# do3PartAttribution
# Does attribution where portfolio returns and volatility are 
# broken down into alternative, factor tilts, and risk management
# See comments at beginning of function
# Each of the 3 parts can be NULL, if it is not present in portfolio
# the retXXX means reutrn of a portfolio that is 100% invested
# without XXX part, along with the weight of that part
do3PartAttribution = function(ret, retBetaNoAlts, retNoAlts, wtNoAlts, 
                              retNoAltsNoTilts, wtNoAltsNoTilts, 
                              retNoAltsNoRiskMgmt, wtNoAltsNoRiskMgmt,
                              AnnualizationFactor, retBmkAlts = NULL, retBmkNoAlts = NULL)
{
     
     # Input error check
     if(ncol(ret) != 1) stop("ret has more than 1 column")
     if(ncol(retBetaNoAlts) != 1) stop("retBetaNoAlts has more than 1 column")
     # if(ncol(retNoAlts) != 1) stop("retNoAlts has more than 1 column")
     # if(ncol(retNoAltsNoTilts) != 1) stop("RetNoAltsNoTilts has more than 1 column")
     # if(ncol(retNoAltsNoRiskMgmt) != 1) stop("retNoAltsNoRiskMgmt has more than 1 column")
     
     # results will be returned in the results list
     results = list()

     # Portfolio Notation
     
     # ret. Portfolio return, such as our dynamic
     #    65% our equity bond portfolio, 35% alternative + MSI
     #
     # retNoAlts. Portfolio return without any alterntives
     #    also known as Equity Bond Portfolio
     #         60% our equity portfolio, 40% our bond portfolio + MSI
     #
     # retNoAltsNoRiskMgmt
     #    60% our equity portfolio with fixed weights, 40% our bond portfolio
     #    No MSI involved
     #
     # retNoAltsNoTilts
     #    60% SPY, EFA, EEM with MSI, 40% AGG + MSI
     #
     # retBetaNoAlts
     #    60% ACWI, 40% AGG
     
     # Attribution notation
     
     # cXX, contribution of XX
     # aXx, attribution of XX = cXX * weight
     
     
     
     # Return attribution framework
     #    aAlternative = Dynamic - 65% * Dynamic No Alts
     #
     #    aEquityBond = 65% Dynamic No Alts
     #
     #    This is broken down into
     #         a6040 = 65% * 60/40
     #
     #         aMSI(0) = aEquityBond - 65% * Dynamic No Alts No MSI = 65% * (Dynamic No Alts - Dynamic No Alts No MSI)
     #              Before allocating delta
     #         aFT(0) = aEquityBond - 65% * Dynamic No Alts No FT  = 65% * (Dynamic No Alts - Dynamic No Alts No FT)
     #              Before allocating delta
     #		%FT
     #              aFT(0) / ( aMSI(0) + aFT(0) )
     #                   70.4%
     #         Delta = aEquityBond - a6040 - aMSI(0) - aFT(0)
     #
     #         aMSI = aMSI(0) + Delta * ( 1 - %FT )
     #
     #	     aFT = aFT(0) + Delta * %FT
     # 
     #    Dynamic = a6040 + aMSI + aFT + aAlternative
     
     
     
     
     
     # Set all series to same period
     
     datelist = list(index(ret),
                     index(retBetaNoAlts),
                     if(!is.null(retNoAlts)) index(retNoAlts),
                     if(!is.null(retNoAltsNoTilts)) index(retNoAltsNoTilts), 
                     if(!is.null(retNoAltsNoRiskMgmt)) index(retNoAltsNoRiskMgmt),
                     if(!is.null(retBmkAlts)) index(retBmkAlts),
                     if(!is.null(retBmkNoAlts)) index(retBmkNoAlts))
     datelist = datelist[!sapply(datelist, is.null)] 
     
     common_months = Reduce(intersect, datelist)

     common_months = setToDate(common_months, ret)
     
     ret = ret[common_months]
     retBetaNoAlts = retBetaNoAlts[common_months]
     retNoAlts = retNoAlts[common_months]
     retNoAltsNoTilts = retNoAltsNoTilts[common_months]
     retNoAltsNoRiskMgmt = retNoAltsNoRiskMgmt[common_months]
     retBmkAlts = retBmkAlts[common_months]
     retBmkNoAlts = retBmkNoAlts[common_months]
     
     ####################################
     # Contribution to portfolio return #
     ####################################
     
     if(!is.null(retNoAlts)){
          
          # if retAlts or retBmkAlts either are null, 
          # then alts doesn't have a benchmark
          if(is.null(retBmkAlts)){
               aAlts = (ret - wtNoAlts * retNoAlts)
               colnames(aAlts) = "Adding Alternative" 
               
               aAltsBmk = NULL
          } else {

               ## Alts attribution is Alts return - Alts bmk return
               ## This however ignores netting benefits
               ## aAlts = (retAlts - retBmkAlts) * (1 - wtNoAlts)

               # Alts attribution is  portfolio - (65% return no Alts + 35% retBmkAlts)
               # This however has all netting benefits going to alts
               aAlts = (ret - (wtNoAlts * retNoAlts + (1 - wtNoAlts) * retBmkAlts))

               colnames(aAlts) = "Alternative"
               aAltsBmk = (1 - wtNoAlts) * retBmkAlts
          }

          
          if(wtNoAlts == 1){
               cAlts = aAlts
          } else {
               cAlts = aAlts/(1-wtNoAlts)
               
               if(!is.null(aAltsBmk)){
                    cAltsBmk = aAltsBmk/(1-wtNoAlts)
               }
          }
          
          
          # Now after I've removed alternatives
          # need to scale down retNoAlts to wtNoAlts
          
          retNoAlts = retNoAlts * wtNoAlts
          # # no alts
          # retNoAltsres =  calcSummaryStats2(retNoAlts,
          #                                   retBetaNoAlts, colnames(retBetaNoAlts),  increaseDownsideSkipFirst = 0, 
          #                                   netReturns = doNetReturns,
          #                                   marketing = doMarketing)  
     } else {
          # when there is no alts in the portfolio
          # the return without alts is simply the portfolio return
          retNoAlts = ret
          
          aAlts = NULL
          aAltsBmk = NULL
          cAlts = NULL
     }
     
     
     # Value add from tilts and risk management of the 
     # return without Alts
     
     # Need to keep track of difference of
     # delta = retNoAlts - aTilts - aRiskMgmt - aBetaNoAlts
     # Will build delta incrementally
     
     if(!is.null(retNoAltsNoTilts)){
          # from returns without alts
          # get value add from tilts
          
          aTilts = retNoAlts - retNoAltsNoTilts * wtNoAltsNoTilts
          cTilts = aTilts/wtNoAltsNoTilts
          
          delta = retNoAlts - aTilts
          
          # retNoTiltsres =  calcSummaryStats2(retNoTilts,
          #                                    retBetaNoAlts, colnames(retBetaNoAlts),  increaseDownsideSkipFirst = 0, 
          #                                    netReturns = doNetReturns,
          #                                    marketing = doMarketing)
     } else {
          aTilts = NULL
          cTilts = NULL
          delta = NULL
     }
     
     
     if(!is.null(retNoAltsNoRiskMgmt)){
          # from returns without alts
          # get value add from managing risk
          
          aRiskMgmt = retNoAlts - retNoAltsNoRiskMgmt * wtNoAltsNoRiskMgmt
          cRiskMgmt = aRiskMgmt/wtNoAltsNoRiskMgmt
          
          if(!is.null(delta)){
               delta = delta - aRiskMgmt
          } else {
               # the case where we had no tilts
               delta = retNoAlts - aRiskMgmt
          }
          
          
          # retNoRiskMgmtres =  calcSummaryStats2(retNoRiskMgmt,
          #                                       retBetaNoAlts, colnames(retBetaNoAlts),  increaseDownsideSkipFirst = 0, 
          #                                       netReturns = doNetReturns,
          #                                       marketing = doMarketing) 
     }
     
     
     if(!is.null(retBetaNoAlts)){
          # from returns without alts
          # get contribution from benchmark
          aBetaNoAlts = retBetaNoAlts * wtNoAlts
     
          delta = delta - aBetaNoAlts
          
          if( !is.null( retBmkNoAlts) ){
               aBetaNoAlts = aBetaNoAlts - retBmkNoAlts * wtNoAlts
               aBmkNoAlts = retBmkNoAlts * wtNoAlts
               cBmkNoAlts = retBmkNoAlts
          } else {
               aBmkNoAlts = NULL
               cBmkNoAlts = NULL
          }
          cBetaNoAlts = aBetaNoAlts/wtNoAlts
     }
     
     
     # Need to allocate the delta between tilts and managing risks
     
     if(!is.null(aTilts) & !is.null(aRiskMgmt)){
          # If we have both tilts and risk management, then
          # will allocate the delta to them in the following ratios
          # which are their % of joint contribution from 
          # April 2004 to May 2016
          
          if(colnames(ret) == "Dynamic Macro"){
               wt = c("Managing Risk" = 0.3191019,#0.65 * mean(aRiskMgmt)/(mean(aTilts) + mean(aRiskMgmt)),
                      "Factor Tilts" = 0.6808981)#0.65 * mean(aTilts)/(mean(aTilts) + mean(aRiskMgmt)))
          } else if(colnames(ret) == "Enhanced Macro"){
               wt = c("Managing Risk" = 0.2517375,#0.65 * mean(aRiskMgmt)/(mean(aTilts) + mean(aRiskMgmt)),
                      "Factor Tilts" = 0.7482625)#0.65 * mean(aTilts)/(mean(aTilts) + mean(aRiskMgmt)))
               
          } else if(colnames(ret) == "Global Equity"){
               wt = c("Managing Risk" = 0.3120021,#0.65 * mean(aRiskMgmt)/(mean(aTilts) + mean(aRiskMgmt)),
                      "Factor Tilts" = 0.6879979)#0.65 * mean(aTilts)/(mean(aTilts) + mean(aRiskMgmt)))
          } else {
               stop("Function currently only handles dynamic macro, enhanced macro, and global equity. Need to set up fixed allocation of tilts and risk management delta before adding new portfolio")
          }
          
          aTilts = aTilts + delta * wt["Factor Tilts"]
          aRiskMgmt = aRiskMgmt + delta * wt["Managing Risk"]
          
          cTilts = aTilts/wtNoAltsNoTilts
          cRiskMgmt = aRiskMgmt/wtNoAltsNoRiskMgmt
     } else if(!is.null(aTilts) & is.null(aRiskMgmt)){
          # If we value add of tilts but not risk management
          aTilts = aTilts + delta
          
          cTilts = aTilts/wtNoAltsNoTilts
          
     } else if(is.null(aTilts) & !is.null(aRiskMgmt)){
          # If we value add of risk management but not alts
          aRiskMgmt = aRiskMgmt + delta
          
          cRiskMgmt = aRiskMgmt/wtNoAltsNoRiskMgmt
     } else {
          stop("Should never run this attribution module without both risk management and tilts")
     }
     

     # check if the attribution without alts adds up
     # that the parts sum to the whole
     
     ret0 = ret
     ret0[] = 0
     
     # Begin comparing equity bond part
     
     retNoAltsReplication = ret0
     if(!is.null(aTilts)) {
          retNoAltsReplication = retNoAltsReplication + aTilts
     }
     
     if(!is.null(aRiskMgmt)) {
          retNoAltsReplication = retNoAltsReplication + aRiskMgmt
     }
     
     if(!is.null(aBetaNoAlts)) {
          retNoAltsReplication = retNoAltsReplication + aBetaNoAlts
          
          if(!is.null(aBmkNoAlts)){
               retNoAltsReplication = retNoAltsReplication + aBmkNoAlts
          }
     }
     checkDifference(retNoAlts - retNoAltsReplication, 0,
     "Return attribution error: equity bond parts don't sum up to whole")
     
     # Compare entire portfolio
     
     retReplication = retNoAltsReplication
     
     retReplication = retReplication + if(is.null(aAlts)) { xts(rep(0, nrow(retReplication)),index(retReplication)) } else { aAlts } + 
          if(is.null(aAltsBmk)) { xts(rep(0, nrow(retReplication)),index(retReplication)) } else { aAltsBmk }

     # if aBmkNoAlts is NULL, that means we have no benchmark for equity bond part
     # and want to allocate the beta part to a benchmark, and then set beta part to NULL
     aBmk = if(is.null(aBmkNoAlts)) { aBetaNoAlts } else { aBmkNoAlts } + if(is.null(aAltsBmk)) { xts(rep(0, nrow(aAlts)),index(aAlts)) } else { aAltsBmk }
     # also want to remove aBetaNoAlts if it is all 0
     # it is all 0, when the retBmkNoAlts is ret6040
     if(is.null(aBmkNoAlts) | all(aBetaNoAlts == 0)) { aBetaNoAlts = NULL }
     
     
     
     
     wtBmk = wtNoAlts + if(is.null(aAltsBmk)) { 0 } else { 1 - wtNoAlts }
     cBmk = aBmk/wtBmk
       
     
     # check if the entire attribution alts adds up
     # that the parts sum to the whole   
     checkDifference(ret - retReplication,0, "Return attribution error: parts don't sum up to whole")
     
     
     # Plot histogram of delta
     colnames(delta) = "Delta"
     plotHistogram(delta,"Delta","Delta",4,
                   ifelse(abs(max(delta)) <= abs(min(delta)),"topleft","topright"))
     
     
     # Save monthly contributions
     retAttrb = merge(aBmk, if(exists("aTilts")) aTilts, 
                     if(exists("aRiskMgmt")) aRiskMgmt, 
                        if(exists("aAlts")) aAlts, 
                         if(!is.null(aBetaNoAlts)) aBetaNoAlts)
     
     attributionPartNames = c("Beta",if(!is.null(aTilts)) "Return Drivers", 
                               if(!is.null(aRiskMgmt)) "Risk Timing", 
                               if(!is.null(aAlts)) "Adding Alternatives",
                                   if(!is.null(aBetaNoAlts)) "Beta Difference")
     
     colnames(retAttrb) = attributionPartNames
     
     # Second error check that parts sum to whole
     checkDifference(ret - xts(rowSums(retAttrb), index(retAttrb)),0,"Return attribution error: parts don't sum up to whole")

     
     # Plot histogram of monthly contributions
     for(i in 1:ncol(retAttrb)){
          plotHistogram(retAttrb[,i], 
                        paste("Contribution of",colnames(retAttrb[,i])), 
                        colnames(retAttrb)[i], 4,
                        ifelse(abs(max(retAttrb[,i])) <= abs(min(retAttrb[,i])),"topleft","topright"))
     }
     
     
     retAttrbM = merge(ret,retAttrb)
     colnames(retAttrbM) = c(colnames(ret), colnames(retAttrb))
     # Save monthly results
     results[["Return Attribution Monthly"]] = retAttrbM
     
     # Save summary
     toPctRoundCoef = 3
     
     parts = setdiff(colnames(retAttrbM),c(colnames(ret),"Beta"))
     
     # summarize annualized results
     retAttrb = colMeans(retAttrb) * AnnualizationFactor
     
     # add % contribution
     if(wtBmk == 1){
          # Doing attribution of alpha
          retAttrb = rbind(toPct(retAttrb, toPctRoundCoef), toPct(retAttrb/sum(retAttrb[parts]), toPctRoundCoef))
          colnames(retAttrb) = attributionPartNames
          # need to remove the % contribution from beta column
          retAttrb[2,"Beta"] = ""
     } else {
          # Doing return attribution
          retAttrb = rbind(toPct(retAttrb, toPctRoundCoef), toPct(retAttrb/sum(retAttrb), toPctRoundCoef))
          colnames(retAttrb) = attributionPartNames
     }
     
     
     rownames(retAttrb) = c("Contribution to Return","% Contribution")
     
     # add portfolio results
     retAttrb = cbind(c("Contribution to Return" = toPct(mean(ret) * AnnualizationFactor, toPctRoundCoef),
                         "% Contribution" = ""), retAttrb)
     colnames(retAttrb)[1] = colnames(ret)
     
     results[["Return Attribution"]] = retAttrb
     
     
     ########################################
     # Contribution to portfolio volatility #
     ########################################
     
     volCtrb = merge(cBmk, if(!is.null(cTilts)) cTilts, 
                     if(!is.null(cRiskMgmt)) cRiskMgmt, 
                     if(!is.null(cAlts)) cAlts,
                     if(!is.null(aBetaNoAlts)) cBetaNoAlts)
     
     
     colnames(volCtrb) = attributionPartNames
     
     volCtrbWt = c(wtBmk, if(!is.null(wtNoAltsNoTilts)) wtNoAltsNoTilts,
                   if(!is.null(wtNoAltsNoRiskMgmt)) wtNoAltsNoRiskMgmt, 
                   if(!is.null(cAlts)) ifelse(wtNoAlts == 1,1,1-wtNoAlts),
                   if(!is.null(aBetaNoAlts)) wtNoAlts)     
     names(volCtrbWt) = attributionPartNames
     
     
     volAttrb = sapply(colnames(volCtrb),function(name){
          volCtrbWt[name] * sd(volCtrb[,name]) * cor(volCtrb[,name], ret)
     })
     
     
     checkDifference(sd(ret), sum(volAttrb),"Vol attribution doesn't add up to portfolio vol")
     
     # annualize results
     volAttrb = volAttrb * sqrt(AnnualizationFactor)
     
     # add % contribution
     if(wtBmk == 1){
          volAttrb = rbind(toPct(volAttrb, toPctRoundCoef), toPct(volAttrb/sum(volAttrb[parts]), toPctRoundCoef))
          colnames(volAttrb) = attributionPartNames
          # need to remove the % contribution from beta column
          volAttrb[2,"Beta"] = ""
     } else {
          volAttrb = rbind(toPct(volAttrb, toPctRoundCoef), toPct(volAttrb/sum(volAttrb), toPctRoundCoef))
          colnames(volAttrb) = attributionPartNames
     }
     rownames(volAttrb) = c("Contribution to Volatility","% Contribution")
     
     
     # add portfolio vol
     volAttrb = cbind(c("Contribution to Volatility" = toPct(sd(ret) * sqrt(AnnualizationFactor), toPctRoundCoef),
                        "% Contribution" = ""), volAttrb)
     colnames(volAttrb)[1] = colnames(ret)
     
     results[["Volatility Attribution"]] = volAttrb
     
     
     #################################################
     # Marginal Contribution to portfolio volatility #
     #################################################
     
     margCtrb = retAttrbM

     checkDifference(ret, margCtrb[,colnames(ret)],"Return and Return in retAttrbM doesn't match")
     
     
     # Remove the part from the product
     margCtrb[, parts] = 
          vectorToXtsMatrix(margCtrb[,colnames(ret)], length(parts)) -
               margCtrb[, parts]
     
     # Calculate summary stats with the part removed from the product
     margAttrb = calcSummaryStats2(margCtrb,margCtrb[,"Beta"],"Beta")
     
     volMargCtrb = fromPct(margAttrb["Stdev",])
     names(volMargCtrb) = colnames(margAttrb)
     
     # Calculate how much volatility changes when removing part from product
     volMargCtrb[parts] = volMargCtrb[colnames(ret)] - volMargCtrb[parts]
     
     # Calculating percent contribution to total volatility change
     volMargCtrb[parts] = volMargCtrb[parts]/abs(sum(volMargCtrb[parts]))
     
     # add row for total contribution and % contribution
     volMargCtrb = rbind(volMargCtrb,volMargCtrb)
     rownames(volMargCtrb) = rownames(volAttrb)
     
     volMargCtrb["Contribution to Volatility",parts] = 
     (volMargCtrb["Contribution to Volatility", "Beta"] - volMargCtrb["Contribution to Volatility", colnames(ret)]) * 
          volMargCtrb["% Contribution", parts]

     # have volatility reduction, and contribution to it, need to flip sign of % contribution
     volMargCtrb["% Contribution",parts] = -volMargCtrb["% Contribution",parts]
     
     volMargCtrb = apply(volMargCtrb,2, function(x){toPct(x,toPctRoundCoef)})
     rownames(volMargCtrb) = rownames(volAttrb)
     
     volMargCtrb["% Contribution",c(colnames(ret),"Beta")] = ""
     
     results[["Volatility Marginal Attribution"]] = volMargCtrb
     
     ########
     # Done #
     ########
     
     return(results)
}

write3PartAttrbResults = function(res, name){
     write.csv(data.frame(res[["Return Attribution Monthly"]], check.names = F), paste("attribution -",name,"return attribution monthly.csv"))
     write.csv(res[["Return Attribution"]], paste("attribution -",name,"return attribution.csv"))
     write.csv(res[["Volatility Attribution"]], paste("attribution -",name,"volatility attribution.csv"))
     write.csv(res[["Volatility Marginal Attribution"]], paste("attribution -",name,"volatility difference attribution.csv"))
     
}

write1PartAttrbResults = function(res, name, end_=NULL){
     if (is.null(end_)) {
         write.csv(data.frame(res[["Return Attribution Monthly"]], check.names = F), paste("attribution -",name,"return attribution monthly.csv"))     
     } else {
        temp  = res[["Return Attribution Monthly"]]
        temp  = temp[index(temp)>=as.yearmon(end_-1/12)]
        write.csv(data.frame(temp, check.names = F), paste("attribution -",name,"return attribution monthly.csv"))     
     }
}




calcGrowingPctile = function(x, minQuantileLength){
     xpctile = x
     xpctile[,] = NA
     
     
     if(nrow(x) >= (minQuantileLength + 1)){
          for(sig in colnames(x)){
               
               for(mydate in ((minQuantileLength + 1):nrow(x))){
                    if(all(is.na(x[1:(mydate-1), sig]))){
                         NA
                    } else {
                         xpctile[mydate, sig] = 
                              ecdf(as.numeric(x[1:(mydate-1), sig]))(as.numeric(x[mydate,sig]))
                    }
                    
               }
               
          }
     }
     
     return(xpctile)
}

# res = getSignalReturnTree(sigName, signalLocation, alloc = myalloc)
# res = res[signal_level <= maxLevel,]
# x = "return"
# mySigName = sigName
# minQuantileLength = 12
calcCtrb = function(res = myres, x = myx, mySigName = sigName, minQuantileLength = 12, leverage = NULL){
     
     # get what we are analyzing
     if(is.character(x)){
          # browser()
          ret = datToXts(unique(res[,parent_signal:=NULL]),"signal","date",x)
          last = index(ret)[length(index(ret))]
          first = index(ret)[!is.na(ret[,mySigName])][1]
          ret = ret[index(ret)>=(first),]
          ret = ret[index(ret)<=(last),]
          #for (i in names(ret)) {
          #   if (is.na(ret[last,i])) {
          #      ret[last,i] = 0
          #   }
          #}
          #ret = na.omit(ret)
          ret = na.fill(ret,0)

     } else {
          ret = x
     } 

     # if (mySigName=="BONDS_DYNAMIC") {browser()}
     # get the weights
     defaultwt = na.omit(datToXts(unique(res[,parent_signal:=NULL]),"signal","date","signal_wt"))
     wt = na.omit(datToXts(unique(res[,parent_signal:=NULL]),"signal","date","signal_current_wt"))
     timingwt = na.omit(datToXts(unique(res[,parent_signal:=NULL]),"signal","date","signal_timing_wt"))
     
     # error check on weights
     # weights include a 1 entry for the parent signal, so need to compare to 2
     checkDifference(rowSums(abs(defaultwt)), 2, "calcCtrb error: sum of abs default weights isn't 1")
     if(any( (rowSums(abs(wt)) - 2) < -DiffTolerance)) stop("calcCtrb error: sum of abs weights with scaling below 1")
     checkDifference(rowSums(abs(timingwt)), 2, "calcCtrb error: sum of abs timing weights isn't 1")
     
                     
     # set to common months and column setup
     common_months = getCommonMonths(ret, wt)
     
     ret = ret[common_months]
     wt = wt[common_months] 
     defaultwt = defaultwt[common_months]
     timingwt = timingwt[common_months]
     
     wt = wt[,colnames(ret)]
     defaultwt = defaultwt[,colnames(ret)]
     timingwt = timingwt[,colnames(ret)]
	 if (!is.null(leverage)) {
	    leverage = leverage[common_months]
		wt = wt * as.numeric(leverage)
		defaultwt = defaultwt * as.numeric(leverage)
		timingwt = timingwt * as.numeric(leverage)	
	 }
	 
     risktimingwtadj = timingwt - defaultwt
	 
	 
     # need to adjust attribution weights to include the sign of the timing signal
     # sign of timing signal comes from wt_adj
     
     if(any( wt < -DiffTolerance ) ){
          stop("no net attribution weights should be negative")
     }
     
     if(any(timingwt < -DiffTolerance)){
          
          print(paste(names(which(apply(timingwt,2,function(x){any(x<0)}))),"have negative timing weights"))
          warning(print(paste(names(which(apply(timingwt,2,function(x){any(x<0)}))),"have negative timing weights")))
     }
     
     wt = wt * sign(timingwt)

     # Calculate contributions
     ctrb = ret * wt
     ctrbdefaultwt = ret * defaultwt
     ctrbtimingwt = ret * timingwt
     ctrbToRiskTiming = ctrbtimingwt - ctrbdefaultwt
     # gxs being dirty...
     if (mySigName %in% c("ALL_DYNAMIC_GLOBAL_MACRO")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,!(names(risktimingwtadj) %in% c("BONDS_EM","EQUITIES_ACWI",mySigName))] = 0
        # risktimingwtadj[,!(names(risktimingwtadj) %in% c("BONDS_EM","EQUITIES_ACWI","SINGLE_ETF_BKLN","SINGLE_ETF_HYG",mySigName))] = 0
        ctrbToRiskTiming[,"EQUITIES_ACWI"] = risktimingwtadj[,"EQUITIES_ACWI"] * (ret[,"EQUITIES_ACWI"]-ret[,"SHELTER_BASKET_EB_MSI"])
        if ("BONDS_EM" %in% names(ctrbToRiskTiming)) {
           ctrbToRiskTiming[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] = risktimingwtadj[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] * (ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"]-0.75*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"TREASURIES_US"]-0.25*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"CREDIT_US_CREDIT_RISK_SPY"])
        }
     } else if (mySigName %in% c("ALL_GLOBAL_MACRO")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,!(names(risktimingwtadj) %in% c("BONDS_EM",mySigName))] = 0
        # ctrbToRiskTiming[,"EQUITIES_ACWI"] = risktimingwtadj[,"EQUITIES_ACWI"] * (ret[,"EQUITIES_ACWI"]-ret[,"SHELTER_BASKET_EB_MSI"])
        if ("BONDS_EM" %in% names(ctrbToRiskTiming)) {
            ctrbToRiskTiming[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] = risktimingwtadj[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] * (ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"]-0.75*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"TREASURIES_US"]-0.25*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"CREDIT_US_CREDIT_RISK"])
        }
     } else if (mySigName %in% c("EQUITIES_ACWI")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,!(names(risktimingwtadj) %in% c("EQUITIES_EM","EQUITIES_EAFE",mySigName))] = 0
        ctrbToRiskTiming[,"EQUITIES_EM"]    = risktimingwtadj[,"EQUITIES_EM"]   * (ret[,"EQUITIES_EM"]-ret[,"EQUITIES_US"])
        ctrbToRiskTiming[,"EQUITIES_EAFE"]  = risktimingwtadj[,"EQUITIES_EAFE"] * (ret[,"EQUITIES_EAFE"]-ret[,"EQUITIES_US"])
     } else if (mySigName %in% c("BONDS_DYNAMIC")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,!(names(risktimingwtadj) %in% c("BONDS_EM","BONDS_INTERNATIONAL",mySigName))] = 0
        if ("BONDS_EM" %in% names(ctrbToRiskTiming)) {
            ctrbToRiskTiming[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] = risktimingwtadj[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] * (ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"]-0.75*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"TREASURIES_US"]-0.25*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"CREDIT_US_CREDIT_RISK_SPY"])
            ctrbToRiskTiming[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"BONDS_EM"] = risktimingwtadj[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"BONDS_EM"] * (ret[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"BONDS_EM"]-0.54*ret[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"TREASURIES_US"]-0.46*ret[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"SINGLE_ETF_MBB"])
        }
     } else if (mySigName %in% c("BONDS")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,!(names(risktimingwtadj) %in% c("BONDS_EM","BONDS_INTERNATIONAL", mySigName))] = 0
        if ("BONDS_EM" %in% names(ctrbToRiskTiming)) {
            ctrbToRiskTiming[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] = risktimingwtadj[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"] * (ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"BONDS_EM"]-0.75*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"TREASURIES_US"]-0.25*ret[index(ctrbToRiskTiming) < as.yearmon("Feb 2017"),"CREDIT_US_CREDIT_RISK"])
            ctrbToRiskTiming[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"BONDS_EM"] = risktimingwtadj[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"BONDS_EM"] * (ret[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"BONDS_EM"]-0.54*ret[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"TREASURIES_US"]-0.46*ret[index(ctrbToRiskTiming) >= as.yearmon("Feb 2017"),"SINGLE_ETF_MBB"])
        }
     }  else if (mySigName %in% c("EQUITIES_ACWI_SPYEMEFA_DDS")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,!(names(risktimingwtadj) %in% c("SINGLE_ETF_EFA","SINGLE_ETF_EEM",mySigName))] = 0
        ctrbToRiskTiming[,"SINGLE_ETF_EEM"] = risktimingwtadj[,"SINGLE_ETF_EEM"] * (ret[,"SINGLE_ETF_EEM"]-ret[,"SINGLE_ETF_SPY"])
        ctrbToRiskTiming[,"SINGLE_ETF_EFA"] = risktimingwtadj[,"SINGLE_ETF_EFA"] * (ret[,"SINGLE_ETF_EFA"]-ret[,"SINGLE_ETF_SPY"])
     }  else if (mySigName %in% c("ABS_RETURN_PORTFOLIO")) {
        ctrbToRiskTiming[,] = 0
        risktimingwtadj[,]  = 0
        slipp = (ret[index(ctrb),mySigName]-xts(rowSums(ctrb[, setdiff(colnames(ctrb), mySigName)]), index(ctrb)))*(1/xts(rowSums(wt[, setdiff(colnames(wt), mySigName)]), index(ctrb)))
        for (i in names(ret)) {
           if (i != mySigName) {
               ret[index(ctrb), i] = ret[index(ctrb), i] + slipp[index(ctrb),mySigName]
           } 
        }
        ctrb = ret * wt
        ctrbdefaultwt = ret * defaultwt
        ctrbtimingwt = ret * timingwt
     }
     # defaultwt and timingwt both have 1 for mySigName, therefore the ctrbToRiskTiming will be 0
     # need to set it to the sum of others
     wt[,mySigName] = xts(rowSums(abs(wt[, setdiff(colnames(wt), mySigName)])), index(wt))
     risktimingwtadj[,mySigName] = xts(rowSums(risktimingwtadj[, setdiff(colnames(risktimingwtadj), mySigName)]), index(risktimingwtadj))
     ctrbToRiskTiming[,mySigName] = xts(rowSums(ctrbToRiskTiming[, setdiff(colnames(ctrbToRiskTiming), mySigName)]), index(ctrbToRiskTiming))

     

     # # Error check to ensure that contribution to returns sum up to the return number
     # test = merge(xts(fromPct(toPct(ctrb[,mySigName] - xts( rowSums(ctrb[, setdiff(colnames(ctrb), mySigName)]), index(ctrb)),6)),index(ctrb)),
     # xts(rowSums(abs(wt)),index(wt)))
     # colnames(test) = c("Diff","Sum wt")
     
     checkDifference(ctrb[,mySigName], xts( rowSums(ctrb[, setdiff(colnames(ctrb), mySigName)]), index(ctrb)),
                    paste("calcCtrb error: 1 contributions don't sum up to whole all months for",x, mySigName),
                    T)
 

     # Calculate contributions quantiles
     # Will compare the contribution to the empirical distribution of contribution for
     # each signal, and give a %tile
     
     ctrbpctile = calcGrowingPctile(ctrb, minQuantileLength)
     retpctile = calcGrowingPctile(ret, minQuantileLength)
     ctrbToRiskTimingpctile = calcGrowingPctile(ctrbToRiskTiming, minQuantileLength)
     riskTimingpctile = calcGrowingPctile(risktimingwtadj, minQuantileLength)
     # ret = merge(ret, ctrb[,addNames])
     
     
     # set sigName to Total
     # set sigName to Total
     colnames(ret)[colnames(ret) == mySigName] = "Total"
     colnames(retpctile)[colnames(retpctile) == mySigName] = "Total"
     colnames(wt)[colnames(wt) == mySigName] = "Total"
     colnames(timingwt)[colnames(timingwt) == mySigName] = "Total"
     colnames(defaultwt)[colnames(defaultwt) == mySigName] = "Total"
     colnames(risktimingwtadj)[colnames(risktimingwtadj) == mySigName] = "Total"
     colnames(riskTimingpctile)[colnames(riskTimingpctile) == mySigName] = "Total"
     colnames(ctrbToRiskTiming)[colnames(ctrbToRiskTiming) == mySigName] = "Total"
     colnames(ctrbToRiskTimingpctile)[colnames(ctrbToRiskTimingpctile) == mySigName] = "Total"
     colnames(ctrb)[colnames(ctrb) == mySigName] = "Total"
     colnames(ctrbpctile)[colnames(ctrbpctile) == mySigName] = "Total"
     
     # Save results
     
     ctrbres = list()
     
     ctrbres[["return"]] = ret
     
     ctrbres[["return pctile"]] = retpctile[,colnames(ret)] # to ensure column setup is same
     
     ctrbres[["weight"]] = wt[,colnames(ret)]
     
     ctrbres[["timing weight"]] = timingwt[,colnames(ret)]
     
     ctrbres[["default weight"]] = defaultwt[,colnames(ret)]
     
     ctrbres[["active weight"]] = risktimingwtadj[,colnames(ret)]
     
     ctrbres[["active weight pctile"]] = riskTimingpctile[,colnames(ret)]
     
     ctrbres[["contribution to risk timing"]] = ctrbToRiskTiming[,colnames(ret)]
     
     ctrbres[["contribution to risk timing pctile"]] = ctrbToRiskTimingpctile[,colnames(ret)]
     
     ctrbres[["contribution"]] = ctrb[,colnames(ret)]
     
     ctrbres[["contribution percentile"]] = ctrbpctile[,colnames(ret)]
     
     return(ctrbres)
     
}





# 
# sigName = "ABS_RETURN_PORTFOLIO"
# signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
# maxLevel = 2
# myalloc = NULL
# benchmark = "HFRX_Absolute_Return"
# beta_adjust_bmk = T
# rollBetaLength = NULL
# myfees = 0
# start_ = as.yearmon("Apr 2004")
# end_ = as.yearmon("Sep 2016")

signalAttributionResults = function(sigName, signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_", 
                                    maxLevel = 2, myalloc = NULL, benchmark = NULL, beta_adjust_bmk = F, rollBetaLength = NULL,
                                    myfees = NULL, start_ = NULL, end_ = NULL, productWeight = NULL, myLev=NULL){
     
    if(!is.null(myalloc)) {
        myalloc[,"strategy"] = as.character(myalloc[,"strategy"])
        print(paste0("SAR: ",sigName," alloc present"))
    } else {
       print(paste0("SAR: ",sigName," alloc NOT present"))
    }
     
     # will return results in returnres
     returnres = list()
     
     # get signal return tree 
     res = getSignalReturnTree(sigName, signalLocation, alloc = myalloc, fees = myfees,
                               date_start = start_, date_end = end_)
     res = res[signal_level <= maxLevel,]
     
     # res[parent_signal == "ALL_DYNAMIC_GLOBAL_MACRO",.(signal, date, signal_wt, signal_current_wt)]
     # Get return contribution
     retctrbres = calcCtrb(res, "return", sigName, leverage=myLev)
     
     
     # compare the contribution from the custom alloc, and the main alloc
     if(!is.null(myalloc)){
          res2 = getSignalReturnTree(sigName, signalLocation)
          res2 = res2[signal_level <= maxLevel,]
          
          retctrbres2 = calcCtrb(res2,"return", sigName)
          
          ctrb = retctrbres[["contribution"]]
          ctrb2 = retctrbres2[["contribution"]]
          
          ret1 = xts(rowSums(ctrb[,setdiff(colnames(ctrb),c(sigName,"residual"))]),index(ctrb))
          ret2 = xts(rowSums(ctrb2[,setdiff(colnames(ctrb2),c(sigName,"residual"))]),index(ctrb2))
          
          checkDifference(ret1, ret2,
                          paste("Custom alloc file final return without residual doesn't match", sigName,"alloc file returns without residual"),
                          T)
     }
     
     
     returnres[["Returns"]] = retctrbres[["return"]]
     returnres[["Returns %tile"]] = retctrbres[["return pctile"]]
     returnres[["Default Weight"]] = retctrbres[["default weight"]]
     returnres[["Current Weight"]] = retctrbres[["timing weight"]]
     returnres[["Timing Weight"]] = retctrbres[["active weight"]]
     returnres[["Timing Weight %tile"]] = retctrbres[["active weight pctile"]]
     
     returnres[["Ctrb to Timing"]] = retctrbres[["contribution to risk timing"]]
     returnres[["Ctrb to Timing %tile"]] = retctrbres[["contribution to risk timing pctile"]]

     returnres[["Weight w. Netting"]] = retctrbres[["weight"]]
	 if (!is.null(productWeight)) {
	   productWeight = productWeight[index(retctrbres[["return"]])]
	   returnres[["Product Weight w. Netting"]] = retctrbres[["weight"]]*as.numeric(productWeight)
	 }
	 
     returnres[["Ctrb to Returns"]]  = retctrbres[["contribution"]]
     returnres[["Ctrb to Returns %tile"]]  = retctrbres[["contribution percentile"]]

	 if (!is.null(productWeight)) {
	   productWeight = productWeight[index(retctrbres[["return"]])]
	   returnres[["Product Ctrb to Returns"]] = retctrbres[["return"]]*retctrbres[["weight"]]*as.numeric(productWeight)
	   returnres[["Product Ctrb to Returns"]][,"Total"] = retctrbres[["return"]][,"Total"]*as.numeric(productWeight)
	 }
     
     
     # Alpha contribution
     

      # alpharet = datToXts(res,"signal","date","return")
      # last = index(alpharet)[length(index(alpharet))]
      # first = index(alpharet)[!is.na(alpharet[,sigName])][1]
      # alpharet = alpharet[index(alpharet)>=(first),]
      # alpharet = alpharet[index(alpharet)<=(last),]
      # alpharet = na.fill(alpharet, 0)
      # for (i in names(alpharet)) {
      #    if (is.na(alpharet[last,i])) {
      #       alpharet[last,i] = 0
      #    }
      # }
     
     alpharet =   retctrbres[["return"]]
     if(is.character(benchmark)){
          bmkret = returnsToXts(benchmark)
     }  else {
          bmkret = benchmark
     }
     
     if(index(bmkret)[nrow(bmkret)] < end_){
          warning(paste(benchmark,"doesnt have returns available for",as.character(end_),"for",sigName,". Adding a dummy"))
          temp = xts(as.numeric(0), end_)
          colnames(temp) = colnames(bmkret)
          bmkret = rbind(bmkret,temp)
     }
     
     bmkret = bmkret[index(alpharet)]
     alpharet = alpharet[index(bmkret)]
     
     bmkret = vectorToXtsMatrix(bmkret, ncol(alpharet))  
     colnames(bmkret) = colnames(alpharet)
     
     # need to scale fees according to signalWt/weightInCalling
     # because the weightInCalling, coming from attribution weights
     # sums to above 1, so when we calculate contribution as ret * weight
     # we are multiplying the fees part by a number above 1, and attribution won't match
     defwt = datToXts(res, "signal","date","signal_timing_wt")
     attrbwt = retctrbres[["weight"]]
     
     scalingbmk = defwt/attrbwt
     # if attrbwt is 0, then scalingbmk will be Inf, need to replace with 0
     scalingbmk[!is.finite(scalingbmk)] = 1
     totwt = xts(rowSums(abs(attrbwt[,setdiff(colnames(attrbwt),c(sigName,"Total"))])),index(attrbwt))
     #totwt = eval(paste0("totwt$",sigName," <- 1"))
     if(any(scalingbmk > (1 + DiffTolerance))) stop("signalAttributionResults error: scaling bmk factor should never be above 1")
     
     currBeta = alpharet
     currBeta[,] = NA
     
     if(beta_adjust_bmk){

          if(is.null(rollBetaLength)){
               # if the rollBetaLength is NULL, then will use full sample beta
               currBeta[,] = coef(lm(alpharet[,sigName] ~ bmkret[,sigName]))[2]

          } else {
               # loop over time
               for(mytime in (rollBetaLength+1):nrow(alpharet)){

                    currBeta[mytime,] = 
                         coef(lm(alpharet[(mytime - rollBetaLength):(mytime-1),sigName] ~ 
                                      bmkret[(mytime - rollBetaLength):(mytime-1),sigName]))[2]
                    
               }
               
               # the first 1 to rollBetaLength -1 entries will have NA in the beta
               # will fill it with the first observation
               
               currBeta = na.locf(currBeta, fromLast = T)
          }
          


          alpharet =  alpharet - bmkret * currBeta * scalingbmk
          
          returnres[["Beta"]] = currBeta
          
          alphactrbres = calcCtrb(res, alpharet,sigName)
          
          returnres[["Alpha"]] = alphactrbres[["return"]]
          returnres[["Alpha %tile"]] = alphactrbres[["return pctile"]]
          
          returnres[["Ctrb to Alpha"]]  = alphactrbres[["contribution"]]
          returnres[["Ctrb to Alpha %tile"]]  = alphactrbres[["contribution percentile"]]
          
     } else {
  

          currBeta[,] = 1
          returnres[["Alpha"]] = (alpharet) - (bmkret)
          returnres[["Alpha %tile"]]  = calcGrowingPctile(returnres[["Alpha"]] , 12)
          returnres[["Ctrb to Alpha"]] = (retctrbres[["contribution"]])-(bmkret*(abs(attrbwt)/as.numeric(totwt)))
          #returnres[["Ctrb to Alpha"]][,"Total"] = returnres[["Alpha"]][,"Total"]
          returnres[["Ctrb to Alpha %tile"]]  = calcGrowingPctile(returnres[["Ctrb to Alpha"]] , 12)
          returnres[["Beta"]] = currBeta
     }
          
     
     return(returnres)
}



# mySigName = "ALL_DYNAMIC_GLOBAL_MACRO"
# mySignalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
# maxLevel = 2
# myalloc = NULL
# mybenchmark = "SPY"
# my_beta_adjust_bmk = F
# myRollBetaLength = 36
# mystart = as.yearmon("Apr 2004")
# myend = as.yearmon("Jun 2016")
# myfees = 0

createSingleAttributionReport = function(mySigName, mybenchmark = NULL, mystart, myend,
                                         mySignalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_", 
                                         maxLevel = 2, myalloc = NULL, my_beta_adjust_bmk = F, 
                                         myRollBetaLength = NULL, myfees = NULL, scaleFactor=NULL){
     
     if(is.null(mybenchmark)) stop("createSingleAttributionReport error: benchmark can't be NULL")
     
     repFees = NULL
     if ((is.null(scaleFactor)) & (!is.null(myfees)) & ("all_fees" %in% names(myfees))) {
        scaleFactor = xts(rep(1, length(myfees[["all_fees"]])), index(myfees[["all_fees"]]))
        repFees = myfees[["all_fees"]]
     } else if (!is.null(scaleFactor)) {
        scaleFactor = scaleFactor[index(myfees[["all_fees"]]),]
        repFees = myfees[["all_fees"]]*scaleFactor
     }
     
     attrbres = signalAttributionResults(sigName = mySigName, signalLocation = mySignalLocation, 
                                         maxLevel = maxLevel, myalloc = myalloc, 
                                         benchmark = mybenchmark, beta_adjust_bmk = my_beta_adjust_bmk, 
                                         rollBetaLength = myRollBetaLength, myfees = repFees,
                                         start_ = mystart, end_ = myend)
     
     

     if(setToDate(max(sapply(attrbres,function(x){max(index(x))})), attrbres[[1]]) < myend){
          warning(paste(as.character(myend),"isn't available in returns for some signal in",mySigName))
     }
     
     attrrep = sapply(names(attrbres),function(name){
          SubsetDates_xts(attrbres[[name]], myend, myend)
     })
     
     betainfo = unique(attrrep[,"Beta"])
     attrrep = attrrep[,setdiff(colnames(attrrep), "Beta")]
     
     attrrepordering = portfolioNameMap[rownames(attrrep),.(signal, format_rank)]
     setorder(attrrepordering,format_rank, na.last = T)
     attrrepordering = data.frame(attrrepordering, stringsAsFactors = F)
     # need to set order of attrrep to ensure that mySigName is at the bottom
     # set Risk_Timing at second to last
     
     attrrep = attrrep[attrrepordering[, "signal"],]
  
     # sum up weight columns
     #attrrep["Total",grepl("Weight",colnames(attrrep))] = 
     #     apply(attrrep[1:(which(rownames(attrrep) == "Total")-1),grepl("Weight",colnames(attrrep))], 2,function(x){sum(abs(x))})

     
     attrrepnames = rownames(attrrep)
     attrrepnames[attrrepnames == "Total"] = mySigName
     attrrep = apply(attrrep,2, toPct)
     rownames(attrrep) = attrrepnames
      
     timingcols = c("Timing Weight","Ctrb to Timing")
     for (i in rownames(attrrep)) {
        for (y in timingcols) {
            if ((attrrep[i,"Timing Weight"] == "0%") | (attrrep[i,"Timing Weight"] == "")) {
                attrrep[i,y] = ""
                attrrep[i,(paste0(y," %tile"))] = ""
            }
        }
     }
     # set %tile columns to only have %tile name
     colnames(attrrep)[grepl("%tile", colnames(attrrep))] = "%tile"
     
     # attrrep[c(mySigName), grepl("Contribution", colnames(attrrep))] = ""
     # attrrep[c(mySigName), "Weight w. Netting"] = ""
     # attrrep[c(mySigName), "Default Weight"] = ""
     # attrrep[c(mySigName), "Timing Weight"] = ""
     # attrrep["Risk_Timing","Contribution to Returns"] = ""
     # attrrep["Risk_Timing","Contribution to Alpha"] = ""
     # attrrep["Risk_Timing", "Alpha"] = ""
     # attrrep["Risk_Timing", "Alpha %tile"] = ""
     
    
     # attrrep[grepl("residual",rownames(attrrep)), "Alpha"] = ""
     
     # rownames(attrrep)[grepl("residual",rownames(attrrep))] = "Timing and Netting"

     # colnames(attrrep)[grepl("^Alpha$",colnames(attrrep))] = paste("Alpha Against",toupper(gsub("_index","",mybenchmark)))
     bmktemp = returnsToXts(mybenchmark)
     if (myend %in% index(bmktemp)) {
        bmktemp =as.numeric(bmktemp[myend,mybenchmark])
     } else {
        bmktemp =0
     }
     numAddColumns = 7
     numAddColumns2 = 8
     emptyLine = rep("", ncol(attrrep))
     calculationMapping = c("1","2","3","4","(4-3)","%tile 4-3","(4 - 3) * 1","(%tile (4 - 3) * 1","5","(1 * 5)","%tile 1 * 5","1 - Bmk Return","% 1 - Bmk Return","(1 - Bmk Return) * 5","%tile (1 - Bmk Return) * 5")
     attrrep = rbind( c("Portfolio Name","Slippage, Commission & Fees","Performance During","Bmk","Bmk Return","Bmk Beta", "Beta Adjusted Bmk Return",rep("",ncol(attrrep)-numAddColumns)),
                      c(mySigName, toPct(repFees[as.yearmon(myend),1]),as.character(myend), toupper(mybenchmark), toPct(bmktemp),round(betainfo,2), toPct(bmktemp * betainfo),rep("",ncol(attrrep)-numAddColumns)),
                      emptyLine,
                      c("","Res.Slippage", "Exec.Slippage","Commission","LongOnly constraint","Small Trade filter","Tax harvest","Fees",rep("",ncol(attrrep)-numAddColumns2)),
                      c("", toPct((myfees[["slippage"]]*scaleFactor)[as.yearmon(myend),1]),toPct((myfees[["execution"]]*scaleFactor)[as.yearmon(myend),1]), toPct((myfees[["commission"]]*scaleFactor)[as.yearmon(myend),1]), 
                      toPct((myfees[["lo_constraint"]]*scaleFactor)[as.yearmon(myend),1]),toPct((myfees[["st_filter"]]*scaleFactor)[as.yearmon(myend),1]),toPct((myfees[["tax_aware"]]*scaleFactor)[as.yearmon(myend),1]),
                      toPct((myfees[["fee"]]*scaleFactor)[as.yearmon(myend),1]),rep("",ncol(attrrep)-numAddColumns)),
                      emptyLine,
                      calculationMapping,
                      colnames(attrrep), 
                      attrrep[-nrow(attrrep),],
                      emptyLine,
                      attrrep[nrow(attrrep),],
                      emptyLine,
                      emptyLine)

     rownames(attrrep)[grepl("emptyLine", rownames(attrrep))] = ""
     rownames(attrrep)[1] = "Attribution Setup"
     rownames(attrrep)[4] = "Slippages Costs &  Fees"
     rownames(attrrep)[nrow(attrrep)-2] = mySigName
     return(attrrep)
}


createSingleAttributionReportNew = function(mySigName, mybenchmark = NULL, mystart, myend,
                                         mySignalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_", 
                                         maxLevel = 2, myalloc = NULL, my_beta_adjust_bmk = F, 
                                         myRollBetaLength = NULL, myfees = NULL, scaleFactor=NULL,
										 productWeight=NULL, leverage = 1.0){
     
     if(is.null(mybenchmark)) stop("createSingleAttributionReport error: benchmark can't be NULL")
     
     repFees = NULL
     if ((is.null(scaleFactor)) & (!is.null(myfees)) & ("all_fees" %in% names(myfees))) {
        scaleFactor = xts(rep(1, length(myfees[["all_fees"]])), index(myfees[["all_fees"]]))
        repFees = myfees[["all_fees"]]/leverage
     } else if (!is.null(scaleFactor)) {
        scaleFactor = scaleFactor[index(myfees[["all_fees"]]),]
        repFees = myfees[["all_fees"]]*scaleFactor/leverage
     }

	 lev_xts = NULL
	 if ((!is.null(myfees)) & ("all_fees" %in% names(myfees))) {
        lev_xts = xts(rep(leverage, length(myfees[["all_fees"]])), index(myfees[["all_fees"]]))
	 }
	 
     attrbres = signalAttributionResults(sigName = mySigName, signalLocation = mySignalLocation, 
                                         maxLevel = maxLevel, myalloc = myalloc, 
                                         benchmark = mybenchmark, beta_adjust_bmk = F, 
                                         rollBetaLength = NULL, myfees = repFees,
                                         start_ = mystart, end_ = myend, productWeight = productWeight, myLev = lev_xts)
     
     

     if(setToDate(max(sapply(attrbres,function(x){max(index(x))})), attrbres[[1]]) < myend){
          warning(paste(as.character(myend),"isn't available in returns for some signal in",mySigName))
     }
	 
	 # if (!is.null(repFees)) {
	     # names(repFees) = c("fee")
         # attrbres[["fees"]] = repFees
	 # }
     return(attrbres)
}


createAttributionReportNew = function(reportparameters, sigName, mystart, myend,
                                   signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_", 
                                   maxLevel = 2, myalloc = NULL, beta_adjust_bmk = F, 
                                   rollBetaLength = NULL, myfees = NULL){
     
     bond_names = c("BONDS_EM","CREDIT_US_CREDIT_RISK","CREDIT_US_CREDIT_RISK_SPY","TREASURIES_US")
	 
	 reportparameters[,1] = as.character(reportparameters[,1])
     reportparameters[,2] = as.character(reportparameters[,2])
     
     myscale = NULL
     timingwt = createFileWeights(signalLocation, sigName, NULL, "wt_adj.csv")
     attrbwt = createFileWeights(signalLocation, sigName, NULL,  "attribution_weights.csv")
	 
     if ((!is.null(timingwt)) & (!is.null(attrbwt))) {
         common_months = getCommonMonths(timingwt, attrbwt)
         common_cols   = intersect(colnames(attrbwt),colnames(timingwt))
         timingwt = timingwt[common_months,common_cols]
         attrbwt  = attrbwt[common_months,common_cols]
		 
		 timingwt = cbind(timingwt, xts(rowSums(timingwt[,bond_names]), index(timingwt)))
		 names(timingwt)[length(names(timingwt))] = ifelse(sigName=="ALL_DYNAMIC_GLOBAL_MACRO","BONDS_DYNAMIC","BONDS")
		 
		 attrbwt = cbind(attrbwt, xts(rowSums(attrbwt[,bond_names]), index(attrbwt)))
		 names(attrbwt)[length(names(attrbwt))] = ifelse(sigName=="ALL_DYNAMIC_GLOBAL_MACRO","BONDS_DYNAMIC","BONDS")
		 
         myscale = timingwt/attrbwt
         myscale = na.fill(myscale,1)
		 
     }
     
     reportres = lapply(reportparameters[,"signal"],function(x){
          # x = reportparameters[,"signal"][4]
          print(paste(x, reportparameters[reportparameters[,"signal"] == x,"benchmark"]))

          createSingleAttributionReportNew(x, 
                                        mybenchmark = reportparameters[reportparameters[,"signal"] == x,"benchmark"], mystart, myend,
                                        signalLocation, 
                                        maxLevel, if(x == sigName) {myalloc} else  {NULL}, beta_adjust_bmk, 
                                        rollBetaLength, myfees = myfees, scaleFactor = if((x == sigName) | !(x %in% colnames(myscale))) {NULL} else {myscale[,x]},
										productWeight =  if((x == sigName) | !(x %in% colnames(attrbwt))) {xts(rep(1,nrow(attrbwt)), index(attrbwt))} else {attrbwt[,x]})
     })

     names(reportres) = reportparameters[,"signal"]
	 
	 attrrepall = lapply(names(reportres), function(x) {
	      attrbres = reportres[[x]]
	      attrreptemp = sapply(names(attrbres),function(name){
              SubsetDates_xts(attrbres[[name]], myend, myend)
          })
		  return(attrreptemp)
	 
	 })
	 names(attrrepall) = reportparameters[,"signal"]
	 
	 repall = lapply(names(attrrepall), function(x){
	     scaleFactor = ifelse(((x == sigName) | !(x %in% colnames(myscale))), xts(rep(1, length(myfees[["all_fees"]])), index(myfees[["all_fees"]])), myscale[,x])
		 mybenchmark = reportparameters[reportparameters[,"signal"] == x,"benchmark"]
	     attrrep = attrrepall[[x]]
		 betainfo = unique(attrrep[,"Beta"])
		 attrrep = attrrep[,setdiff(colnames(attrrep), "Beta")]
		 
		 attrrepordering = portfolioNameMap[rownames(attrrep),.(signal, format_rank)]
		 setorder(attrrepordering,format_rank, na.last = T)
		 attrrepordering = data.frame(attrrepordering, stringsAsFactors = F)
		 # need to set order of attrrep to ensure that mySigName is at the bottom
		 # set Risk_Timing at second to last
		 
		 attrrep = attrrep[attrrepordering[, "signal"],]


		 
		 attrrepnames = rownames(attrrep)
		 attrrepnames[attrrepnames == "Total"] = x
		 attrrep = apply(attrrep,2, toPct)
		 rownames(attrrep) = attrrepnames
		  
		 timingcols = c("Timing Weight","Ctrb to Timing")
		 for (i in rownames(attrrep)) {
			for (y in timingcols) {
				if ((attrrep[i,"Timing Weight"] == "0%") | (attrrep[i,"Timing Weight"] == "")) {
					attrrep[i,y] = ""
					attrrep[i,(paste0(y," %tile"))] = ""
				}
			}
		 }
		 # set %tile columns to only have %tile name
		 colnames(attrrep)[grepl("%tile", colnames(attrrep))] = "%tile"
		 
		 bmktemp = returnsToXts(mybenchmark)
		 if (myend %in% index(bmktemp)) {
			bmktemp =as.numeric(bmktemp[myend,mybenchmark])
		 } else {
			bmktemp =0
		 }
		 numAddColumns = 7
		 numAddColumns2 = 8
		 emptyLine = rep("", ncol(attrrep))
		 calculationMapping = c("1","2","3","4","(4-3)","%tile 4-3","(4 - 3) * 1","(%tile (4 - 3) * 1","5","","(1 * 5)","%tile 1 * 5","","1 - Bmk Return","% 1 - Bmk Return","(1 - Bmk Return) * 5","%tile (1 - Bmk Return) * 5")
		 if (x == sigName) {
			 attrrep = rbind( c("Portfolio Name","Slippage, Commission & Fees","Performance During","Bmk","Bmk Return","Bmk Beta", "Beta Adjusted Bmk Return",rep("",ncol(attrrep)-numAddColumns)),
							  c(x, toPct((myfees[["all_fees"]]*scaleFactor)[as.yearmon(myend),1]), as.character(myend), toupper(mybenchmark), toPct(bmktemp),round(betainfo,2), toPct(bmktemp * betainfo),rep("",ncol(attrrep)-numAddColumns)),
							  emptyLine,
							  c("","Res.Slippage", "Exec.Slippage","Commission","LongOnly constraint","Small Trade filter","Tax harvest","Fees",rep("",ncol(attrrep)-numAddColumns2)),
							  c("", toPct((myfees[["slippage"]]*scaleFactor)[as.yearmon(myend),1]),toPct((myfees[["execution"]]*scaleFactor)[as.yearmon(myend),1]), toPct((myfees[["commission"]]*scaleFactor)[as.yearmon(myend),1]), 
							  toPct((myfees[["lo_constraint"]]*scaleFactor)[as.yearmon(myend),1]),toPct((myfees[["st_filter"]]*scaleFactor)[as.yearmon(myend),1]),toPct((myfees[["tax_aware"]]*scaleFactor)[as.yearmon(myend),1]),
							  toPct((myfees[["fee"]]*scaleFactor)[as.yearmon(myend),1]),rep("",ncol(attrrep)-numAddColumns)),
							  emptyLine,
							  calculationMapping,
							  colnames(attrrep), 
							  attrrep[-nrow(attrrep),],
							  emptyLine,
							  attrrep[nrow(attrrep),],
							  emptyLine,
							  emptyLine)

			 rownames(attrrep)[grepl("emptyLine", rownames(attrrep))] = ""
			 rownames(attrrep)[1] = "Attribution Setup"
			 rownames(attrrep)[4] = "Slippages Costs &  Fees"
		 } else {
			 attrrep = rbind( c("Portfolio Name","Slippage, Commission & Fees","Performance During","Bmk","Bmk Return","Bmk Beta", "Beta Adjusted Bmk Return",rep("",ncol(attrrep)-numAddColumns)),
							  c(x, toPct((myfees[["all_fees"]]*scaleFactor)[as.yearmon(myend),1]), as.character(myend), toupper(mybenchmark), toPct(bmktemp),round(betainfo,2), toPct(bmktemp * betainfo),rep("",ncol(attrrep)-numAddColumns)),
							  emptyLine,
							  emptyLine,
							  calculationMapping,
							  colnames(attrrep), 
							  attrrep[-nrow(attrrep),],
							  emptyLine,
							  attrrep[nrow(attrrep),],
							  emptyLine,
							  emptyLine)

			 rownames(attrrep)[grepl("emptyLine", rownames(attrrep))] = ""
			 rownames(attrrep)[1] = "Attribution Setup"
			 }
		 rownames(attrrep)[nrow(attrrep)-2] = x
		 return(attrrep)
		 
		})

	 reportreswithadd = do.call(rbind, repall)
	 return(reportreswithadd)
	 
}

# reportparameters = dynparameters
# sigName = "ALL_DYNAMIC_GLOBAL_MACRO"
# mystart = as.yearmon("Apr 2004")
# myend = as.yearmon("Jun 2016")
# signalLocation = filebase
# maxLevel = 2
# beta_adjust_bmk = F
# rollBetaLength = NULL
# myalloc = NULL
# myfees = dyn_fees

createAttributionReport = function(reportparameters, sigName, mystart, myend,
                                   signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_", 
                                   maxLevel = 2, myalloc = NULL, beta_adjust_bmk = F, 
                                   rollBetaLength = NULL, myfees = NULL){
     
     reportparameters[,1] = as.character(reportparameters[,1])
     reportparameters[,2] = as.character(reportparameters[,2])
     
     myscale = NULL
     timingwt = createFileWeights(signalLocation, sigName, NULL, "wt_adj.csv")
     attrbwt = createFileWeights(signalLocation, sigName, NULL,  "attribution_weights.csv")
     if ((!is.null(timingwt)) & (!is.null(attrbwt))) {
         common_months = getCommonMonths(timingwt, attrbwt)
         common_cols   = intersect(colnames(attrbwt),colnames(timingwt))
         timingwt = timingwt[common_months,common_cols]
         attrbwt  = attrbwt[common_months,common_cols]
         myscale = timingwt/attrbwt
         myscale = na.fill(myscale,1)
     }
     
     reportres = lapply(reportparameters[,"signal"],function(x){
          # x = reportparameters[,"signal"][4]
          print(paste(x, reportparameters[reportparameters[,"signal"] == x,"benchmark"]))

          createSingleAttributionReport(x, 
                                        mybenchmark = reportparameters[reportparameters[,"signal"] == x,"benchmark"], mystart, myend,
                                        signalLocation, 
                                        maxLevel, if(x == sigName) {myalloc} else  {NULL}, beta_adjust_bmk, 
                                        rollBetaLength, myfees = myfees, scaleFactor = if((x == sigName) | !(x %in% colnames(myscale))) {NULL} else {myscale[,x]})
     })

     names(reportres) = reportparameters[,"signal"]
     
     colsToAddCtrbInfo = c(
                              # grep("^Risk Timing$", colnames(reportres[[1]])) + 1,
                              #grep("^Ctrb to Timing$", colnames(reportres[[1]])) + 1, # add 1 because %tile follows it
                              grep("^Weight w. Netting$", colnames(reportres[[1]])),
                              grep("^Ctrb to Returns$", colnames(reportres[[1]])) + 1 ) # add 1 because %tile follows it
     
     
     # want to add to the report weight in product, and contribution to product
     # want to add columns after the %tile column
     reportreswithadd = lapply(names(reportres), function(x){
     print(x)
          emptycol = rep("", nrow(reportres[[x]]))

          productWeightCol = "Weight w. Netting"
          
          # get weight in product
          xproductweight = reportres[[sigName]][x,productWeightCol]
          xproductweight = fromPct(xproductweight)
          
          # am using Weight w. Netting
          # Sums to above 1, if we are looking up the product, then the contribution numbers
          # already are calculated using Weight w. Netting, so need to set weight at 1
          if(sigName == x){
               xproductweight = 1
          }
          
          #  we need to add rows to accommodate the weights in product
          # and contribution to product returns
          temprep = reportres[[x]]

          for(i in 1:length(colsToAddCtrbInfo)){
               
               if(i == 1){
                    temprepadj = cbind(temprep[,1:colsToAddCtrbInfo[i]], emptycol)
                    
               } else {
                    temprepadj = cbind(temprepadj, temprep[,(colsToAddCtrbInfo[i-1] + 1):colsToAddCtrbInfo[i]], emptycol) 
                    # need to set the column name if we are picking out only a 1 column
                    # R will convert 1 column into vector and removing the column name
                    if(length((colsToAddCtrbInfo[i-1] + 1):colsToAddCtrbInfo[i]) == 1){
                         colnames(temprepadj)[ncol(temprepadj)-1] = colnames(temprep)[(colsToAddCtrbInfo[i-1] + 1)]
                    }
               }
               
               # pickout the column name and information
               
               if(colnames(temprep)[colsToAddCtrbInfo[i] - 1] != "%tile"){
                    # the column we want to add weight * column information
                    colinfo = temprep[,colsToAddCtrbInfo[i] - 1]
                    
                    # the column name we care about
                    colname = colnames(temprep)[colsToAddCtrbInfo[i] - 1]
                    
               } else {
                    # the column we want to add weight * column information
                    colinfo = temprep[,colsToAddCtrbInfo[i]]
                    
                    # the column name we care about
                    colname = colnames(temprep)[colsToAddCtrbInfo[i]]
                    
               }
               
               # find where the data starts, as there is a row above results with
               # attribution setup information
               datastart = 1 + which(colinfo == colname)
               
               
               # need to populate that column that was added

               # the information we will add to the results
               addInfo = fromPct(colinfo[datastart : length(colinfo)]) * xproductweight
               
               ###################################################################
               # Error check that sum of addInfo matches the product information #
               ###################################################################
               
               # Risk timing happens at 1 signal level higher, therefore the subsignals might
               # not have any risk timing, but the signal still has contribution in parent signal
               # don't do error check if the column has Risk Timing in the name
               if(!grepl("Risk Timing", colname)){
                    #if (is.na(fromPct(reportres[[sigName]][x,colname]))) prodlevel=0 fromPct(reportres[[sigName]][x,colname])
                    
                    # divide sum addInfo by 2 as the sum includes the signal itself,
                    # it has sub signals, and signal, therefore will sum up to double
                    
                    # allow 2 bps difference as we are working with numbers rounded to bps
                    if(abs(fromPct(reportres[[sigName]][x,colname]) - sum(if(x == "ABS_RETURN_PORTFOLIO" & colname == productWeightCol) {abs(addInfo)} else {abs(addInfo)},na.rm = T)/2) > 0.0002 ){
                         if(x == "ABS_RETURN_PORTFOLIO" & colname == productWeightCol){ 
                              # product weight column, "Weight w. Netting" won't match for signals that have netting and are scaled up
                              
                         } else {
                              warning(paste("Product information doesn't match for", colname, "for signal", x,"in product",sigName)) 
                         }
                              
                    }

               }

               
               addInfo = toPct(addInfo)
               # some columns will be NA, and toPct will cause it to be NA%
               # will turn NA% into empty string ""
               addInfo[addInfo == "NA%"] = ""
               
               temprepadj[datastart : length(colinfo),ncol(temprepadj)] = addInfo
                    
               # }
               
               colnames(temprepadj)[ncol(temprepadj)] = paste("Product", colname) 
               
               temprepadj[datastart-1,ncol(temprepadj)] = paste("Product", colname) 
               
               
          }
          
          # need to add columns after last empty line insert
          
          temprepadj = cbind(temprepadj, temprep[,(colsToAddCtrbInfo[i] + 1):ncol(temprep)])
  
          return(temprepadj)
     })
     
     reportreswithadd = do.call(rbind, reportreswithadd)
     
     reportreswithadd = reportreswithadd[-((nrow(reportreswithadd)-1):nrow(reportreswithadd)),]
     return(reportreswithadd)
}


formatAttributionReport = function(x,nameMap = if(exists("portfolioNameMap")) {portfolioNameMap} else {NULL}){
     
     if(!is.null(nameMap)){
          # Replace signal names with portfolio names
          rownames(x) = ifelse( is.na(nameMap[rownames(x),name]),rownames(x),nameMap[rownames(x),name])
          # replace any entries with portfolio names 
          for(i in 1:ncol(x)){
               x[,i] = ifelse( is.na(nameMap[x[,i],name]),x[,i],nameMap[x[,i],name])
          }
     }
     
     # Remove EQUITIES_ from rownames
     # rownames(x) = gsub("^EQUITIES_","",rownames(x))
     
     ## Remove everything else from names with SAFETY, VALUE, TRUE_BETA_, MOMENTUM
     # for(i in c("SAFETY$", "VALUE$", "TRUE_BETA$", "MOMENTUM$")){
     #      rownames(x)[grepl(i,rownames(x))] = gsub("[$]","",i) # removing the $ from the end
     # }
     
     return(x)
}

formatAttributionReportAndWrite = function(x, name, 
          nameMap = if(exists("portfolioNameMap")) {portfolioNameMap} else {NULL}){
     
     x = formatAttributionReport(x, nameMap)
     write.table(x,paste(name,"research attribution.csv"), sep = ",",col.names = F)
}



# portfolioNameMap
# A map from signal names to formal product names
portfolioNameMap = fread("C:/local_quant_qsf/Quant/qsf_etf/TRADING/portfolio_nice_names_mapping.csv")
portfolioNameMap[, portfolio_introduction := as.yearmon(gsub('"','',portfolio_introduction))]
setkey(portfolioNameMap, signal)

portfolioStyleMap = fread("C:/local_quant_qsf/Quant/qsf_etf/TRADING/portfolio_style_map.csv")
portfolioStyleMap[, signalname := toupper(signalname)]
setkey(portfolioStyleMap, signalname)


# calcRollingPctile
# Calculates a rolling %tile of a variable

calcRollingPctile = function(myVar, myPctileWindowLength, myRequireFullData){
     
     if(myRequireFullData){
          myVar = na.omit(myVar)
     } else {
          # remove first entries that have no data because burn in for rolling calculation
          myVar = myVar[rowSums(is.na(myVar)) < (ncol(myVar)/2)]
     }
     
     
     rollpctile = xts(rollapplyr(index(myVar), myPctileWindowLength, function(mydate){
          mydate = setToDate(mydate, myVar)
          
          apply(myVar[mydate,],2,function(x){
               ecdf(x)(x[length(x)])
          })
     }, fill = NA), index(myVar))
     
     return(rollpctile)
}


# createMSITable
# Used in the equity region and equity bond MSI signals to summarize current month's information
# Has no use outside that, is used in at least 5 different scripts, hence the function
createMSITable = function(sigName = "", myDate, usraw = NULL, ussig = NULL, 
                          eaferaw = NULL, eafesig = NULL, emraw = NULL, emsig = NULL){
     
     if(!is.null(usraw)) {
          usraw = as.numeric(usraw[myDate])
     } else {
          usraw = NA
     }
     
     if(!is.null(ussig)) {
          ussig = as.numeric(ussig[myDate])
     } else {
          ussig = NA
     }
     
     if(!is.null(eaferaw)) {
          eaferaw = as.numeric(eaferaw[myDate])
     } else {
          eaferaw = NA
     }
     
     if(!is.null(eafesig)) {
          eafesig = as.numeric(eafesig[myDate])
     } else {
          eafesig = NA
     }
     
     if(!is.null(emraw)) {
          emraw = as.numeric(emraw[myDate])
     } else {
          emraw = NA
     }
     
     if(!is.null(emsig)) {
          emsig = as.numeric(emsig[myDate])
     } else {
          emsig = NA
     }
     
     
     res = data.frame("Raw" = c(usraw, eaferaw, emraw), "Signal" = c(ussig, eafesig, emsig))
     colnames(res) = c(paste(sigName,"Raw"), paste(sigName,"Signal"))
     rownames(res) = c("US","EAFE","EM")
     return(res)
}




# summarize3PartAttributionSingle
# Reads in the return and volatility attribution and combines in a single data.frame
summarize3PartAttributionSingle = function(fileNames, fileTypes, headerName, betaName){
     
     
     retres = read.csv(paste(fileNames,fileTypes[1]), check.names = F, stringsAsFactors = F)
     names(retres)[grepl("Beta",names(retres))] = betaName
     retres[1,1] = headerName[1]
     retres = rbind(names(retres),retres)
     colnames(retres) = NA
     # add a title row that says returns, alpha against ...
     retres = rbind( c( "", gsub("Contribution to ","", headerName[1]), rep("", ncol(retres)-2)),
                     retres)
     
     
     volres = read.csv(paste(fileNames,fileTypes[2]), check.names = F, stringsAsFactors = F)
     names(volres)[grepl("Beta",names(volres))] = betaName
     volres[1,1] = headerName[2]
     volres = rbind(names(volres),volres)
     colnames(volres) = NA
     # add a title row that says returns, alpha against ...
     volres = rbind( c( "", gsub("Contribution to ","", headerName[1]), rep("", ncol(volres)-2)),
                     volres)
     
     
     # add then next to each other on same lines
     # filler = retres[,1]
     # filler[] = ""
     # 
     # res = cbind( retres, filler, volres)
     # colnames(res)[c(1,ncol(retres) + 1, ncol(retres) + 2)] = ""
     
     
     filler = retres[1,]
     filler[] = ""
     res = rbind( retres, filler, volres, filler)
     
     # set column names to be empty spaces
     # column names need to be unique, so have column 1 be 1 space, column 2 be 2 spaces etc
     colnames(res) = (sapply(1:ncol(res),function(x){paste0(rep(" ",x), collapse = "")}))
     
     
     res = 
          
          # nameadder = res[1,]
          # nameadder[] = ""
          # 
          # nameadder[1] = headerName[1]
          # nameadder[ncol(retres)+2] = headerName[2]
          
          # res = rbind(nameadder, res)
          
          return(res)
}

# summarize3PartAttributionProduct
# Uses summarize3PartAttributionSingle to summarize attribution results for our products

summarize3PartAttributionProduct = function(){
     
     
     #################
     # Dynamic Macro #
     #################
     
     dynretctrb = summarize3PartAttributionSingle(fileNames = "attribution - Dynamic macro", 
                                                  fileTypes = c("return attribution.csv","volatility attribution.csv"), 
                                                  headerName = c("Contribution to Returns","Contribution to Portfolio Volatility"), 
                                                  betaName = c("60/40"))
     
     
     
     dynalphactrb6040 = summarize3PartAttributionSingle(fileNames = "attribution - Dynamic macro alpha 6040", 
                                                        fileTypes = c("return attribution.csv","volatility difference attribution.csv"), 
                                                        headerName = c("Contribution to Alpha vs 60/40","Contribution to Volatility Difference vs 60/40"), 
                                                        betaName = c("60/40"))
     
     
     dynalphactrb6040hfrx = summarize3PartAttributionSingle(fileNames = "attribution - Dynamic macro alpha 6040 hfrx", 
                                                            fileTypes = c("return attribution.csv","volatility difference attribution.csv"), 
                                                            headerName = c("Contribution to Alpha vs 65% 60/40 35% HFRX AR","Contribution to Volatility Difference vs 65% 60/40 35% HFRX AR"), 
                                                            betaName = c("65% 60/40 35% HFRX AR"))
     
     fillerline = rep("", ncol(dynretctrb))
     
     dynres = rbind( dynretctrb,
                     fillerline,
                     dynalphactrb6040,
                     fillerline,
                     dynalphactrb6040hfrx,
                     fillerline)
     
     write.csv(dynres,"Dynamic Macro Attribution results.csv", row.names = F)
     
     
     
     ##################
     # Enhanced Macro #
     ##################
     
     enretctrb = summarize3PartAttributionSingle(fileNames = "attribution - Enhanced macro", 
                                                 fileTypes = c("return attribution.csv","volatility attribution.csv"), 
                                                 headerName = c("Contribution to Returns","Contribution to Portfolio Volatility"), 
                                                 betaName = c("60/40"))
     
     
     
     enalphactrb6040 = summarize3PartAttributionSingle(fileNames = "attribution - Enhanced macro alpha 6040", 
                                                       fileTypes = c("return attribution.csv","volatility difference attribution.csv"), 
                                                       headerName = c("Contribution to Alpha vs 60/40","Contribution to Volatility Difference vs 60/40"), 
                                                       betaName = c("60/40"))
     
     
     enalphactrb6040hfrx = summarize3PartAttributionSingle(fileNames = "attribution - Enhanced macro alpha 6040 hfrx", 
                                                           fileTypes = c("return attribution.csv","volatility difference attribution.csv"), 
                                                           headerName = c("Contribution to Alpha vs 65% 60/40 35% HFRX AR","Contribution to Volatility Difference vs 65% 60/40 35% HFRX AR"), 
                                                           betaName = c("65% 60/40 35% HFRX AR"))
     
     fillerline = rep("", ncol(enretctrb))
     
     enres = rbind( enretctrb,
                    fillerline,
                    enalphactrb6040,
                    fillerline,
                    enalphactrb6040hfrx,
                    fillerline)
     
     write.csv(enres,"Enhanced Macro Attribution results.csv", row.names = F)
     
     
     
     #####################
     # Global Allocation #
     #####################
     
     
     gaalphactrb6040 = summarize3PartAttributionSingle(fileNames = "attribution - Global allocation", 
                                                       fileTypes = c("return attribution.csv","volatility difference attribution.csv"), 
                                                       headerName = c("Contribution to Alpha vs 60/40","Contribution to Volatility Difference vs 60/40"), 
                                                       betaName = c("60/40"))
     
     write.csv(gaalphactrb6040,"Global Allocation Attribution results.csv", row.names = F)
     
     
     #################
     # Global Equity #
     #################
     
     gealphactrbacwi = summarize3PartAttributionSingle(fileNames = "attribution - Global Equity alpha acwi", 
                                                       fileTypes = c("return attribution.csv","volatility difference attribution.csv"), 
                                                       headerName = c("Contribution to Alpha vs MSCI ACWI","Contribution to Volatility Difference vs MSCI ACWI"), 
                                                       betaName = c("MSCI ACWI"))
     
     write.csv(gealphactrbacwi,"Global Equity Attribution results.csv", row.names = F)
     
     
     print("Done writing attribution results to file")
}





# compareWeights
# Compares weights of two portfolios
# can take in xts weights, or signal IMP location
compareWeights = function(wt1, wt2, name = "", noMqaidAdjust=F, myWarningOnly=F){
     
     if(is.character(wt1)){
          wt1 = signalImpToXts(wt1)
     }
     # remove _backfilled from name, and the mqaidAdjustment
     # as these are still the same assets
     if (!noMqaidAdjust) {
         colnames(wt1) = gsub("_backfilled","", colnames(wt1))
         colnames(wt1) = gsub(mqaidAdjustment(),"", colnames(wt1))
     }
     if(is.character(wt2)){
          wt2 = signalImpToXts(wt2)
     }
     # remove _backfilled from name, and the mqaidAdjustment
     if (!noMqaidAdjust) {
         colnames(wt2) = gsub("_backfilled","", colnames(wt2))
         colnames(wt2) = gsub(mqaidAdjustment(),"", colnames(wt2))
    }
     wt1 = wt1[,apply(wt1, 2, function(x){any((x != 0 & !is.na(x)))})]
     wt2 = wt2[,apply(wt2, 2, function(x){any((x != 0 & !is.na(x)))})]
     #wt2 = wt2[,(colSums(wt2))!=0]

     if( length(setdiff2(colnames(wt1), colnames(wt2))) > 0  ){
          stop(paste("compareWeights error:", name,"Two portfolios have different holdings"))
          #warning(paste("compareWeights error:", name,"Two portfolios have different holdings"))
     }
     
     wt2 = wt2[,colnames(wt1)]
     
     #checkDifference(abs(as.numeric(round(wt1,4) - round(wt2,4))), 0, paste("compareWeights error:", name,"Two portfolios have different holdings"))
     checkDifference(abs(as.numeric(wt1 - wt2)), 0, paste("compareWeights error:", name,"Two portfolios have different holdings"), warningsOnly = myWarningOnly)
     
     return(paste("Weights match for",name))
}


# getSignalWeightAttribution
# Maps signal imp of a signal into contributions from each end signal
# end signal is lowest level signal
# sigName ="ALL_DYNAMIC_GLOBAL_MACRO"
# reportDate = as.yearmon("Sep 2016")
# weightChangeFocused = T
# signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
# rawReport = F
# keepSignalNames = F

getSignalWeightAttributionRaw = function(sigName, 
                                      reportDate, 
                                      weightChangeFocused = T,
                                      rawReport = F,
                                      keepSignalNames = F,
                                      signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_",
                                      addReturns = F){
     
     # get signal weight tree
     wt = getSignalWeightTree(sigName,signalLocation)
     
     setkey(wt, parent_signal, signal, signal_level, year_mon, ticker)
     
     res = parseSignalWeightTree(sigName,sigName,1, wt)
     
     ###################################################################
     # Error check comparing parsed weight tree results and signal imp #
     ###################################################################
     # browser()
     mysig = wt[.(sigName,sigName)]
     mysig = mysig[,.(year_mon, ticker, weight)]
     setkey(mysig, year_mon, ticker)
     
     res[, totval:=sum(value), keyby = .(ticker, year_mon)]
     res[, prop:= value/totval]
     res[, prop:= na.fill(prop,0)]
     setkey(res, year_mon, ticker, type)
     res=mysig[res]
     
     res[,weight:=na.fill(weight,0)]
     res[,value:= prop*weight]
     res[,prop:=NULL]
     res[,weight:=NULL]
     res[,totval:=NULL]
     
     resnet = res[, sum(value), keyby = .(ticker, year_mon)]
     resnet = datToXts(resnet, "ticker","year_mon","V1")
     resnet = na.fill(resnet, 0)
     sigimp = signalImpToXts( paste0(signalLocation, sigName,"/signal_IMP_M.csv") )
     colnames(sigimp) = mqaidToTicker(colnames(sigimp))
     
     # compareWeights(resnet, sigimp,sigName)
     
     # Done with error check
     
     
     ##################
     # Format results #
     ##################
     
     wt = wt[signal == sigName, .(year_mon, ticker, weight_change, rank_abs_weight_change, weight, weight_l1m)]
     
     setnames(res, "value","contribution_to_weight")
     
     setkey(wt, year_mon, ticker)
     setkey(res, year_mon, ticker)
     
     attrbwt = merge(wt, res, by = key(wt), all = T)
     attrbwt[,contribution_to_weight:=na.fill(contribution_to_weight,0)]
     attrbwt[is.na(type),type:=sigName]
     # remove the rows where there is no contribution to weight
     # means that signal didn't have the ETF
     
     if(weightChangeFocused){
          if(!rawReport){
               attrbwt = attrbwt[!(weight == 0 & weight_change == 0)] 
          }
          attrbwt[, abs_weight_change := abs(weight_change)]

     } else {
          if(!rawReport){
               attrbwt = attrbwt[!(contribution_to_weight == 0)]   
          }
          attrbwt[, abs_weight := abs(weight)]
          
     }
     
     
     
     
     ###################################################################
     # Final error check that contribution to weight sums up to weight #
     ###################################################################
     
     
     errorcheck = attrbwt[,list("weight" = weight,
                                "sum_ctrb" = sum(contribution_to_weight)), keyby = .(year_mon, ticker)]
     
     errorcheck = errorcheck[!(is.na(weight) & sum_ctrb==0),]
     # check that contribution to weight sums up to weight
     # errorcheck[, checkDifference(weight, sum_ctrb,"getSignalWeightAttribution error: contribution to weights don't sum up to weights")]
     
     errorcheck = unique(errorcheck, by = NULL)
     
     # check that weights sum up to signal imp weights
     errorcheck = na.fill(datToXts(errorcheck,"ticker","year_mon","weight"),0)
     
    # compareWeights(errorcheck, sigimp,sigName)
     
     
     #########################
     # Done with error check #
     #########################
     
     
     
     setkey(attrbwt, year_mon)
     # keep only the month we care about
     attrbwt = attrbwt[year_mon == reportDate]
    
    
    # SignalWeightAttribution: Now do custom splits ####
    emb = attrbwt[type=="BONDS_EM" & ticker=="emb",]
    if (nrow(emb)>0) {
        emb[,contribution_to_weight:=contribution_to_weight*0.2]
        emb[,type:="BONDS_EM_COR"]
        attrbwt[type=="BONDS_EM" & ticker=="emb",contribution_to_weight:=contribution_to_weight*0.8]
        attrbwt = rbind(attrbwt, emb)
        setkey(attrbwt, year_mon)
    }

    extract = attrbwt[((type %in% c("US_ADAALTS_5FACTORS","US_ADAALTS_9SECTORS"))),]
    if (nrow(extract)>0) {
        extract[,contribution_to_weight:=contribution_to_weight*0.333]
        attrbwt[((type %in% c("US_ADAALTS_5FACTORS","US_ADAALTS_9SECTORS"))),contribution_to_weight:=contribution_to_weight*0.334]
        attrbwt[((type %in% c("US_ADAALTS_5FACTORS","US_ADAALTS_9SECTORS"))),type:="EQUITIES_US_SECTOR_VOL"]

        extract[,type:="EQUITIES_US_SECTOR_MOM"]
        attrbwt = rbind(attrbwt, extract)

        extract[,type:="EQUITIES_US_SECTOR_VALUE"]
        attrbwt = rbind(attrbwt, extract)

        setkey(attrbwt, year_mon)

        attrbwt = attrbwt[,sum(contribution_to_weight), keyby = .(ticker, year_mon, weight_change, rank_abs_weight_change, weight, weight_l1m, type)]
        setnames(attrbwt,"V1","contribution_to_weight")
        if(weightChangeFocused){
            attrbwt[, abs_weight_change := abs(weight_change)]
         } else {
            attrbwt[, abs_weight := abs(weight)]         
         }
        setkey(attrbwt, year_mon)   
    }


     # order by absolute weight, so biggest abs weight at top
     if(weightChangeFocused){
          setorderv(attrbwt, c("year_mon", "abs_weight_change"), c(1,-1))
     } else {
          setorderv(attrbwt, c("year_mon", "abs_weight"), c(1,-1))
     }
     
 
     if(!keepSignalNames){
          # replace signal names with nice names
          attrbwt[, signal := portfolioNameMap[attrbwt[,type], name]]
     } else {
          attrbwt[, signal := type]
     }
     
    if (addReturns) {
        returns = dat["monthly_return",]
		indexs = dat["monthly_return_index",]
		expenses = dat["etf_fees"]
		returns = merge(returns, indexs, by=c("mqaid","year_mon"), all=T)
		returns = merge(returns, expenses, by=c("mqaid","year_mon"), all=T)
		names(returns) = c("mqaid","year_mon","typex","value","typey","index","typez","fee")
		returns[,typex:=NULL]
		returns[,typey:=NULL]
		returns[,typez:=NULL]
		returns[,fee:=fee/12]
		returns[is.na(value),value:=index-fee]
		returns = returns[!is.na(value),]
		returns[,index:=NULL]
		returns[,fee:=NULL]
        if (reportDate %in% returns[,unique(year_mon)]) {
            returns[,ticker:= mqaidToTicker(mqaid)]
            returns = returns[!is.na(ticker),]
            returns[, mqaid := NULL]
            returns[, type:= NULL]
            setnames(returns,"value","return")
            attrbwt = merge(attrbwt, returns, by=c("ticker","year_mon"), all.x=T, all.y=F)
        }
     }
     
     if(rawReport){
        attrbwt[, parent_signal := sigName]
        # keep only columns we care about
        if ("return" %in% names(attrbwt)) {
            attrbwt = attrbwt[,.(parent_signal, year_mon, ticker, weight, contribution_to_weight, signal, return)]
        } else {
            attrbwt = attrbwt[,.(parent_signal, year_mon, ticker, weight, contribution_to_weight, signal)]
        }
        return(attrbwt)
     } else {
          # keep only columns we care about
        if ("return" %in% names(attrbwt)) {
            attrbwt = attrbwt[,.(year_mon, ticker, weight, contribution_to_weight, signal, weight_l1m, weight_change, return)]
        } else {
            attrbwt = attrbwt[,.(year_mon, ticker, weight, contribution_to_weight, signal, weight_l1m, weight_change)]
        }        
          
     }

     # do final formatting
     attrbwt[, weight := toPct(weight)]
     attrbwt[, weight_l1m := toPct(weight_l1m)]
     attrbwt[, contribution_to_weight := toPct(contribution_to_weight)]
     attrbwt[, weight_change := toPct(weight_change)]
     attrbwt[, ticker := toupper(ticker)]
     if ("return" %in% names(attrbwt)) {
         attrbwt[, return := toPct(return)]
     }
     setnames(attrbwt,"ticker","Ticker")
     setnames(attrbwt,"weight", paste("Weight in",attrbwt[1,year_mon]))
     setnames(attrbwt,"weight_l1m", paste("Weight in",attrbwt[1,year_mon]-1/12))
     setnames(attrbwt,"contribution_to_weight", "Contribution to Weight")
     setnames(attrbwt,"signal", "Signal")
     setnames(attrbwt,"weight_change", "Weight Change")
     attrbwt[,year_mon := NULL]
     
     attrbwt = data.frame(attrbwt, check.names = F)
     
     # remove redundant and repeated information in table
     # As the same ticker shows up as many times as it is in number of signals
     # items such as ticker, weight in the month, and weight change will be repeated
     # blank out such entries
     
     # Need to do 2 runs, first to remove weight in month and weight change, will use ticker
     # equaling the previous one to remove those, second run will remove the redundant tickers
     for(i in 2:nrow(attrbwt)){
          if(attrbwt[i-1,"Ticker"] == attrbwt[i,"Ticker"]){
               attrbwt[i,c( paste("Weight in", reportDate), 
                            paste("Weight in", reportDate - 1/12), 
                            "Weight Change")] = ""
          }
     }
     
     for(i in nrow(attrbwt):2){
          if(attrbwt[i-1,"Ticker"] == attrbwt[i,"Ticker"]){
               attrbwt[i,"Ticker"] = ""
          }
          
     }
     
     return(attrbwt)
}

# getSignalWeightAttribution
# Combines rawReport results from getSignalWeightAttributionRaw for current and lagged 1 month
# to paint a complete picture of weight composition in current and last month
getSignalWeightAttribution = function(sigName, 
                                      reportDate, 
                                      weightChangeFocused = T,
                                      keepSignalName = F,
                                      masklevel=0,
                                      signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_",
                                      leverage = 1.0){
     
     
     # sigName = "ALL_DYNAMIC_GLOBAL_MACRO"
     # reportDate = as.yearmon("Jul 2016")
     # weightChangeFocused = T
     # signalLocation = "C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_"
     
     current = getSignalWeightAttributionRaw(sigName, reportDate, weightChangeFocused, T, keepSignalName, signalLocation="C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_", T)
     lagged1m = getSignalWeightAttributionRaw(sigName, reportDate- 1/12, weightChangeFocused, T, keepSignalName, signalLocation="n:/TRADING/SIGNAL_")
     
     current[, parent_signal := NULL]
     lagged1m[, parent_signal := NULL]
     
     setkey(current, ticker, signal)
     setkey(lagged1m, ticker, signal)
     
     setnames(lagged1m,"weight","weight_l1m")
     setnames(lagged1m, "contribution_to_weight","contribution_to_weight_l1m")
     setnames(lagged1m, "year_mon","year_mon_l1m")
     
     attrbwt = merge(current, lagged1m, all=T)
     attrbwt[is.na(year_mon), year_mon:= as.yearmon(reportDate)]
     attrbwt[is.na(year_mon_l1m), year_mon_l1m:= as.yearmon(reportDate)-1/12]
     attrbwt[is.na(contribution_to_weight), contribution_to_weight:= 0]
     attrbwt[is.na(contribution_to_weight_l1m), contribution_to_weight_l1m := 0]

     # screen out those that didn't contribution anything to weights in both months
     attrbwt = attrbwt[!(contribution_to_weight == 0 & contribution_to_weight_l1m == 0)]
     
     temp = attrbwt[, list(weight_l1m = mean(weight_l1m , na.rm=T),
                           weight     = mean(weight , na.rm=T)), keyby = .(ticker, year_mon)]
     
     setkey(temp, ticker, year_mon)     
     temp[is.na(weight), weight:= 0]
     temp[is.na(weight_l1m), weight_l1m:= 0]
     
     attrbwt[is.na(weight), weight:= temp[ticker, weight]]
     attrbwt[is.na(weight_l1m), weight_l1m:= temp[ticker, weight_l1m]]    
    
     attrbwt[, weight_change := weight - weight_l1m]
     attrbwt[, abs_weight_change := abs(weight_change)]
     attrbwt[, abs_weight := abs(weight)]
     attrbwt[, contribution_to_weight_changes := contribution_to_weight -
                  contribution_to_weight_l1m]
     removeReturn = F
     if (!("return" %in% names(attrbwt))) {
       attrbwt[,return:=0]
       removeReturn = T
     }
     if (masklevel==1) {     
         attrbwt[,style := portfolioStyleMap[toupper(signal), cat1]]  
         attrbwt[is.na(style), style := signal]
         attrbwt = attrbwt[, list(contribution_to_weight= sum(contribution_to_weight),
                   contribution_to_weight_l1m=sum(contribution_to_weight_l1m),
                   contribution_to_weight_changes=sum(contribution_to_weight_changes)),  
                   keyby = .(ticker, year_mon, weight, return, year_mon_l1m, weight_l1m, weight_change, abs_weight_change, abs_weight, style)]                  
         
         setnames(attrbwt,"style", "signal")
     } else if (masklevel==2) {
         attrbwt[,style := portfolioStyleMap[toupper(signal), cat2]]     
         attrbwt[is.na(style), style := signal]
         attrbwt = attrbwt[, list(contribution_to_weight= sum(contribution_to_weight),
                   contribution_to_weight_l1m=sum(contribution_to_weight_l1m),
                   contribution_to_weight_changes=sum(contribution_to_weight_changes)),  
                   keyby = .(ticker, year_mon, weight, return, year_mon_l1m, weight_l1m, weight_change, abs_weight_change, abs_weight, style)]                  
         
         setnames(attrbwt,"style", "signal")
     
     
     }
     
     if (removeReturn) {
       attrbwt[,return:=NULL]
     }
     if ((!weightChangeFocused) & ("return" %in% names(attrbwt))){
        attrbwt[, contribution_to_return := return*contribution_to_weight]
     }
     
     # reorder columns
     if(weightChangeFocused){
          attrbwt = attrbwt[,.(ticker, weight, weight_l1m, weight_change, 
                               signal, contribution_to_weight_changes,
                               year_mon, year_mon_l1m, abs_weight_change, abs_weight)]
          
          
     } else {
          if ("return" %in% names(attrbwt)) {
              attrbwt = attrbwt[,.(ticker, weight, 
                                   signal, contribution_to_weight, 
                                   year_mon, year_mon_l1m, abs_weight_change, abs_weight, return, contribution_to_return)]
          } else {
              attrbwt = attrbwt[,.(ticker, weight, 
                                   signal, contribution_to_weight, 
                                   year_mon, year_mon_l1m, abs_weight_change, abs_weight)]
          
          }
          #attrbwt = attrbwt[contribution_to_weight != "0%"]
     }

     # do final formatting
     attrbwt[,year_mon := NULL]
     attrbwt[, year_mon_l1m := NULL]
     myRoundCoef = 2
     attrbwt[, weight := toPct(weight, myRoundCoef)]
     
     attrbwt[, ticker := toupper(ticker)]
    # attrbwt[, contribution_to_weight_l1m := toPct(contribution_to_weight_l1m, myRoundCoef)]  
     setnames(attrbwt,"ticker","Ticker")
     setnames(attrbwt,"weight", paste("Weight in",reportDate))
     setnames(attrbwt,"signal", "Signal")

     if ("return" %in% names(attrbwt)) {
         attrbwt[, return := toPct(return, myRoundCoef)]
     }

     if ("contribution_to_return" %in% names(attrbwt)) {
         attrbwt[, contribution_to_return := toPct(contribution_to_return, 4)]
     }
	 
     if(weightChangeFocused) {
        attrbwt[, weight_l1m := toPct(weight_l1m*leverage, myRoundCoef)]
        setnames(attrbwt,"weight_l1m", paste("Weight in",reportDate- 1/12))

        attrbwt[, contribution_to_weight_changes := toPct(contribution_to_weight_changes*leverage, myRoundCoef)]
        setnames(attrbwt,"contribution_to_weight_changes", paste("Contribution to Weight Changes in",reportDate))
        
        attrbwt[, weight_change := toPct(weight_change*leverage, myRoundCoef)]
        setnames(attrbwt,"weight_change", "Weight Change")
     }

     if(!weightChangeFocused) {
        attrbwt[, contribution_to_weight := toPct(contribution_to_weight*leverage, myRoundCoef)]
        attrbwt = attrbwt[contribution_to_weight != "0%"]
        setnames(attrbwt,"contribution_to_weight", paste("Contribution to Weight in",reportDate))
        
     }

     # setnames(attrbwt,"contribution_to_weight_l1m", paste("Contribution to Weight in",attrbwt[1,year_mon_l1m]))
     
     if(weightChangeFocused){
          setorderv(attrbwt, "abs_weight_change", -1)
     } else {
          setorderv(attrbwt, "abs_weight", -1)
     }

     attrbwt[, abs_weight_change := NULL]
     attrbwt[, abs_weight := NULL]
     
     
     attrbwt = data.frame(attrbwt, check.names = F)
     
     # remove redundant and repeated information in table
     # As the same ticker shows up as many times as it is in number of signals
     # items such as ticker, weight in the month, and weight change will be repeated
     # blank out such entries
     
     # Need to do 2 runs, first to remove weight in month and weight change, will use ticker
     # equaling the previous one to remove those, second run will remove the redundant tickers
     for(i in 2:nrow(attrbwt)){
          if(attrbwt[i-1,"Ticker"] == attrbwt[i,"Ticker"]){
               attrbwt[i,intersect(colnames(attrbwt),
                                   c( paste("Weight in", reportDate), 
                                      paste("Weight in", reportDate - 1/12), 
                                      "Weight Change"))] = ""
          }
     }
     
     for(i in nrow(attrbwt):2){
          if(attrbwt[i-1,"Ticker"] == attrbwt[i,"Ticker"]){
               attrbwt[i,"Ticker"] = ""
          }
          
     }
     
     return(attrbwt)
     
}



# parseSignalWeightTree 
# Recursive function that arses results from getSignalWeightTree, 
# used in getSignalWeightAttribution

parseSignalWeightTree = function(mySigName, portName, sigWt = 1, mywt, level=1){
     # need to walk through the tree according to all signals
     
     if( length(setdiff(mywt[mySigName, unique(signal)], portName)) == 1 & 
         all(is.na(setdiff(mywt[mySigName, unique(signal)], portName))) ){
          # if there is no signals for the mySigName, it means there is no further subdivision and
          # we've reached an end node.
          
          # if is end_node return signal_current_wt * weights
          
          portWt = datToXts(mywt[.(portName,mySigName,level)],"ticker", "year_mon", "weight")
          
          if(class(sigWt)[1] == "xts"){
               # if we have an xts matrix, then need to setup the calculation
               portWt = portWt * vectorToXtsMatrix(sigWt, ncol(portWt))
          } else {
               portWt = portWt * sigWt
          }
          
          portWt = xtsToDat(portWt, if(grepl("SINGLE_ETF_",mySigName)) {portName} else {mySigName})
          setnames(portWt,"mqaid","ticker")
          
          return(portWt)
     } else {
          # if there is sub signals for the mySigName, then call parseSignalWeightTree for each 
          # sub signalreturn 
          level = level+1
          tempres = lapply(setdiff(mywt[mySigName, unique(signal)], portName),function(name){
               
               if( nrow(unique(mywt[.(mySigName, name, level),.(year_mon, signal_current_wt)], by = NULL)) !=
                   nrow(mywt[.(mySigName, name, level)])/mywt[.(mySigName,name, level),length(unique(ticker))] ){
                    stop(paste0("parseSignalWeightTree error: signal_current_wt isn't unique for a signal and month",mySigName,name))
               }
               
               tempwt = unique(mywt[.(mySigName, name, level),.(year_mon, signal_current_wt)], by = NULL)
               tempwt = tempwt[,xts(signal_current_wt, year_mon)]
               parseSignalWeightTree(name, mySigName, tempwt * sigWt, mywt, level=level)
          })
          
          tempres = rbindlist(tempres, use.names = T)
          
          return(tempres)
     }
     
}

# toPctTable
# takes a table and turns into % format with RoundCoef decimals
# replaces NA with ""
toPctTable = function(x, RoundCoef = 2){
     apply(x, 2, function(x){ifelse(is.na(x),"",toPct(x, RoundCoef))})
}




# addRowAndColnames
# Adds rownames and column names to X, with the [1,1] entry being empty
addRowAndColnames = function(x){
     
     x = cbind(rownames(x),x)
     x = rbind(colnames(x),x)
     
     return(x)
}


# createRiskManagementReport
# Takes in cumulative returns, drawdowns, and name
# and write a pdf file with name, and plots cumulative returns
# and drawdowns on same page for each column in cumulative returns

createRiskManagementReport = function(name,mycumreturns, mycumreturnsdd, myalphabmkmap,
                                      mycurrbeta = NULL, mytitle = "Risk Management Report",
                                      defaultPortIntroduction = as.yearmon("Mar 2016")){
     
     # mycumreturns = cumalpharet
     # mycumreturnsdd = cumalpharetdd
     # myalphabmkmap = alphabmkmap
     # mycurrbeta = currBeta
     pdf(name, width = 14, height = 11)
     
     # plot title page
     textplot(mytitle)
     
     if(!is.null(mycurrbeta)){
          layout(1:3, heights = c(2,1,1))
     } else {
          layout(1:2, heights = c(2,1))
     }
     
     par(mar = c(1, 5, 2.25, 1), oma = c( 3, 0.5, 0.5, 0.5))
     
     if(!is.null(mycurrbeta)){
          mycex = 2.7
     } else {
          mycex = 2    
     }
     
     
     
     for(sig in colnames(mycumreturns)){
          
          tempsig = mycumreturns[,sig]
          
          # tempsig = tempsig[(firstNonNA(returns[,sig]) - 1):length(tempsig)]
          
          if(!all(tempsig == 1)){
               tempsig = tempsig[(which(tempsig != 1)[1]-1):length(tempsig)]
               
               tempsigdd = mycumreturnsdd[,sig]
               tempsigdd = tempsigdd[index(tempsig)]
               
               if(!is.null(mycurrbeta)) {
                    tempbeta = mycurrbeta[index(tempsig), gsub(" with Timing","",sig)]
                    # cum returns will have extra entry of 1 at beginning
                    # need to add to beta 
                    tempbeta = merge(tempsig, tempbeta, all = T)
                    tempbeta = tempbeta[,2]
                    tempbeta = na.locf(tempbeta, fromLast = T)
               }
               
               # tempsigdd = tempsigdd[(firstNonNA(returns[,sig]) - 1):length(tempsigdd)]
               
               alphacol = "darkgreen"
               liveColor = "magenta"
               if (is.null(mycurrbeta)) {
                 maintext = sig
                 ylabtext = "Cumulative Return"
               } else {
                 maintext = ifelse(is.na(myalphabmkmap[gsub(" with Timing","",sig), Bmk_Name]),
                                        paste(sig,"Alpha"),
                                        paste(sig,"Alpha vs",myalphabmkmap[gsub(" with Timing","",sig), Bmk_Name])) 
                 ylabtext = "Cumulative Alpha"
               
               }
               
               plot(tempsig, type = "n",
                    main = maintext,
                    xaxt = 'n', ylab = ylabtext, col.lab = alphacol,
                    cex.lab = mycex, cex.axis = mycex, cex = mycex, cex.main = mycex)
               lines(tempsig, col = alphacol, lwd = 2)
               
               liveDates = index(SubsetDates_xts(tempsig,
                               ifelse(is.na(myalphabmkmap[gsub(" with Timing","",sig),portfolio_introduction]),
                                      defaultPortIntroduction,
                                      myalphabmkmap[gsub(" with Timing","",sig),portfolio_introduction])-1/12,
                               index(tempsig)[length(tempsig)]))
                  
               lines(tempsig[liveDates], col = liveColor, lwd = 3)            
               legend("topleft","Live Track Record", text.col = liveColor, bty = 'n', cex = mycex)                
               
               alphaddcol = "red2"
               
               if(!is.null(mycurrbeta)){
                    plot(tempsigdd, main = "", ylab = "Drawdown", col.lab = alphaddcol,  
                         cex.lab = mycex, cex.axis = mycex, cex = mycex, xaxt = 'n')   
               } else {
                    plot(tempsigdd, main = "", ylab = "Drawdown", col.lab = alphaddcol,  
                         cex.lab = mycex, cex.axis = mycex, cex = mycex)
               }

               lines(tempsigdd, col = alphaddcol, lwd = 2)
               lines(tempsigdd[liveDates], col = liveColor, lwd = 3)            
               
               if(!is.null(mycurrbeta)){
                    betacol = "blue"
                    test = plot(tempbeta, main = "", ylab = "Beta", col.lab = betacol,  
                         cex.lab = mycex, cex.axis = mycex, cex = mycex)
                    lines(tempbeta, col = betacol, lwd = 2)
                    lines(tempbeta[liveDates], col = liveColor, lwd = 3)            
                    
               }
               
      
          }
          
          
     }
     
     dev.off()
}




# yearmonToTradeDate is a function that converts a yearmon into a timedate
# For a given month we can choose to have the "first", "last", firstDayOfNextMonth returned
yearmonToTradeDate =  function(adate, dayType = "last", BizDayOffset = 0, tradeDateOrSettleDate = "tradeDate" ){
     if (class(adate) == "Date") {
          if (tradeDateOrSettleDate == "settleDate"){
               ts = timeSequence(adate, adate+11)
               ts = isBizday(ts, holidayNYSE())
               adate = as.Date(names(ts)[ts][4])
          }
          return(adate)
     }
        
     if(class(adate) != "yearmon"){
          stop("yearmonToTradeDate Error: adate not yearmon this has not been coded")
     }
     
     if(dayType == "firstDayOfNextMonth" & class(adate) == "yearmon"){
          adate = adate + 1/12
          dayType = "first"
     }
     
     
    if(tradeDateOrSettleDate == "tradeDate" ){
     
     tradeDate = get_DistanceDay_xts(start_dt_t = as.timeDate(as.Date(adate)),
                                     end_dt_t = as.timeDate(as.Date(adate)),
                                     offsetYrs_int =  1, dayOfMonth_str =  dayType, return_DistanceDay_bool =  F , dayOfMonthToSelectWithinMonth = 1)
    } else if (tradeDateOrSettleDate == "settleDate"){
              
              if(dayType == "first"){
                   
                   dayOfMonthToSelectWithinMonth_a = 4
                   
              } else if (dayType == "last") {
                   
                   dayType = "first"
                   dayOfMonthToSelectWithinMonth_a = 3
                   adate = adate + 1/12
              }
              
              tradeDate = get_DistanceDay_xts(start_dt_t = as.timeDate(as.Date(adate)),
                                              end_dt_t = as.timeDate(as.Date(adate)),
                                              offsetYrs_int =  1, dayOfMonth_str =  dayType, return_DistanceDay_bool =  F , dayOfMonthToSelectWithinMonth = dayOfMonthToSelectWithinMonth_a)
              
         }
       
    
     
     tradeDate = tradeDate[year(tradeDate)==year(as.timeDate(as.Date(adate))) & 
                                month(tradeDate)== month(as.timeDate(as.Date(adate)))]
     
     return(tradeDate)
     
}

# collapseListofListToDt will collapse a list of list into a datatable
collapseListofListToDt = function(x){
     do.call(rbind,lapply(x, rbindlist))
}


# calcFixedTransactionCosts
# Calculates transaction costs for portfolio assuming there is fixed cost per transaction
calcFixedTransactionCosts = function(wt, fixedCost = 10){
     # wt = signalImpToXts("C:/local_quant_qsf/Quant/qsf_etf/TRADING/SIGNAL_ALL_GLOBAL_MACRO/signal_imp_m.csv")
     # fixedCost = 10
     
     # need to save allocation to each etf at start of month
     # need to save allocation to each etf at end of month, before rebalancing = wt start * (1 + return)
     # need to calculate the trading involved
     
     wt = na.fill(wt,0)
     colnames(wt) = gsub("_backfilled","",colnames(wt))
     colnames(wt) = gsub("_index","",colnames(wt))
     
     ret = returnsToXts( paste(colnames(wt), "backfilled", sep = "_") )
     colnames(ret) = gsub("_backfilled","",colnames(ret))
     ret = ret[,colnames(wt)]
     # set weights and returns to common months
     common_months = getCommonMonths(wt, ret)
     
     wt = wt[common_months,]
     ret = ret[common_months,]
     
     portret = calcPortRet(ret, wt,"",T)
     
     # weight to each ETF at beginning of month
     wtBOM = wt
     wtEOM = wt * (1 + na.fill(ret,0))
     wtEOM = wtEOM/(1 + vectorToXtsMatrix(portret, ncol(wtEOM)))
     wtEOM = lagXts(wtEOM, 1)
     trading = wtBOM - wtEOM
     tradingInvolved = abs(trading) > 0.0000001
     
     tradingCosts = tradingInvolved * fixedCost
     # colnames(tradingCosts) = mqaidToTicker(colnames(tradingCosts))
     
     return(tradingCosts)
}




###################################################################################################
## write.csv.timestamp is a function that saves objects with a time stamp
## Inputs are:
##             - Obj_save is the object to save
##             - csvName is the name of the file
###################################################################################################


write.csv.timestamp = function(Obj_save = "def" , csvName = "abc" )
{
     timenow = Sys.time()
     timenow = as.character(timenow)
     timenow = gsub("[:]","-",timenow)
     
     write.csv(Obj_save, paste0(csvName," " ,timenow,".csv") )
}




# Creates modified logistic curve, which has x in the range of 0 to 1
modifiedLogisticCurve = function(x, midpoint = 0.4, steepness = 10, L = 1 ){
     L/(1+exp(-steepness*(x-midpoint))) - 
          (1-x)/(1+exp(steepness*midpoint))
}



# calculateRealizedMonthlyVolatility
# Takes an xts or zoo object with Date class index, and calculates
# realized volatility within a month
calculateRealizedMonthlyVolatility = function(x, myAnnualizationFactor = 252){
     
     if(!(class(x)[1] %in% c("xts","zoo"))) stop("calculateRealizedMonthlyVolatility Error: input needs to be xts or zoo object")
     
     if(class(index(x)) != "Date") stop("calculateRealizedMonthlyVolatility Error: input needs to have Date class as index")
     loadPackages("data.table")
     
     x = na.omit(data.table("value" = as.numeric(x), "dates" = index(x)))
     
     x[, year_mon := as.yearmon(dates)]
     
     x = x[, sd(value) * sqrt(myAnnualizationFactor), keyby = year_mon]
     x = na.omit(x[, xts(V1, year_mon)])
     
     return(x)
}


# timeSeriesRobustness
# Evaluates time series robustness of a signal, by randomly removing 10% of the months
# and plotting out distribution of mean, vol, sharpe, max DD, worst month
timeSeriesRobustness = function(x, numSim = 10000, pctRemoved = 0.1, AnnualizationFactor = 12){
     
     ret = returnsToXts(paste0(colnames(x),"_backfilled"))
     colnames(ret) = gsub("_backfilled","",colnames(ret))
     
     res = matrix(rep(NA, numSim * 5), nrow = numSim)
     colnames(res) = c("Mean","Stdev","Sharpe","Max DD","Worst Period")
     
     set.seed(1)
     
     for(i in 1:numSim){
          
          tempx = x[-sample(1:nrow(x), floor(nrow(x) * pctRemoved), replace = F),]
          tempx = tempx[index(tempx) %in% index(ret)]
          
          tempportret = xts(rowSums(tempx * ret[index(tempx)]), index(tempx))
          cumtempportret = cumprod(1+tempportret)
          
          res[i,"Mean"] = mean(tempportret) * AnnualizationFactor
          res[i,"Stdev"] = sd(tempportret) * sqrt(AnnualizationFactor)
          res[i,"Sharpe"] = mean(tempportret)/sd(tempportret) * sqrt(AnnualizationFactor)
          res[i,"Max DD"] = min(cumtempportret/cummax(cumtempportret) - 1)
          res[i,"Worst Period"] = min(tempportret)
          
     }
     
     pdf("time_series_robustness_test.pdf")
    
     for(i in colnames(res)){
          skewness(res[,i])
          plotHistogram(res,i,i,1, ifelse(skewness(res[,i]) < 0,"topleft","topright"))
     }
     
     dev.off()
     
     
}




# getComponentStartDatesAndFees
# Takes in signal imp location, and returns when the ETFs started, and the average expense ratio
getComponentStartDatesAndFees = function(sigImpLocation){
     wt = signalImpToXts(sigImpLocation)
     
     colnames(wt) = mqaidToTicker(colnames(wt))
     # get returns of ETFs, so we can find start date
     ret = returnsToXts(colnames(wt))
     
     # start date
     startDate = getStartDatesXts(ret)
     
     fees = datToXts(dat[.("etf_fees", tickerToMqaid(colnames(ret)))])
     fees = colMeans(fees, na.rm = T)
     names(fees) = mqaidToTicker(names(fees))
     
     res = rbind(as.character(startDate),
                 toPct(fees[names(startDate)]))
     rownames(res) = c("ETF Start Date","Average Expense Ratio")
     
     return(res)
     
}

removeBackfilledFromNames = function(x){
     colnames(x) = gsub("_backfilled","",colnames(x))
     return(x)
}

capZScore = function(z, cap){
     z[z > cap] = cap
     z[z < -cap] = -cap
     z = (z + cap)/(2*cap)
     return(z)
}


toPct2 = function(x, RoundCoef = 2){
     xnames = names(x)
     x = paste0(round(100 * x, RoundCoef),"%")
     names(x) = xnames
     return(x)
}


is.yearmon = function(dateYearmon){
     
     return(class(dateYearmon) == "yearmon")
     
}
