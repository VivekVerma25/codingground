# This is the code for creating return, given stock list and weights , every rebalancing date

##################################################### Libraries

library("xts")
library("zoo")
library("matrixStats")

############################ Inputs to the code
setwd("D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/")
path_input<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/INPUT/"
dir.create("DYNAMIC UNI")
path_output<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/DYNAMIC UNI/"

stck_lvl<-data.frame(read.csv(paste(path_input,"FUT DB/","RollAdjReturns1.csv",sep="")))
stck_lvl$Date<-as.Date(stck_lvl$Date,"%d/%m/%Y")

u1 = data.frame(read.csv(paste(path_input,"Universe/","ActiveFO.csv",sep="")))
u2 = data.frame(read.csv(paste(path_input,"Universe/","TOP 100 OPTIONS.csv",sep="")))
u3 = data.frame(read.csv(paste(path_input,"Universe/","TOP 100 ANALYST.csv",sep="")))


lookback_period=c(250)

for(l in 1:length(lookback_period)){
  
  wq1<-stck_lvl
  dt<-wq1[1:nrow(wq1),1]
  m<-rollapply(wq1[,-1],lookback_period[l],mean,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  s<-rollapply(wq1[,-1],lookback_period[l],sd,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  roll= abs(wq1[,-1]-m)/s
  rollfin <- data.frame(roll)
  rollfin<-as.matrix(rollfin)
  rollfin[which(!is.finite(rollfin))] <- NA
  roll= rollfin
  
  m<-rollapply(roll,22,mean,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  
  rollfin <- data.frame(m)
  
  rollfin[is.na(rollfin)] =0
  rollfin<-as.matrix(rollfin)
  rollfin[which(!is.finite(rollfin))] <- NA
  rollfin<-data.frame(DATE=dt,rollfin)
  
  ret <-rollfin      
}
ret1 =ret

ret1[,-1][u1[,-1]==0] = NA

rnk = data.frame(t(apply(ret1[,-1], 1, rank,na.last="keep",ties.method="first"))) 

topminc<-data.frame((apply(rnk,1,max,na.rm=TRUE)))

topminc = (topminc)*(0.95)

topminc_cbnd <- topminc

for (j in 2:dim(rnk)[2] ){
  topminc_cbnd<-cbind(topminc_cbnd,topminc +1)
  
}
u1_fin=u1

u1_fin[,-1][rnk>topminc_cbnd] =NA



