
##################################################### Libraries

library("xts")
library("zoo")
library("matrixStats")

############################ Inputs to the code
setwd("D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/")
path_input<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/INPUT/"
dir.create("TEST MULTI FACTOR")
path_output<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/TEST MULTI FACTOR/"
source("D:/LFT/Template/tester/R test data/full simulation/ALL R CODES/R_FUNC.R")


stck_lvl<-data.frame(read.csv(paste(path_input,"FUT DB/","RollAdjReturns1.csv",sep="")))     # INPUT FOR RETURN SERIES OF FUTURES/STOCKS
stck_lvl$Date<-as.Date(stck_lvl$Date,"%d/%m/%Y") # Convert to R date format


bna<-1  # BETA NEUTRAL: Keep this 1 if you need beta neutral
topbot<-1 # 2 : TOP/BOTTOM RANK WEIGHTED, 1 : TOP/BOTTOM EQUAL WEIGHTED, SINGLE FACTOR TOP/BOT, 3:
#percentile = 0.9 # For defining portfolio of based on percentiles (0-1) , SINGLE FACTOR
ptop = 0.9 # For defining portfolio based on top percentile, SINGLE FACTOR
pbot = 0.1 # For defining portfolio based on bot percentile, SINGLE FACTOR
#xnum<-10  # This is the number of stocks you need to select both on the top side and bottom side, SINGLE FACTOR
tc<-(0.0004)  # This is one side trnsaction cost 
dsort=1 # For enabling DOUBLE SORT, 1: for DSORT, 0: SIngle factor
fac1_per = 0.6 # For defining portfolio of based on percentiles (0-1) for 1st FACTOR
fac2_per = 0.9 # For defining portfolio of based on percentiles (0-1) for 2nd FACTOR
######################################################################################################################################################
list_factor1 <- vector('list',3) # MULTIPLE PARAMETERS LIST

raw_cash_close = data.frame(read.csv(paste(path_input,"CASH DB/","px_last1.csv",sep=""))) # INPUT RAW DATA FOR FACTOR 1


lookback_period=c(5,10,20) # DIFFERENT LOOKBACKS

for(l in 1:length(lookback_period)){                     #WRITE YOUR LOGIC FOR FACTOR 1, HERE EXAMPLES IS MOMENTUM : 125/250 DAYS
  
  DELAY_raw_cash_close = raw_cash_close[,-1]
  DELAY_raw_cash_close[c(-1:-lookback_period[l]),] =DELAY_raw_cash_close[c((-dim(DELAY_raw_cash_close)[1]):(-dim(DELAY_raw_cash_close)[1]+lookback_period[l]-1)),]
  
  DELTA_raw_cash_close = -(raw_cash_close[,-1]-DELAY_raw_cash_close)/DELAY_raw_cash_close
  
  rollfin<-as.matrix(DELTA_raw_cash_close)
  rollfin[which(!is.finite(rollfin))] <- NA
  rollfin<-data.frame(stck_lvl$Date,rollfin)
  
  list_factor1[[l]] <-rollfin      
}

names(list_factor1) <- list("REV 5","REV 10","REV 20") # Factor1 NAMES WITH PARAMETERS USED

######################################################################## FACTOR 2
list_factor2 <- vector('list',2)

raw_cash_close = data.frame(read.csv(paste(path_input,"CASH DB/","px_last1.csv",sep=""))) # INPUT RAW DATA FOR FACTOR 2

lookback_period=c(125,250) # DIFFERENT LOOKBACKS

for(l in 1:length(lookback_period)){              #WRITE YOUR LOGIC FOR FACTOR 2
  
  DELAY_raw_cash_close = raw_cash_close[,-1]
  DELAY_raw_cash_close[c(-1:-lookback_period[l]),] =DELAY_raw_cash_close[c((-dim(DELAY_raw_cash_close)[1]):(-dim(DELAY_raw_cash_close)[1]+lookback_period[l]-1)),]
  
  DELTA_raw_cash_close = (raw_cash_close[,-1]-DELAY_raw_cash_close)/DELAY_raw_cash_close
  
  rollfin<-as.matrix(DELTA_raw_cash_close)
  rollfin[which(!is.finite(rollfin))] <- NA
  rollfin<-data.frame(stck_lvl$Date,rollfin)
  
  list_factor2[[l]] <-rollfin      
}

names(list_factor2) <- list("MOM 125","MOM 250") # Factor2 NAMES WITH PARAMETERS USED
##########################################################################


#stapp = data.frame(read.csv(paste(path_input,"UNIVERSE/","ActiveFO.csv",sep=""))) # INPUT THE UNIVERSE TO RUN ON
uni_list = vector("list",3)
uni_list[[1]] = data.frame(read.csv(paste(path_input,"UNIVERSE/","ActiveFO.csv",sep="")))
uni_list[[2]] = data.frame(read.csv(paste(path_input,"UNIVERSE/","Nifty50_SHORT.csv",sep="")))
uni_list[[3]] = data.frame(read.csv(paste(path_input,"UNIVERSE/","N50_TOP50_ANALYST.csv",sep="")))

names(uni_list) = list("ActiveFO","Nifty50","N50_TOP50_ANALYST")
# FACTOR COMPUTATION ENDS, DON'T CHANGE THE CODE BELOW THIS

#######################################################################################################################################################
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#######################################################################################################################################################


fac_list1 = list_factor1



ret_full_cmbn = data.frame(stck_lvl$Date[c(-1,-2)])
colnames(ret_full_cmbn)= "DATE"

ret_tb_cmbn = ret_full_cmbn
ret_full_cmbn_L = ret_full_cmbn
ret_full_cmbn_S = ret_full_cmbn
ret_tb_cmbn_L = ret_tb_cmbn
ret_tb_cmbn_S= ret_tb_cmbn
result_full_cmbn = NULL
result_tb_cmbn = NULL


for(u in 1: length(uni_list))
{
  stapp = uni_list[[u]]
  
  for(z in 1 : length(fac_list1))
  {
    
    fac_1<-fac_list1[[z]] # factor file input
    
    #stapp<-data.frame(read.csv(paste(uni_list[u,1],"/",uni_list[u,2],".csv",sep="")))
    
    
    f_factor<-data.frame(fac_1)                                 
    f_factor<-(f_factor[,-1])
    
    f_factor[stapp[,-1]==0]<-NA
    f_factor[f_factor<0.0000001 & f_factor>-0.0000001]<-NA      # This will be the final clculate foactor to be used for ranking
    
    fac1_rnk <- data.frame(t(apply(f_factor, 1, rank,na.last="keep",ties.method="max")))
    
    factor_rnk = data.frame(t(apply(f_factor, 1, rank,na.last="keep",ties.method="random")))
    
    fac_clas<-fac1_rnk   # Rank weight of the final factor
    
    if(dsort ==1)
    {
      
      ret_tb_cmbn_L = ret_tb_cmbn
      ret_tb_cmbn_S= ret_tb_cmbn
      
      
    }
    
    
    if(dsort ==1){
      
      #fac_2<-data.frame(read.csv(paste(path_input,"factor.csv",sep=""))) 
      #fac_list2 = list_factor2
      fac_list2 = fac_list1
          
      for(zz in 1 : length(fac_list2))
      {
        
        fac_2<- fac_list2[[zz]] # factor file input
        
        f_factor2<-data.frame(fac_2)                                 
        f_factor2<-(f_factor2[,-1])
        
        f_factor2[stapp[,-1]==0]<-NA
        f_factor2[f_factor2<0.0000001 & f_factor2>-0.0000001]<-NA      # This will be the final clculate foactor to be used for ranking
        
        fac2_top<-f_factor2
        fac2_bot<-f_factor2
                              
        topmax<-data.frame((apply(factor_rnk,1,max,na.rm=TRUE)))
        
        topminc = round((apply(factor_rnk, 1, quantile,probs=fac1_per ,na.rm =TRUE,ties.method="random")))
        
        botminc = round((apply(factor_rnk, 1, quantile,probs=1-fac1_per ,na.rm =TRUE,ties.method="random")))
        
        topminc_cbnd <- topminc
        
        for (j in 2:dim(factor_rnk)[2] ){
          topminc_cbnd<-cbind(topminc_cbnd,topminc)
          
        }
        #       
        
        
        botminc_cbnd <- botminc
        
        for (j in 2:dim(factor_rnk)[2] ){
          botminc_cbnd<-cbind(botminc_cbnd,botminc)
          
        }
        
       
        
        
        
        
        #botminc = 1/(2*(botminc))      
        
        
#         
#         
#         wts_ini_top[rnk_top>=topminc_cbnd]<-topminc_cbnd1[rnk_top>=topminc_cbnd]
#         wts_ini_top<-data.frame(wts_ini_top)
#         
#         
#         wts_ini_bot[rnk_bot<=botminc_cbnd]<-botminc_cbnd1[rnk_bot<=botminc_cbnd]
#         wts_ini_bot<-data.frame(wts_ini_bot)
#         
        
        
        fac2_top[factor_rnk < topminc_cbnd]<- NA  
        
        fac2_rank_top<- data.frame(t(apply(fac2_top, 1, rank,na.last="keep",ties.method="random"))) 
        
        fac2_bot[factor_rnk > botminc_cbnd] <- NA  
        
        fac2_rank_bot<- data.frame(t(apply(fac2_bot, 1, rank,na.last="keep",ties.method="random")))
        
        
        fac2_rank_top2<-fac2_rank_top
        
        fac2_rank_bot2<-fac2_rank_bot 
        
        topmax2<-((apply(fac2_rank_top,1,max,na.rm=TRUE)))
        
        #topminc2 = round((apply(factor_rnk, 1, quantile,probs=fac2_per ,na.rm =TRUE,ties.method="random")))
        
        botminc2 = round((apply(factor_rnk, 1, quantile,probs=1-fac2_per ,na.rm =TRUE,ties.method="random")))
               
        
        fac2_rank_top2[fac2_rank_top < (topmax2 - botminc2+1)]<- NA
        
        #fac2_rank_top1[fac2_rank_top1 <(dim(fac2_rank_top1)[2]-rowSums(is.na(fac2_rank_top1)))- dnum2+1]<- NA
        
        
        fac2_rank_bot2[fac2_rank_bot>botminc2]<- NA
        

        topminc_cbnd2 <- (1/(2*(botminc2)))
        
        for (j in 2:dim(fac2_rank_top2)[2] ){
          topminc_cbnd2<-cbind(topminc_cbnd2,(1/(2*(botminc2))))
          
        }
        #       
        
        
        botminc_cbnd2 <- -(1/(2*(botminc2)))
        
        for (j in 2:dim(fac2_rank_bot2)[2] ){
          botminc_cbnd2<-cbind(botminc_cbnd2,-1/(2*(botminc2)))
          
        }
        

        botminc_cbnd2[is.na(botminc_cbnd2)] = 0
        #botminc_cbnd[is.na(botminc_cbnd)] = 0
        #topminc_cbnd[is.na(topminc_cbnd)] = 0
        topminc_cbnd2[is.na(topminc_cbnd2)] = 0
        fac2_rank_top2[is.na(fac2_rank_top2)] = 0
        fac2_rank_bot2[is.na(fac2_rank_bot2)] = 0         


        fac2_rank_top2[fac2_rank_top2>0]<-topminc_cbnd2[fac2_rank_top2>0]
        fac2_rank_top2<-data.frame(fac2_rank_top2)
        
        
        fac2_rank_bot2[fac2_rank_bot2>0]<-botminc_cbnd2[fac2_rank_bot2>0]
        fac2_rank_bot2<-data.frame(fac2_rank_bot2)
    
# 
#         fac2_rank_top2[is.na(fac2_rank_top2)] <-0   #Final double sorted equal weights
#         fac2_rank_top2[fac2_rank_top2 >0]<-(1/(2*botmin2))
#         fac2_rank_bot2[is.na(fac2_rank_bot2)] <-0
#         fac2_rank_bot2[fac2_rank_bot2 >0]<-(-1/(2*botmin2))
        
        
        colnames(fac2_rank_top2)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
        colnames(fac2_rank_bot2)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
        #       
        #       
        #       topname<-matrix(0,dim(fac2_rank_top2)[1],dnum2)
        #       botname<-matrix(0,dim(fac2_rank_bot2)[1],dnum2)
        #       
        #       
        #       
        #       
        #       for (k in 1:dim(fac2_rank_top2)[1]){
        #         
        #         if((sum(fac2_rank_top2[k,]>0) ==dnum2) && (sum(fac2_rank_bot2[k,]<0) ==dnum2))
        #         {
        #         
        #         topname[k,]<-colnames(fac2_rank_top2[k,fac2_rank_top2[k,]>0])
        #         botname[k,]<-colnames(fac2_rank_bot2[k,fac2_rank_bot2[k,]<0])
        #         
        #         }
        #         
        #         else
        #         {
        #           fac2_rank_top2[k,] =0
        #           fac2_rank_bot2[k,] =0
        #         }
        #       }
        #       
        
        wts_tb<-(fac2_rank_top2 + fac2_rank_bot2)
        
        wts_tb<-data.frame(wts_tb)
        
        wts_ini_top<-wts_tb
        wts_ini_bot<-wts_tb
        
        wts_ini_top[wts_tb<=0]<-0
        wts_ini_bot[wts_tb>=0]<-0
        
        
        wts_ini_full_tb <- (wts_tb)
        
        ###################################################################################################################################################################
        
        wts_ini_top_calc<-wts_ini_top[c(-1*dim(wts_ini_top)[1],-1*dim(wts_ini_top)[1]+1),]                        #return calculation
        wts_ini_bot_calc<-wts_ini_bot[c(-1*dim(wts_ini_bot)[1],-1*dim(wts_ini_bot)[1]+1),]
        
        stck_lvl_calc<-stck_lvl[c(-1,-2),-1]
        
        lng_ret_tb<-data.frame(rowSums(wts_ini_top_calc*stck_lvl_calc))
        sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
        
        lng_beta_tb<- matrix(1,dim(lng_ret_tb)[1],1)
        sht_beta_tb<- matrix(1,dim(sht_ret_tb)[1],1)
        
        
        if (bna==1){        # This will check if beta neutral needs to be done or not
          
          
          for(m in 251: dim(lng_beta_tb)[1])     # This will quantify the beta ratio between long and short in the portfolio
          {                                  
            
            #print(m)  
            
            lng_beta_tb[m,1]<- (cov(lng_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
            sht_beta_tb[m,1]<- -(cov(sht_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
          }
          
          wts_ini_bot_calc<-wts_ini_bot_calc*(lng_beta_tb/sht_beta_tb)
          wts_ini_full_tb[c(-1*dim(wts_ini_full_tb)[1],-1*dim(wts_ini_full_tb)[1] +1),] <-(wts_ini_top_calc + wts_ini_bot_calc)
          wts_ini_full_tb[(dim(wts_ini_full_tb)[1]-1),] <- wts_ini_top[(dim(wts_ini_full_tb)[1]-1),]+wts_ini_bot[(dim(wts_ini_full_tb)[1]-1),]*(lng_beta_tb[dim(lng_beta_tb)[1],1]/sht_beta_tb[dim(sht_beta_tb)[1],1])
          wts_ini_bot<-wts_ini_full_tb
          wts_ini_bot[wts_ini_full_tb>=0]<-0
          sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
          
        } 
        
        cst_tb<-data.frame(rowSums(abs(wts_ini_full_tb[-1,]-wts_ini_full_tb[-1*dim(wts_ini_full_tb)[1],])*tc))
        cst_tb<-cst_tb[-1*dim(cst_tb)[1],]
        
        cst_tb_L<-data.frame(rowSums(abs(wts_ini_top[-1,]-wts_ini_top[-1*dim(wts_ini_top)[1],])*tc))
        cst_tb_L<-cst_tb_L[-1*dim(cst_tb_L)[1],]
        
        cst_tb_S<-data.frame(rowSums(abs(wts_ini_bot[-1,]-wts_ini_bot[-1*dim(wts_ini_bot)[1],])*tc))
        cst_tb_S<-cst_tb_S[-1*dim(cst_tb_S)[1],]
        
        TV_tb<-data.frame(rowSums(abs(wts_ini_full_tb[-1,]-wts_ini_full_tb[-1*dim(wts_ini_full_tb)[1],])))[-1,]
        
        #result_tb = data.frame(cbind(t(ann_rslt(data.frame(stck_lvl$Date[c(-1,-2)],tot_ret_tb,TV_tb))),paste(names(fac_list1)[z],"_",names(uni_list)[u])))

        tot_ret_tb<-data.frame((lng_ret_tb+sht_ret_tb) - cst_tb)
        
        lng_ret_tb<-data.frame(lng_ret_tb-cst_tb_L)
        sht_ret_tb<-data.frame(sht_ret_tb-cst_tb_S)
        
        ret_fin_tb<-data.frame(cbind(stck_lvl$Date[c(-1,-2)],tot_ret_tb,lng_ret_tb,sht_ret_tb,wts_ini_full_tb[c(-1,-1*dim(wts_ini_full_tb)[1]),]))

        tot_ret_tb[is.na(tot_ret_tb)]<-0
        TV_tb[is.na(TV_tb)]<-0

        result_tb = data.frame(cbind(t(ann_rslt(data.frame(stck_lvl$Date[c(-1,-2)],tot_ret_tb,TV_tb))),paste(names(fac_list1)[z],"_",names(fac_list2)[zz],"_",names(uni_list)[u])))
        #result_full = data.frame(cbind(t(ann_rslt(data.frame(stck_lvl$Date[c(-1,-2)],tot_ret_full,TV_full))),paste(names(fac_list1)[z],"_",names(uni_list)[u])))
        colnames(result_tb)[dim(result_tb)[2]] = "FACTOR"

        write.csv(result_tb,paste(path_output,names(fac_list1)[z],"_",names(fac_list2)[zz],"_",names(uni_list)[u],"_TB_Results.csv"),row.names=FALSE)
        
        write.csv(ret_fin_tb,paste(path_output,names(fac_list1)[z],"_",names(fac_list2)[zz],"_",names(uni_list)[u],"_TB_PORTFOLIO.csv"),row.names=FALSE)
        
        ret_tb_cmbn = data.frame(cbind(ret_tb_cmbn,tot_ret_tb))
        colnames(ret_tb_cmbn)[((u-1)*(length(fac_list1)*length(fac_list2))) +(z-1)*length(fac_list2)+1+zz]= paste(names(fac_list1)[z],"_",names(fac_list2)[zz],"_",names(uni_list)[u])
        
        result_tb_cmbn = data.frame(rbind(result_tb_cmbn,result_tb))

        ret_tb_cmbn_L = data.frame(cbind(ret_tb_cmbn_L,lng_ret_tb))
        colnames(ret_tb_cmbn_L)[((u-1)*(length(fac_list1)*length(fac_list2))) +(z-1)*length(fac_list2)+1+zz]= paste(names(fac_list1)[z],"_",names(fac_list2)[zz],"_",names(uni_list)[u])
        
        ret_tb_cmbn_S = data.frame(cbind(ret_tb_cmbn_S, sht_ret_tb))
        colnames(ret_tb_cmbn_S)[((u-1)*(length(fac_list1)*length(fac_list2))) +(z-1)*length(fac_list2)+1+zz]= paste(names(fac_list1)[z],"_",names(fac_list2)[zz],"_",names(uni_list)[u])
      
      }
      
      
    }
    
    
    if(dsort!=1){
      
      wts_fin<-NULL
      
      fac_clas_sel_1<-as.matrix(fac_clas)
      
      fac_clas_sel_2<-(fac_clas_sel_1-rowMeans(fac_clas_sel_1,na.rm=TRUE))/rowSums(abs(fac_clas_sel_1-rowMeans(fac_clas_sel_1,na.rm=TRUE)),na.rm=TRUE)
      
      wts_ini<-data.frame(fac_clas_sel_2)
      
      wts_tb<-wts_ini
      wts_ini_top<-matrix(0,dim(wts_ini)[1],dim(wts_ini)[2])
      wts_ini_bot<-matrix(0,dim(wts_ini)[1],dim(wts_ini)[2])
      
      
      if (topbot==1){  # This will select the top x and bottom x stocks and equaly weigh the same
        
        
        rnk_top<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
        #rnk_top<-fac1_rnk
        
        rnk_bot<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
        #rnk_bot<-fac1_rnk
        
        ############ The below will calculate the top and bottom ranks
        
        topmax<-data.frame((apply(rnk_top,1,max,na.rm=TRUE)))
        
        topminc = round((apply(rnk_top, 1, quantile,probs=ptop ,na.rm =TRUE,ties.method="random")))
        
        botminc = round((apply(rnk_top, 1, quantile,probs=pbot ,na.rm =TRUE,ties.method="random")))
        #topminc[topminc<=xnum]<-xnum     # This is to make sure that the total number is not less than selected numbers
        
        topminc_cbnd <- topminc
        
        for (j in 2:dim(wts_ini)[2] ){
          topminc_cbnd<-cbind(topminc_cbnd,topminc)
          
        }
#       
        

        botminc_cbnd <- botminc

        for (j in 2:dim(wts_ini)[2] ){
        botminc_cbnd<-cbind(botminc_cbnd,botminc)
  
        }


        topminc_cbnd1 <- (1/(2*(topmax - topminc+1)))

        for (j in 2:dim(wts_ini)[2] ){
            topminc_cbnd1<-cbind(topminc_cbnd1,(1/(2*(topmax - topminc+1))))
  
        }
#       


        botminc_cbnd1 <- -1/(2*(botminc))

        for (j in 2:dim(wts_ini)[2] ){
        botminc_cbnd1<-cbind(botminc_cbnd1,-1/(2*(botminc)))
  
        }

      
        

        #botminc = 1/(2*(botminc))      

        botminc_cbnd1[is.na(botminc_cbnd1)] = 0
        botminc_cbnd[is.na(botminc_cbnd)] = 0
        topminc_cbnd[is.na(topminc_cbnd)] = 0
        topminc_cbnd1[is.na(topminc_cbnd1)] = 0
        rnk_top[is.na(rnk_top)] = -999999999
        rnk_bot[is.na(rnk_bot)] = 999999999         


      #topminc[is.na(topminc)] = 0
        



        wts_ini_top[rnk_top>=topminc_cbnd]<-topminc_cbnd1[rnk_top>=topminc_cbnd]
        wts_ini_top<-data.frame(wts_ini_top)
        

        wts_ini_bot[rnk_bot<=botminc_cbnd]<-botminc_cbnd1[rnk_bot<=botminc_cbnd]
        wts_ini_bot<-data.frame(wts_ini_bot)

        
        #wts_ini_bot[rnk_bot<=botminc_cbnd]<-(-1/(2*xnum))
        
        #wts_ini_bot<-data.frame(wts_ini_bot)
        
        
        colnames(wts_ini_bot)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
        colnames(wts_ini_top)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
        
#         
#         topname<-matrix(0,dim(wts_ini_top)[1],xnum)
#         botname<-matrix(0,dim(wts_ini_bot)[1],xnum)
#         
        
        #       
        #       
        #       for (k in 1:dim(wts_ini_bot)[1] ){
        #         
        #         if((sum(wts_ini_top[k,]>0) ==xnum) && (sum(wts_ini_bot[k,]<0) ==xnum))
        #           
        #         {
        #           topname[k,]<-colnames(wts_ini_top[k,wts_ini_top[k,]>0])
        #           botname[k,]<-colnames(wts_ini_bot[k,wts_ini_bot[k,]<0])
        #         }
        #         else
        #         {
        #           wts_ini_top[k,]<-0
        #           wts_ini_bot[k,]<-0
        #         }
        #         
        #       }
        
        
      }
      ####################################################################################################################################################
      
      
      if (topbot==2){  # This will select the top x and bottom x stocks and equaly weigh the same
        
        
        
        rnk_top<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
        #rnk_top<-fac1_rnk
        
        rnk_bot<-data.frame(t(apply(wts_ini, 1, rank,na.last="keep",ties.method="random"))) 
        #rnk_bot<-fac1_rnk
        
        ############ The below will calculate the top and bottom ranks
        
        topmax<-data.frame((apply(rnk_top,1,max,na.rm=TRUE)))
        ############ The below will calculate the top and bottom ranks
        topminc = round((apply(rnk_top, 1, quantile,probs=ptop ,na.rm =TRUE,ties.method="random")))
        
        botminc = round((apply(rnk_top, 1, quantile,probs=pbot ,na.rm =TRUE,ties.method="random")))
        #topminc<-data.frame((apply(rnk_top,1,max,na.rm=TRUE)))
        #topminc[topminc<=xnum]<-xnum     # This is to make sure that the total number is not less than selected numbers
        
        topminc_cbnd <- topminc
        
        for (j in 2:dim(wts_ini)[2] ){
          topminc_cbnd<-cbind(topminc_cbnd,topminc)
          
        }
               
                
        botminc_cbnd <- botminc
        
        for (j in 2:dim(wts_ini)[2] ){
          botminc_cbnd<-cbind(botminc_cbnd,botminc)
          
        }
        
        wts_ini_top<-wts_tb
        wts_ini_bot<-wts_tb
        
        wts_ini_top[rnk_top < topminc_cbnd] <-NA
        wts_ini_bot[rnk_bot > botminc_cbnd] = NA
        
        wts_ini_top<-wts_ini_top/(2*rowSums(abs(wts_ini_top),na.rm=TRUE))
        wts_ini_bot<-wts_ini_bot/(2*rowSums(abs(wts_ini_bot),na.rm=TRUE))
        
#         
#         wts_tb[rnk_top < topminc_cbnd & rnk_top >botminc_cbnd] <-NA
#         wts_tb<-wts_tb/rowSums(abs(wts_tb),na.rm=TRUE)
#       
        
        wts_ini_top[is.na(wts_ini_top)]<-0
        wts_ini_bot[is.na(wts_ini_bot)]<-0

        wts_ini_top<-data.frame(wts_ini_top)
        wts_ini_bot<-data.frame(wts_ini_bot)
          
        wts_tb =  wts_ini_top + wts_ini_bot


#         wts_ini_top[wts_tb<=0]<-0
#         wts_ini_bot[wts_tb>=0]<-0
#         
        
        colnames(wts_ini_bot)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
        colnames(wts_ini_top)<-colnames(stck_lvl)[-1]  # This will assign thhe proper stock name
        
                 
      }
      
      ####################################################################################################################################################
      
      
      #wts_sel_int<-wts_ini[wts_ini[2,]==i]     # This is the internal wts for calculation
      
      wts_fin<-wts_ini
      
      
      wts_fin[is.na(wts_fin)]<-0
      
      wts_int_full<-data.frame((wts_fin))
      
      
      wts_int_pos_full<-wts_int_full
      wts_int_neg_full<-wts_int_full
      
      wts_int_pos_full[wts_int_full<=0]<-0
      wts_int_neg_full[wts_int_full>=0]<-0
      
      
      ##############################################################################################################################
      wts_int_pos_full_calc<-wts_int_pos_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),]             #Full universe factor returns
      wts_int_neg_full_calc<-wts_int_neg_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),]
      
      
      #wts_int_pos_full_calc<-wts_int_pos_full_calc[-1*dim(wts_int_pos_full_calc)[1],]             #Full universe factor returns
      #wts_int_neg_full_calc<-wts_int_neg_full_calc[-1*dim(wts_int_neg_full_calc)[1],]
      
      stck_lvl_calc<-stck_lvl[c(-1,-2),-1]
      
      lng_ret_full<-data.frame(rowSums(wts_int_pos_full_calc*stck_lvl_calc))
      sht_ret_full<-data.frame(rowSums(wts_int_neg_full_calc*stck_lvl_calc))
      
      lng_beta_full<- matrix(1,dim(lng_ret_full)[1],1)
      sht_beta_full<- matrix(1,dim(sht_ret_full)[1],1)
      
      
      if (bna==1){        # This will check if beta neutral needs to be done or not
        
        
        for(m in 251: dim(lng_ret_full)[1])        # This will quantify the beta ratio between long and short in the portfolio
        {
          
          #print(m)  
          
          lng_beta_full[m,1]<- (cov(lng_ret_full[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
          sht_beta_full[m,1]<- -(cov(sht_ret_full[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
        }
        
        wts_int_neg_full_calc<-wts_int_neg_full_calc*(lng_beta_full/sht_beta_full)
        wts_int_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),] <- ( wts_int_pos_full_calc + wts_int_neg_full_calc)
        wts_int_full[(dim(wts_int_full)[1]-1),] <- wts_int_pos_full[(dim(wts_int_full)[1]-1),]+wts_int_neg_full[(dim(wts_int_full)[1]-1),]*(lng_beta_full[dim(lng_beta_full)[1],1]/sht_beta_full[dim(sht_beta_full)[1],1])
        wts_int_neg_full<-wts_int_full
        wts_int_neg_full[wts_int_full>=0]<-0
        sht_ret_full<-data.frame(rowSums(wts_int_neg_full_calc*stck_lvl_calc))
      } 
      
      
      cst_full<-data.frame(rowSums(abs(wts_int_full[-1,]-wts_int_full[-1*dim(wts_int_full)[1],])*tc))
      cst_full<-cst_full[-1*dim(cst_full)[1],]
      
      cst_full_L<-data.frame(rowSums(abs(wts_int_pos_full[-1,]-wts_int_pos_full[-1*dim(wts_int_pos_full)[1],])*tc))
      cst_full_L<-cst_full_L[-1*dim(cst_full_L)[1],]
      
      cst_full_S<-data.frame(rowSums(abs(wts_int_neg_full[-1,]-wts_int_neg_full[-1*dim(wts_int_neg_full)[1],])*tc))
      cst_full_S<-cst_full_S[-1*dim(cst_full_S)[1],]
      
      
      TV_full = data.frame(rowSums(abs(wts_int_full[-1,]-wts_int_full[-1*dim(wts_int_full)[1],])))[-1,]
      
      
      #lng_ret_full<-data.frame(rowSums(wts_int_pos_full_calc*stck_lvl_calc))
      #tot_ret_full<-data.frame((wts_int_full[c(-1*dim(wts_int_full)[1],-1*dim(wts_int_full)[1] +1),]*stck_lvl_calc)-cst_full)  
      
      tot_ret_full<-data.frame((lng_ret_full+sht_ret_full)-cst_full)
      
      
      lng_ret_full<-data.frame(lng_ret_full-cst_full_L)
      sht_ret_full<-data.frame(sht_ret_full-cst_full_S)
      
      ret_fin_full<-data.frame(cbind(stck_lvl$Date[c(-1,-2)],tot_ret_full,lng_ret_full,sht_ret_full,wts_int_full[c(-1,-1*dim(wts_int_full)[1]),]))
      
      tot_ret_full[is.na(tot_ret_full)]<-0
      TV_full[is.na(TV_full)]<-0

      result_full = data.frame(cbind(t(ann_rslt(data.frame(stck_lvl$Date[c(-1,-2)],tot_ret_full,TV_full))),paste(names(fac_list1)[z],"_",names(uni_list)[u])))
      colnames(result_full)[dim(result_full)[2]] = "FACTOR"
      #write.csv(ret_fin_full,paste(path_output,fac_list[z,2],"_",uni_list[u,2],"_FULL.csv"),row.names=FALSE)
      write.csv(result_full,paste(path_output,names(fac_list1)[z],"_",names(uni_list)[u],"_FULL_Results.csv"),row.names=FALSE)
      
      #write.csv(ret_fin_full, file = "ret_fin_full.csv")
      
      #write.csv(ret_fin_full,paste(path_output,fac_list[z,2],"_",uni_list[u,2],"_FULL.csv"),row.names=FALSE)
      write.csv(ret_fin_full,paste(path_output,names(fac_list1)[z],"_",names(uni_list)[u],"_FULL_PORTFOLIO.csv"),row.names=FALSE)
      ################################################################################################################################
      
      ################################################################################################################################
      if (topbot!=0){       
        
        wts_ini_full_tb <- (wts_ini_top+wts_ini_bot)
        
        
        wts_ini_top_calc<-wts_ini_top[c(-1*dim(wts_ini_top)[1],-1*dim(wts_ini_top)[1]+1),]                        #return calculation for top-bot 10
        wts_ini_bot_calc<-wts_ini_bot[c(-1*dim(wts_ini_bot)[1],-1*dim(wts_ini_bot)[1]+1),]
        
        lng_ret_tb<-data.frame(rowSums(wts_ini_top_calc*stck_lvl_calc))
        sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
        
        
        lng_beta_tb<- matrix(1,dim(lng_ret_tb)[1],1)
        sht_beta_tb<- matrix(1,dim(sht_ret_tb)[1],1)
        
        
        if (bna==1){        # This will check if beta neutral needs to be done or not
          
          
          for(m in 251: dim(lng_beta_tb)[1])     # This will quantify the beta ratio between long and short in the portfolio
          {                                  
            
            #print(m)  
            
            lng_beta_tb[m,1]<- (cov(lng_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
            sht_beta_tb[m,1]<- -(cov(sht_ret_tb[(m-250):(m-1),1],stck_lvl[c(-1,-2),2][(m-250):(m-1)])/var(stck_lvl[c(-1,-2),2][(m-250):(m-1)]))
          }
          
          wts_ini_bot_calc<-wts_ini_bot_calc*(lng_beta_tb/sht_beta_tb)
          wts_ini_full_tb[c(-1*dim(wts_ini_full_tb)[1],-1*dim(wts_ini_full_tb)[1] +1),] <-(wts_ini_top_calc + wts_ini_bot_calc)
          wts_ini_full_tb[(dim(wts_ini_full_tb)[1]-1),] <- wts_ini_top[(dim(wts_ini_full_tb)[1]-1),]+wts_ini_bot[(dim(wts_ini_full_tb)[1]-1),]*(lng_beta_tb[dim(lng_beta_tb)[1],1]/sht_beta_tb[dim(sht_beta_tb)[1],1])
          wts_ini_bot<-wts_ini_full_tb
          wts_ini_bot[wts_ini_full_tb>=0]<-0
          sht_ret_tb<-data.frame(rowSums(wts_ini_bot_calc*stck_lvl_calc))
          
        } 
        
        cst_tb<-data.frame(rowSums(abs(wts_ini_full_tb[-1,]-wts_ini_full_tb[-1*dim(wts_ini_full_tb)[1],])*tc))
        cst_tb<-cst_tb[-1*dim(cst_tb)[1],]
        
        cst_tb_L<-data.frame(rowSums(abs(wts_ini_top[-1,]-wts_ini_top[-1*dim(wts_ini_top)[1],])*tc))
        cst_tb_L<-cst_tb_L[-1*dim(cst_tb_L)[1],]
        
        cst_tb_S<-data.frame(rowSums(abs(wts_ini_bot[-1,]-wts_ini_bot[-1*dim(wts_ini_bot)[1],])*tc))
        cst_tb_S<-cst_tb_S[-1*dim(cst_tb_S)[1],]
        
        
        TV_tb<-data.frame(rowSums(abs(wts_ini_full_tb[-1,]-wts_ini_full_tb[-1*dim(wts_ini_full_tb)[1],])))[-1,]
        
        tot_ret_tb<-data.frame((lng_ret_tb+sht_ret_tb) - cst_tb)
        
        lng_ret_tb<-data.frame(lng_ret_tb-cst_tb_L)
        sht_ret_tb<-data.frame(sht_ret_tb-cst_tb_S)
        
        #ret_fin_tb<-data.frame(cbind(stck_lvl$Returns[c(-1,-2)],tot_ret_tb,lng_ret_tb,sht_ret_tb,topname[c(-1,-1*dim(topname)[1]),],botname[c(-1,-1*dim(botname)[1]),]))
        
        ret_fin_tb<-data.frame(cbind(stck_lvl$Date[c(-1,-2)],tot_ret_tb,lng_ret_tb,sht_ret_tb,wts_ini_full_tb[c(-1,-1*dim(wts_ini_full_tb)[1]),]))
        
        
        #ret_fin_tb1<- data.frame(aggregate(ret_fin_tb[,2],by=list((substr(ret_fin_tb[,1],1,4))),sum))
        #ret_fin_tb2<- data.frame(aggregate(ret_fin_tb[,2],by=list((substr(ret_fin_tb[,1],1,4))),mean))
        #ret_fin_tb3<- data.frame(aggregate(ret_fin_tb[,2],by=list((substr(ret_fin_tb[,1],1,4))),sd))
        
        #write.csv(ret_fin_tb, file = "ret_fin_tb.csv")
        #write.csv(ret_fin_tb,paste(path_output,fac_list[z,2],"_",uni_list[u,2],"_TOPBOT.csv"),row.names=FALSE)
                
        tot_ret_tb[is.na(tot_ret_tb)]<-0
        TV_tb[is.na(TV_tb)]<-0
                
        result_tb = data.frame(cbind(t(ann_rslt(data.frame(stck_lvl$Date[c(-1,-2)],tot_ret_tb,TV_tb))),paste(names(fac_list1)[z],"_",names(uni_list)[u])))
        #result_full = data.frame(cbind(t(ann_rslt(data.frame(stck_lvl$Date[c(-1,-2)],tot_ret_full,TV_full))),paste(names(fac_list1)[z],"_",names(uni_list)[u])))
        colnames(result_tb)[dim(result_tb)[2]] = "FACTOR"
        #write.csv(ret_fin_full,paste(path_output,fac_list[z,2],"_",uni_list[u,2],"_FULL.csv"),row.names=FALSE)
        write.csv(result_tb,paste(path_output,names(fac_list1)[z],"_",names(uni_list)[u],"_TB_Results.csv"),row.names=FALSE)
        
        write.csv(ret_fin_tb,paste(path_output,names(fac_list1)[z],"_",names(uni_list)[u],"_TB_PORTFOLIO.csv"),row.names=FALSE)
        
      }
      
      
      ret_full_cmbn = data.frame(cbind(ret_full_cmbn,tot_ret_full))
      colnames(ret_full_cmbn)[z+(u-1)*(length(fac_list1))+1]= paste(names(fac_list1)[z],"_",names(uni_list)[u])
      
      result_full_cmbn = data.frame(rbind(result_full_cmbn,result_full))
      
      ret_full_cmbn_L = data.frame(cbind(ret_full_cmbn_L,lng_ret_full))
      colnames(ret_full_cmbn_L)[z+(u-1)*(length(fac_list1))+1]= paste(names(fac_list1)[z],"_",names(uni_list)[u])
      
      ret_full_cmbn_S = data.frame(cbind(ret_full_cmbn_S, sht_ret_full))
      colnames(ret_full_cmbn_S)[z+(u-1)*(length(fac_list1))+1]= paste(names(fac_list1)[z],"_",names(uni_list)[u])
      
      if (topbot!=0){   
        ret_tb_cmbn = data.frame(cbind(ret_tb_cmbn,tot_ret_tb))
        colnames(ret_tb_cmbn)[z+(u-1)*(length(fac_list1))+1]= paste(names(fac_list1)[z],"_",names(uni_list)[u])
        
        result_tb_cmbn = data.frame(rbind(result_tb_cmbn,result_tb))
        
        ret_tb_cmbn_L = data.frame(cbind(ret_tb_cmbn_L,lng_ret_tb))
        colnames(ret_tb_cmbn_L)[z+(u-1)*(length(fac_list1))+1]= paste(names(fac_list1)[z],"_",names(uni_list)[u])
        
        ret_tb_cmbn_S = data.frame(cbind(ret_tb_cmbn_S, sht_ret_tb))
        colnames(ret_tb_cmbn_S)[z+(u-1)*(length(fac_list1))+1]= paste(names(fac_list1)[z],"_",names(uni_list)[u])
        
      }
      
    }
  }
}



write.csv(ret_full_cmbn,paste(path_output,"FULL_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(result_full_cmbn,paste(path_output,"RESULTS_FULL_CMBND.csv"))
write.csv(ret_full_cmbn_L,paste(path_output,"LONG_FULL_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(ret_full_cmbn_S,paste(path_output,"SHT_FULL_CMBND_RETURNS.csv"),row.names=FALSE)

write.csv(ret_tb_cmbn,paste(path_output,"TOP_BOT_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(result_tb_cmbn,paste(path_output,"RESULTS_TB_CMBND.csv"))
write.csv(ret_tb_cmbn_L,paste(path_output,"LONG_TOP_BOT_CMBND_RETURNS.csv"),row.names=FALSE)
write.csv(ret_tb_cmbn_S,paste(path_output,"SHT_TOP_BOT_CMBND_RETURNS.csv"),row.names=FALSE)

