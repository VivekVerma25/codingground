# This is the code for creating return, given stock list and weights , every rebalancing date

##################################################### Libraries

library("xts")
library("zoo")
library("matrixStats")


############################ Inputs to the code
setwd("D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/")
path_input<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/INPUT/"
dir.create("DYNAMIC UNI zscore250 2sigma")
path_output<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/DYNAMIC UNI zscore250 2sigma/"

stck_lvl<-data.frame(read.csv(paste(path_input,"FUT DB/","RollAdjReturns1.csv",sep="")))
stck_lvl$Date<-as.Date(stck_lvl$Date,"%d/%m/%Y")

u1 = data.frame(read.csv(paste(path_input,"Universe/","ActiveFO.csv",sep="")))
u2 = data.frame(read.csv(paste(path_input,"Universe/","TOP 100 OPTIONS.csv",sep="")))
u3 = data.frame(read.csv(paste(path_input,"Universe/","TOP 100 ANALYST.csv",sep="")))


uni_list = vector("list",3)
uni_list[[1]] = u1
uni_list[[2]] = u2
uni_list[[3]] = u3

names(uni_list) = list("ActiveFO_95per","TOP 100 OPTIONS_95per","TOP 100 ANALYST_95per")



lookback_period=c(250)

for(l in 1:length(lookback_period)){
  
  wq1<-stck_lvl
  dt<-wq1[1:nrow(wq1),1]
  #m<-rollapply(wq1[,-1],lookback_period[l],mean,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  s<-rollapply(wq1[,-1],22,sd,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  roll= s
  rollfin <- data.frame(roll)
  rollfin<-as.matrix(rollfin)
  rollfin[which(!is.finite(rollfin))] <- NA
  roll= rollfin
  
  S<-rollapply(roll,lookback_period[l],sd,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  m<-rollapply(roll,lookback_period[l],mean,na.rm =TRUE,fill=NA,align = "right",by.column=TRUE)
  
  roll= (wq1[,-1]-m)/s
  rollfin <- data.frame(roll)
  rollfin<-as.matrix(rollfin)
  rollfin[which(!is.finite(rollfin))] <- NA
  rollfin<-data.frame(DATE=dt,rollfin)
  
  ret <-rollfin      
}

ret1 =ret


for(k in 1:3){
  
  
  ret1[,-1][uni_list[[k]][,-1]==0] = NA
  
  u_old = uni_list[[k]]
  u1_fin = uni_list[[k]]

for(i in 6: dim(stck_lvl)[1] )
{
  
  if((stck_lvl[i,1] - stck_lvl[i-1,1] >=3) && months(stck_lvl[i,1])==months(stck_lvl[i-1,1]))
    
  {
    
    
    rnk = data.frame(t(apply(ret1[i,-1], 1, rank,na.last="keep",ties.method="random"))) 
    topminc = round((apply(rnk, 1, quantile,probs=0.95,na.rm =TRUE,ties.method="random")))
    
    
    #topminc<-data.frame((apply(rnk,1,max,na.rm=TRUE)))
    
    #topminc = (topminc)*(0.95)
    
    #topminc_cbnd <- topminc
    # 
    # for (j in 2:dim(rnk)[2] ){
    #   topminc_cbnd<-cbind(topminc_cbnd,topminc +1)
    #   
    # }
    
    #xx= u1_fin[i,-1]
    c=which(rnk>topminc)
    if(length(c) !=0)
    {
    u1_fin[i,c+1][ret1[i,c+1] > 2] = 0
    #u1_fin[i,-1][rnk>topminc] = 0
    }
    #yy= u1_fin[i,-1]
    
  }
  
  else{
    
    if(months(stck_lvl[i,1])!=months(stck_lvl[i-1,1]))
    {u1_fin[i,-1] = u_old[i,-1]}
    
    else{
      u1_fin[i,-1] = u1_fin[i-1,-1] 
    }
  }
  
  
}

write.csv(u1_fin,paste(path_output,names(uni_list)[k],".csv",sep=""),row.names=FALSE)
}
