
##################################################### Libraries

library("xts")
library("zoo")
library("matrixStats")

############################ Inputs to the code
setwd("D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/")
path_input<-"D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/"
FOLDER_NAME = "MF TESTING MICHAELENGELO PAIRWISE AVG RETURNS"
dir.create(FOLDER_NAME)
path_output<-paste("D:/LFT/Template/tester/R test data/full simulation/FINAL FILES/OUTPUT/",FOLDER_NAME,"/",sep="")
source("D:/LFT/Template/tester/R test data/full simulation/ALL R CODES/R_FUNC_NEW.R")


tot_ret_tb<-data.frame(read.csv(paste(path_input,"85TH PER PRI MICHAELENGELO/"," TOP_BOT_CMBND_RETURNS.csv",sep="")))     # INPUT FOR RETURN SERIES OF FUTURES/STOCKS
tot_ret_tb$Date<-as.Date(tot_ret_tb$Date,"%Y-%M-%D") # Convert to R date format
as.character